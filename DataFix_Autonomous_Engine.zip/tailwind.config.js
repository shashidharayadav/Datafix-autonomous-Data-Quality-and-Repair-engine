/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        datafix: {
          bg: '#050B0B',          // Main background (Almost Black)
          sidebar: '#080F12',     // Deep Black
          header: '#080F12',      // Dark Black
          dark: '#111827',        // Near Black text
          white: '#F8FAFC',       // Crisp White text
          muted: '#A7B4B8',       // Secondary grey text
          card: '#FFFFFF',        // Main cards (White)
          cardDark: '#0B1519',    // Secondary dark card container
          teal: '#00B8AD',        // Primary Bright Teal
          'teal-deep': '#008F89', // Secondary Deep Teal
          'teal-light': '#BFF8F0',// Pale Teal
          'border-dark': '#26383A', // Dark borders
          'border-light': '#E5E7EB', // Light borders
          success: '#16A36A',     // Green
          warning: '#F59E0B',     // Amber
          error: '#EF4444',       // Red
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'card': '0 4px 20px -2px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.05)',
        'card-white': '0 4px 20px -2px rgba(0, 0, 0, 0.05), 0 0 0 1px rgba(0, 0, 0, 0.05)',
        'teal-glow': '0 0 25px rgba(0, 184, 173, 0.35)',
        'teal-sm': '0 0 10px rgba(0, 184, 173, 0.2)',
      }
    },
  },
  plugins: [],
}
