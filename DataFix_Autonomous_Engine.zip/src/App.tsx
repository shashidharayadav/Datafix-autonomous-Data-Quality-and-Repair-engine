import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { ProtectedRoute } from './layouts/ProtectedRoute';
import { MainLayout } from './layouts/MainLayout';

// Auth Pages
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';

// Application Pages
import { OverviewPage } from './pages/OverviewPage';
import { UploadDatasetPage } from './pages/UploadDatasetPage';
import { DatasetInspectorPage } from './pages/DatasetInspectorPage';
import { IssueDetectionPage } from './pages/IssueDetectionPage';
import { DiagnosisPage } from './pages/DiagnosisPage';
import { DataRepairPage } from './pages/DataRepairPage';
import { ValidationPage } from './pages/ValidationPage';
import { ExplainabilityPage } from './pages/ExplainabilityPage';
import { AuditHistoryPage } from './pages/AuditHistoryPage';
import { ReportsPage } from './pages/ReportsPage';

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <DataProvider>
          <Routes>
            {/* Public Authentication Routes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />

            {/* Protected DataFix Application Experience */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Navigate to="/overview" replace />} />
              <Route path="overview" element={<OverviewPage />} />
              <Route path="upload" element={<UploadDatasetPage />} />
              <Route path="inspector" element={<DatasetInspectorPage />} />
              <Route path="detection" element={<IssueDetectionPage />} />
              <Route path="diagnosis" element={<DiagnosisPage />} />
              <Route path="repair" element={<DataRepairPage />} />
              <Route path="validation" element={<ValidationPage />} />
              <Route path="explainability" element={<ExplainabilityPage />} />
              <Route path="audit" element={<AuditHistoryPage />} />
              <Route path="reports" element={<ReportsPage />} />
            </Route>

            {/* Catch-all route */}
            <Route path="*" element={<Navigate to="/overview" replace />} />
          </Routes>
        </DataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
