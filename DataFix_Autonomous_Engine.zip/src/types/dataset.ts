export type IssueCategory = 
  | 'missing_values'
  | 'duplicate_records'
  | 'invalid_formats'
  | 'inconsistent_entries'
  | 'anomalies';

export type IssueSeverity = 'critical' | 'high' | 'medium' | 'low';

export type RepairStatus = 'proposed' | 'approved' | 'rejected' | 'applied' | 'requires_review';

export interface DatasetColumn {
  name: string;
  type: 'string' | 'integer' | 'float' | 'date' | 'boolean' | 'category';
  missingCount: number;
  missingPercentage: number;
  uniqueCount: number;
  sampleValues: (string | number | boolean | null)[];
  hasDuplicates?: boolean;
  status: 'clean' | 'warning' | 'critical';
}

export interface DatasetItem {
  id: string;
  name: string;
  fileName: string;
  fileSize: string;
  rowCount: number;
  columnCount: number;
  uploadedAt: string;
  format: 'CSV' | 'XLSX' | 'JSON' | 'PARQUET';
  status: 'Ready' | 'Processing' | 'Cleaned' | 'Issues Found';
  qualityScoreBefore: number;
  qualityScoreAfter?: number;
  issuesCount: number;
  repairedCount: number;
  columns: DatasetColumn[];
  rawRows: Record<string, any>[];
}

export interface QualityIssue {
  id: string;
  category: IssueCategory;
  categoryLabel: string;
  severity: IssueSeverity;
  columnName: string;
  affectedRowsCount: number;
  affectedRowIndices: number[];
  description: string;
  detectedAt: string;
  status: 'open' | 'investigating' | 'repair_ready' | 'resolved';
  sampleAffectedRows: Record<string, any>[];
}

export interface DiagnosisEntry {
  id: string;
  issueId: string;
  category: IssueCategory;
  columnName: string;
  affectedRecords: number;
  identifiedPattern: string;
  possibleRootCauses: string[];
  observedEvidence: string[];
  systemExplanation: string;
  confidenceScore: number; // 0 - 100
  impactAssessment: 'High Risk' | 'Moderate Risk' | 'Low Risk';
}

export interface RepairProposal {
  id: string;
  issueId: string;
  recordId: string | number;
  columnName: string;
  originalValue: any;
  recommendedValue: any;
  repairMethod: string;
  repairReason: string;
  confidence: number; // 0 - 100
  status: RepairStatus;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface ValidationCheck {
  id: string;
  ruleName: string;
  category: string;
  description: string;
  status: 'passed' | 'failed' | 'warning';
  recordsTested: number;
  failuresFound: number;
  details: string;
}

export interface ExplainabilityRecord {
  id: string;
  repairId: string;
  recordId: string | number;
  columnName: string;
  originalValue: any;
  newValue: any;
  issueType: string;
  repairMethod: string;
  whyChosen: string;
  algorithmName: string;
  supportingEvidence: string[];
  confidenceScore: number;
  alternativeOptions: { method: string; score: number; whyNotChosen: string }[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  datasetName: string;
  recordIdentifier: string | number;
  columnName: string;
  originalValue: any;
  updatedValue: any;
  repairMethod: string;
  action: 'Auto-Repair' | 'Manual Approval' | 'Bulk Patch' | 'Rejection' | 'Rollback';
  operator: string;
  status: 'Completed' | 'Pending' | 'Rolled Back';
}

export interface QualityReport {
  id: string;
  datasetId: string;
  datasetName: string;
  generatedAt: string;
  initialScore: number;
  finalScore: number;
  totalRecords: number;
  totalIssuesFound: number;
  issuesRepaired: number;
  issuesRemaining: number;
  breakdown: Record<IssueCategory, { detected: number; repaired: number }>;
  executiveSummary: string;
  validationStatus: 'Passed with Distinction' | 'Passed with Warnings' | 'Requires Attention';
}
