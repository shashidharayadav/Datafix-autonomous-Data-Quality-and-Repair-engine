import { 
  DatasetItem, 
  QualityIssue, 
  DiagnosisEntry, 
  RepairProposal, 
  ValidationCheck, 
  ExplainabilityRecord, 
  AuditLog, 
  QualityReport 
} from '../types/dataset';
import { apiClient } from './api';

export const INITIAL_DATASETS: DatasetItem[] = [
  {
    id: 'ds_fin_q4_01',
    name: 'Q4_Financial_Transactions_Audit.csv',
    fileName: 'Q4_Financial_Transactions_Audit.csv',
    fileSize: '4.8 MB',
    rowCount: 12480,
    columnCount: 12,
    uploadedAt: '2026-11-18 14:32',
    format: 'CSV',
    status: 'Issues Found',
    qualityScoreBefore: 64.8,
    qualityScoreAfter: 98.4,
    issuesCount: 384,
    repairedCount: 312,
    columns: [
      { name: 'transaction_id', type: 'string', missingCount: 0, missingPercentage: 0, uniqueCount: 12380, sampleValues: ['TXN-9011', 'TXN-9012', 'TXN-9013'], status: 'warning', hasDuplicates: true },
      { name: 'timestamp', type: 'date', missingCount: 14, missingPercentage: 0.11, uniqueCount: 11980, sampleValues: ['2026-10-01 09:12:00', '2026-10-01 09:15:30', 'invalid_date_format'], status: 'warning' },
      { name: 'customer_id', type: 'string', missingCount: 0, missingPercentage: 0, uniqueCount: 4210, sampleValues: ['CUST-802', 'CUST-104', 'CUST-992'], status: 'clean' },
      { name: 'customer_state', type: 'category', missingCount: 88, missingPercentage: 0.7, uniqueCount: 64, sampleValues: ['CA', 'California', 'calif', 'NY'], status: 'warning' },
      { name: 'annual_income', type: 'float', missingCount: 142, missingPercentage: 1.14, uniqueCount: 8900, sampleValues: [75000, 112000, null, 48000], status: 'critical' },
      { name: 'transaction_amount', type: 'float', missingCount: 0, missingPercentage: 0, uniqueCount: 9410, sampleValues: [149.50, 4200.00, -999999.00, 24.99], status: 'critical' },
      { name: 'merchant_category', type: 'category', missingCount: 12, missingPercentage: 0.09, uniqueCount: 18, sampleValues: ['Retail', 'Hospitality', 'Tech', 'RETAIL_ERR'], status: 'warning' },
      { name: 'credit_score', type: 'integer', missingCount: 62, missingPercentage: 0.49, uniqueCount: 480, sampleValues: [720, 680, 815, 0], status: 'warning' },
      { name: 'risk_tier', type: 'string', missingCount: 0, missingPercentage: 0, uniqueCount: 3, sampleValues: ['Low', 'Medium', 'High'], status: 'clean' },
      { name: 'is_fraud_flagged', type: 'boolean', missingCount: 0, missingPercentage: 0, uniqueCount: 2, sampleValues: [false, false, true], status: 'clean' },
      { name: 'postal_code', type: 'string', missingCount: 48, missingPercentage: 0.38, uniqueCount: 1820, sampleValues: ['94103', '10001', '00000', '90210'], status: 'warning' },
      { name: 'approval_status', type: 'string', missingCount: 18, missingPercentage: 0.14, uniqueCount: 5, sampleValues: ['APPROVED', 'Declined', 'PENDING', null], status: 'warning' },
    ],
    rawRows: [
      { id: 1, transaction_id: 'TXN-9011', timestamp: '2026-10-01 09:12:00', customer_id: 'CUST-802', customer_state: 'CA', annual_income: 75000, transaction_amount: 149.50, merchant_category: 'Retail', credit_score: 720, risk_tier: 'Low', is_fraud_flagged: false, postal_code: '94103', approval_status: 'APPROVED' },
      { id: 2, transaction_id: 'TXN-9012', timestamp: '2026-10-01 09:15:30', customer_id: 'CUST-104', customer_state: 'California', annual_income: 112000, transaction_amount: 4200.00, merchant_category: 'Hospitality', credit_score: 680, risk_tier: 'Medium', is_fraud_flagged: false, postal_code: '90210', approval_status: 'APPROVED' },
      { id: 3, transaction_id: 'TXN-9013', timestamp: 'invalid_date_format', customer_id: 'CUST-992', customer_state: 'calif', annual_income: null, transaction_amount: -999999.00, merchant_category: 'RETAIL_ERR', credit_score: 0, risk_tier: 'High', is_fraud_flagged: true, postal_code: '00000', approval_status: null },
      { id: 4, transaction_id: 'TXN-9011', timestamp: '2026-10-01 09:12:00', customer_id: 'CUST-802', customer_state: 'CA', annual_income: 75000, transaction_amount: 149.50, merchant_category: 'Retail', credit_score: 720, risk_tier: 'Low', is_fraud_flagged: false, postal_code: '94103', approval_status: 'APPROVED' },
      { id: 5, transaction_id: 'TXN-9015', timestamp: '2026-10-01 10:04:12', customer_id: 'CUST-331', customer_state: 'NY', annual_income: 88500, transaction_amount: 32.10, merchant_category: 'Retail', credit_score: 745, risk_tier: 'Low', is_fraud_flagged: false, postal_code: '10001', approval_status: 'APPROVED' },
      { id: 6, transaction_id: 'TXN-9016', timestamp: '2026-10-01 10:18:45', customer_id: 'CUST-519', customer_state: 'TX', annual_income: null, transaction_amount: 512.00, merchant_category: 'Tech', credit_score: 690, risk_tier: 'Medium', is_fraud_flagged: false, postal_code: '75001', approval_status: 'APPROVED' },
      { id: 7, transaction_id: 'TXN-9017', timestamp: '2026-10-01 11:00:20', customer_id: 'CUST-412', customer_state: 'FL', annual_income: 62000, transaction_amount: 12000.00, merchant_category: 'Hospitality', credit_score: 710, risk_tier: 'Medium', is_fraud_flagged: false, postal_code: '33101', approval_status: 'APPROVED' },
      { id: 8, transaction_id: 'TXN-9018', timestamp: '2026-10-01 11:22:10', customer_id: 'CUST-709', customer_state: 'Washington', annual_income: 145000, transaction_amount: 88.00, merchant_category: 'Retail', credit_score: 810, risk_tier: 'Low', is_fraud_flagged: false, postal_code: '98101', approval_status: 'APPROVED' }
    ]
  },
  {
    id: 'ds_healthcare_02',
    name: 'Clinical_Trial_Patient_Demographics.xlsx',
    fileName: 'Clinical_Trial_Patient_Demographics.xlsx',
    fileSize: '2.1 MB',
    rowCount: 6420,
    columnCount: 10,
    uploadedAt: '2026-11-17 11:05',
    format: 'XLSX',
    status: 'Cleaned',
    qualityScoreBefore: 72.1,
    qualityScoreAfter: 99.2,
    issuesCount: 142,
    repairedCount: 142,
    columns: [],
    rawRows: []
  },
  {
    id: 'ds_iot_sensors_03',
    name: 'Smart_Turbine_Telemetry_Stream.csv',
    fileName: 'Smart_Turbine_Telemetry_Stream.csv',
    fileSize: '8.4 MB',
    rowCount: 45000,
    columnCount: 16,
    uploadedAt: '2026-11-16 18:20',
    format: 'CSV',
    status: 'Cleaned',
    qualityScoreBefore: 58.4,
    qualityScoreAfter: 97.6,
    issuesCount: 610,
    repairedCount: 598,
    columns: [],
    rawRows: []
  }
];

export const SAMPLE_ISSUES: QualityIssue[] = [
  {
    id: 'iss_01',
    category: 'missing_values',
    categoryLabel: 'Missing Values',
    severity: 'critical',
    columnName: 'annual_income',
    affectedRowsCount: 142,
    affectedRowIndices: [3, 6, 12, 45, 88],
    description: '142 customer records lack annual income figures required for downstream risk scoring and compliance tiering.',
    detectedAt: '2026-11-18 14:35',
    status: 'repair_ready',
    sampleAffectedRows: [
      { id: 3, transaction_id: 'TXN-9013', customer_id: 'CUST-992', annual_income: null, customer_state: 'calif' },
      { id: 6, transaction_id: 'TXN-9016', customer_id: 'CUST-519', annual_income: null, customer_state: 'TX' }
    ]
  },
  {
    id: 'iss_02',
    category: 'duplicate_records',
    categoryLabel: 'Duplicate Records',
    severity: 'high',
    columnName: 'transaction_id',
    affectedRowsCount: 100,
    affectedRowIndices: [1, 4, 18, 19],
    description: '100 duplicate transaction submissions detected with identical payload hashes within a 500ms window.',
    detectedAt: '2026-11-18 14:35',
    status: 'repair_ready',
    sampleAffectedRows: [
      { id: 1, transaction_id: 'TXN-9011', customer_id: 'CUST-802', timestamp: '2026-10-01 09:12:00' },
      { id: 4, transaction_id: 'TXN-9011', customer_id: 'CUST-802', timestamp: '2026-10-01 09:12:00' }
    ]
  },
  {
    id: 'iss_03',
    category: 'invalid_formats',
    categoryLabel: 'Invalid Formats',
    severity: 'high',
    columnName: 'timestamp',
    affectedRowsCount: 14,
    affectedRowIndices: [3, 22, 57],
    description: 'Non-conforming ISO 8601 timestamps found (e.g., text strings, day-month inversion, truncated epochs).',
    detectedAt: '2026-11-18 14:36',
    status: 'repair_ready',
    sampleAffectedRows: [
      { id: 3, transaction_id: 'TXN-9013', timestamp: 'invalid_date_format', status: 'ERR' }
    ]
  },
  {
    id: 'iss_04',
    category: 'inconsistent_entries',
    categoryLabel: 'Inconsistent Entries',
    severity: 'medium',
    columnName: 'customer_state',
    affectedRowsCount: 88,
    affectedRowIndices: [2, 3, 14, 61],
    description: 'Inconsistent state taxonomy detected: mixed casing, unabbreviated names ("California"), and informal tokens ("calif").',
    detectedAt: '2026-11-18 14:36',
    status: 'repair_ready',
    sampleAffectedRows: [
      { id: 2, customer_state: 'California' },
      { id: 3, customer_state: 'calif' }
    ]
  },
  {
    id: 'iss_05',
    category: 'anomalies',
    categoryLabel: 'Statistical Anomalies',
    severity: 'critical',
    columnName: 'transaction_amount',
    affectedRowsCount: 40,
    affectedRowIndices: [3, 91, 104],
    description: 'Values violating physical boundary conditions: negative transactions (-$999,999.00) on credit authorizations.',
    detectedAt: '2026-11-18 14:37',
    status: 'repair_ready',
    sampleAffectedRows: [
      { id: 3, transaction_id: 'TXN-9013', transaction_amount: -999999.00, credit_score: 0 }
    ]
  }
];

export const SAMPLE_DIAGNOSES: DiagnosisEntry[] = [
  {
    id: 'diag_01',
    issueId: 'iss_01',
    category: 'missing_values',
    columnName: 'annual_income',
    affectedRecords: 142,
    identifiedPattern: 'Missingness correlates 91.4% with mobile web onboarding v2.4 where income step was inadvertently set to optional.',
    possibleRootCauses: [
      'Frontend form validation bypass on iOS Safari Safari 17.2 client.',
      'OAuth2 social login bridge omitting optional telemetry attributes.',
      'Partial batch sync failure during nightly ETL ingestion.'
    ],
    observedEvidence: [
      '131 of 142 null records originated from user_agent matching MobileSafari.',
      'Nulls clustered specifically between 2026-10-01 and 2026-10-05 corresponding to Deploy #412.',
      'Customer age and credit score features are 100% complete across all 142 rows.'
    ],
    systemExplanation: 'The missingness mechanism is classified as Missing at Random (MAR). Demographic and credit score covariates provide strong mutual information to reconstruct missing values via Multivariate Imputation by Chained Equations (MICE).',
    confidenceScore: 96.8,
    impactAssessment: 'High Risk'
  },
  {
    id: 'diag_02',
    issueId: 'iss_02',
    category: 'duplicate_records',
    columnName: 'transaction_id',
    affectedRecords: 100,
    identifiedPattern: 'Double-post HTTP retry loop causing twin database inserts with identical microsecond intervals.',
    possibleRootCauses: [
      'Lack of idempotency keys in merchant payment gateway webhook handler.',
      'Aggressive client-side network retry policy on mobile cellular fluctuations.'
    ],
    observedEvidence: [
      'Duplicate pairs exhibit identical SHA-256 payload checksums.',
      'Created timestamps differ by under 140 milliseconds.'
    ],
    systemExplanation: 'Classic network-layer replay issue. Deduplication via first-arrival retention strategy guarantees zero loss of legitimate transactional intent.',
    confidenceScore: 99.4,
    impactAssessment: 'High Risk'
  },
  {
    id: 'diag_03',
    issueId: 'iss_03',
    category: 'invalid_formats',
    columnName: 'timestamp',
    affectedRecords: 14,
    identifiedPattern: 'Legacy POS terminal batch file exported localized European date strings (DD/MM/YYYY) without timezone offsets.',
    possibleRootCauses: [
      'Uncalibrated offline terminal firmware at regional retail branch #14.',
      'Excel auto-formatting converting string dates into corrupt serial numbers.'
    ],
    observedEvidence: [
      'Strings contain unparsed literal "invalid_date_format" or inverted month indices (e.g. 13-02-2026).'
    ],
    systemExplanation: 'Syntactic corruption during extraction. Deterministic regex pattern matching against terminal logs successfully recovers ISO 8601 UTC timestamps.',
    confidenceScore: 94.0,
    impactAssessment: 'Moderate Risk'
  },
  {
    id: 'diag_04',
    issueId: 'iss_04',
    category: 'inconsistent_entries',
    columnName: 'customer_state',
    affectedRecords: 88,
    identifiedPattern: 'Unconstrained free-text input field allowed varied abbreviations and capitalizations for US State names.',
    possibleRootCauses: [
      'Absence of ISO-3166-2 dropdown select constraint on web intake form.',
      'Legacy CRM migration merging 3 separate regional databases.'
    ],
    observedEvidence: [
      '6 distinct variants found for California ("CA", "ca", "Calif", "California", "CALIFORNIA", "calif").'
    ],
    systemExplanation: 'Semantic taxonomy divergence. Fully repairable via exact dictionary lookup and Levenshtein token distance.',
    confidenceScore: 99.8,
    impactAssessment: 'Low Risk'
  },
  {
    id: 'diag_05',
    issueId: 'iss_05',
    category: 'anomalies',
    columnName: 'transaction_amount',
    affectedRecords: 40,
    identifiedPattern: 'Sentinel error value -999999.00 populated by legacy mainframe COBOL backend when currency calculation overflows.',
    possibleRootCauses: [
      'Hardcoded negative sentinel flag indicating calculation timeout in Core Banking Engine v1.',
      'Integer underflow in batch reconciliation pipeline.'
    ],
    observedEvidence: [
      'Values are exactly -$999,999.00 with accompanying zeroed credit scores.',
      'All affected records possess corresponding settlement receipts with genuine amounts.'
    ],
    systemExplanation: 'Machine sentinel values masquerading as real numerical metrics. Replaced with genuine reconciliation settlement values from ledger audit stream.',
    confidenceScore: 98.2,
    impactAssessment: 'High Risk'
  }
];

export const SAMPLE_REPAIRS: RepairProposal[] = [
  {
    id: 'rep_01',
    issueId: 'iss_01',
    recordId: 3,
    columnName: 'annual_income',
    originalValue: 'null',
    recommendedValue: '$78,400.00',
    repairMethod: 'MICE Imputation (Covariates: Credit Score 720, Age 34, Zip 94103)',
    repairReason: 'Imputed using high-fidelity chained equations across postal code and credit tier distributions.',
    confidence: 96,
    status: 'proposed'
  },
  {
    id: 'rep_02',
    issueId: 'iss_02',
    recordId: 4,
    columnName: 'transaction_id',
    originalValue: 'TXN-9011 (Duplicate row)',
    recommendedValue: '[REMOVE REDUNDANT CLONE]',
    repairMethod: 'Deterministic Deduplication (Keep Original Row #1)',
    repairReason: 'Exact SHA-256 match with Row #1 within 120ms window. Redundant network replay.',
    confidence: 99,
    status: 'proposed'
  },
  {
    id: 'rep_03',
    issueId: 'iss_03',
    recordId: 3,
    columnName: 'timestamp',
    originalValue: 'invalid_date_format',
    recommendedValue: '2026-10-01 09:18:22 UTC',
    repairMethod: 'Log Stream Re-correlation & ISO 8601 Parser',
    repairReason: 'Recovered authentic microsecond timestamp from upstream Kafka ingress receipt.',
    confidence: 95,
    status: 'proposed'
  },
  {
    id: 'rep_04',
    issueId: 'iss_04',
    recordId: 2,
    columnName: 'customer_state',
    originalValue: 'California',
    recommendedValue: 'CA',
    repairMethod: 'ISO-3166-2 Canonical Mapping',
    repairReason: 'Standardized full state name to standardized 2-letter uppercase postal code.',
    confidence: 100,
    status: 'approved'
  },
  {
    id: 'rep_05',
    issueId: 'iss_04',
    recordId: 3,
    columnName: 'customer_state',
    originalValue: 'calif',
    recommendedValue: 'CA',
    repairMethod: 'Fuzzy String Matching (Levenshtein Distance 0.96)',
    repairReason: 'Resolved informal colloquial token to canonical US state code.',
    confidence: 98,
    status: 'approved'
  },
  {
    id: 'rep_06',
    issueId: 'iss_05',
    recordId: 3,
    columnName: 'transaction_amount',
    originalValue: '-999999.00',
    recommendedValue: '$249.00',
    repairMethod: 'Ledger Audit Cross-Reference Reconciliation',
    repairReason: 'Replaced mainframe sentinel overflow error with genuine verified receipt amount.',
    confidence: 99,
    status: 'proposed'
  },
  {
    id: 'rep_07',
    issueId: 'iss_01',
    recordId: 6,
    columnName: 'annual_income',
    originalValue: 'null',
    recommendedValue: '$92,500.00',
    repairMethod: 'KNN Imputation (k=7 nearest demographic neighbors)',
    repairReason: 'Imputed using nearest tech-sector employment profile in Texas zip code 75001.',
    confidence: 94,
    status: 'proposed'
  }
];

export const SAMPLE_VALIDATIONS: ValidationCheck[] = [
  {
    id: 'val_01',
    ruleName: 'Completeness Check (Missing Values)',
    category: 'Completeness',
    description: 'Ensure all critical business columns have 0% null rates or valid imputations.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: '142/142 null income records repaired via MICE algorithm. 0 missing values remain.'
  },
  {
    id: 'val_02',
    ruleName: 'Uniqueness & Primary Key Integrity',
    category: 'Integrity',
    description: 'Validate that transaction_id contains zero duplicate entries across the partition.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: '100 duplicate submissions purged. Primary key uniqueness verified at 100%.'
  },
  {
    id: 'val_03',
    ruleName: 'Temporal Format Compliance (ISO 8601)',
    category: 'Syntax',
    description: 'Enforce strict YYYY-MM-DD HH:mm:ss timestamp formatting with timezone offsets.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: '14 malformed timestamp strings parsed and transformed into valid UTC datetimes.'
  },
  {
    id: 'val_04',
    ruleName: 'Categorical Taxonomy Adherence',
    category: 'Consistency',
    description: 'Ensure State and Merchant categories match official ISO-3166 and NAICS dictionaries.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: '88 state entries canonicalized. No unregistered categorical tokens detected.'
  },
  {
    id: 'val_05',
    ruleName: 'Boundary & Value Range Constraints',
    category: 'Validity',
    description: 'Ensure numerical columns (amounts, scores) adhere to non-negative boundaries.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: '40 negative sentinel records reconciled. All transaction amounts are in valid range ($0.01 - $25,000.00).'
  },
  {
    id: 'val_06',
    ruleName: 'Inter-Column Statistical Correlation',
    category: 'Plausibility',
    description: 'Verify credit scores and income distributions match expected risk curve correlations.',
    status: 'passed',
    recordsTested: 12480,
    failuresFound: 0,
    details: 'Pearson correlation r=0.68 aligns with benchmark financial population distribution.'
  }
];

export const SAMPLE_EXPLAINABILITY: ExplainabilityRecord[] = [
  {
    id: 'exp_01',
    repairId: 'rep_01',
    recordId: 3,
    columnName: 'annual_income',
    originalValue: 'null',
    newValue: '$78,400.00',
    issueType: 'Missing Value (MAR)',
    repairMethod: 'Multivariate Imputation by Chained Equations (MICE)',
    whyChosen: 'Selected MICE over Mean/Median imputation to preserve non-linear covariance with Credit Score (720) and Postal Code (94103).',
    algorithmName: 'DataFix Iterative Predictive Mean Matching (PMM)',
    confidenceScore: 96,
    supportingEvidence: [
      'Credit score 720 falls into the 68th percentile of the customer distribution.',
      'Zip code 94103 median tech employee income is $82,000; age regression adjusted value to $78,400.',
      'Residual variance of imputation model is < 3.2% across 5 stochastic runs.'
    ],
    alternativeOptions: [
      { method: 'Median Imputation ($68,000)', score: 71, whyNotChosen: 'Artificially suppresses variance and deflates downstream credit risk calculations.' },
      { method: 'Drop Row', score: 20, whyNotChosen: 'Violates minimal data destruction policy; drops a high-value customer record.' }
    ]
  },
  {
    id: 'exp_02',
    repairId: 'rep_02',
    recordId: 4,
    columnName: 'transaction_id',
    originalValue: 'TXN-9011 (Row 4)',
    newValue: '[Purged Clone]',
    issueType: 'Exact Duplicate Record',
    repairMethod: 'Deterministic SHA-256 Deduplication',
    whyChosen: 'All 12 column attributes match Row 1 with identical payload hash and microsecond arrival delta of 120ms.',
    algorithmName: 'Deterministic Hash Collision Resolver',
    confidenceScore: 99.8,
    supportingEvidence: [
      'Payload hash: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      'Both rows possess identical card token, IP address, and checkout session ID.'
    ],
    alternativeOptions: [
      { method: 'Rename Transaction ID (TXN-9011_dup)', score: 35, whyNotChosen: 'Would lead to double-billing customer and duplicate accounting liabilities.' }
    ]
  },
  {
    id: 'exp_03',
    repairId: 'rep_06',
    recordId: 3,
    columnName: 'transaction_amount',
    originalValue: '-999999.00',
    newValue: '$249.00',
    issueType: 'Statistical Anomaly / Negative Sentinel',
    repairMethod: 'Ledger Audit Re-correlation',
    whyChosen: 'Identified -$999,999 as known COBOL overflow constant; genuine transaction receipt #9013 verified in merchant clearing ledger.',
    algorithmName: 'Cross-System Ledger Reconciler',
    confidenceScore: 99.2,
    supportingEvidence: [
      'Core banking log error code ERR_COBOL_OVF_999 found in transaction metadata.',
      'Merchant terminal settlement batch confirms authorized charge of $249.00 for item #SKU-4912.'
    ],
    alternativeOptions: [
      { method: 'Replace with 0.00', score: 40, whyNotChosen: 'Distorts merchant settlement totals and ledger reconciliation.' },
      { method: 'Outlier Capping ($149.50)', score: 55, whyNotChosen: 'Synthetic guess when authoritative truth is available in audit ledger.' }
    ]
  }
];

export const SAMPLE_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud_01',
    timestamp: '2026-11-18 14:42:10',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #4 (TXN-9011)',
    columnName: 'transaction_id',
    originalValue: 'TXN-9011',
    updatedValue: '[REMOVED]',
    repairMethod: 'Deterministic Deduplication',
    action: 'Auto-Repair',
    operator: 'DataFix Engine v2.4 (Autonomous)',
    status: 'Completed'
  },
  {
    id: 'aud_02',
    timestamp: '2026-11-18 14:42:12',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #2 (TXN-9012)',
    columnName: 'customer_state',
    originalValue: 'California',
    updatedValue: 'CA',
    repairMethod: 'ISO-3166-2 Canonical Mapping',
    action: 'Manual Approval',
    operator: 'Alex Mercer (Lead Engineer)',
    status: 'Completed'
  },
  {
    id: 'aud_03',
    timestamp: '2026-11-18 14:42:15',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #3 (TXN-9013)',
    columnName: 'customer_state',
    originalValue: 'calif',
    updatedValue: 'CA',
    repairMethod: 'Fuzzy String Matching',
    action: 'Manual Approval',
    operator: 'Alex Mercer (Lead Engineer)',
    status: 'Completed'
  },
  {
    id: 'aud_04',
    timestamp: '2026-11-18 14:42:18',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #3 (TXN-9013)',
    columnName: 'timestamp',
    originalValue: 'invalid_date_format',
    updatedValue: '2026-10-01 09:18:22 UTC',
    repairMethod: 'Log Stream Re-correlation',
    action: 'Auto-Repair',
    operator: 'DataFix Engine v2.4 (Autonomous)',
    status: 'Completed'
  },
  {
    id: 'aud_05',
    timestamp: '2026-11-18 14:42:25',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #3 (TXN-9013)',
    columnName: 'transaction_amount',
    originalValue: '-999999.00',
    updatedValue: '$249.00',
    repairMethod: 'Ledger Audit Re-correlation',
    action: 'Bulk Patch',
    operator: 'Alex Mercer (Lead Engineer)',
    status: 'Completed'
  },
  {
    id: 'aud_06',
    timestamp: '2026-11-18 14:42:30',
    datasetName: 'Q4_Financial_Transactions_Audit.csv',
    recordIdentifier: 'Row #3 (TXN-9013)',
    columnName: 'annual_income',
    originalValue: 'null',
    updatedValue: '$78,400.00',
    repairMethod: 'MICE Imputation',
    action: 'Auto-Repair',
    operator: 'DataFix Engine v2.4 (Autonomous)',
    status: 'Completed'
  }
];

export const SAMPLE_REPORT: QualityReport = {
  id: 'rep_q4_final',
  datasetId: 'ds_fin_q4_01',
  datasetName: 'Q4_Financial_Transactions_Audit.csv',
  generatedAt: '2026-11-18 14:45:00',
  initialScore: 64.8,
  finalScore: 98.4,
  totalRecords: 12480,
  totalIssuesFound: 384,
  issuesRepaired: 312,
  issuesRemaining: 72,
  breakdown: {
    missing_values: { detected: 142, repaired: 142 },
    duplicate_records: { detected: 100, repaired: 100 },
    invalid_formats: { detected: 14, repaired: 14 },
    inconsistent_entries: { detected: 88, repaired: 56 },
    anomalies: { detected: 40, repaired: 0 }
  },
  executiveSummary: 'DataFix autonomous inspection executed across 12,480 transactional records and 12 relational attributes. 384 data anomalies and structural defects were detected across 5 core categories. 312 issues have been mathematically repaired, validated, and logged to the immutable audit trail. Overall dataset health score improved from 64.8% (Degraded) to 98.4% (Enterprise Production Ready).',
  validationStatus: 'Passed with Distinction'
};

export const datasetService = {
  async getDatasets(): Promise<DatasetItem[]> {
    try {
      return await apiClient<DatasetItem[]>('/datasets');
    } catch {
      return INITIAL_DATASETS;
    }
  },

  async getDatasetById(id: string): Promise<DatasetItem | undefined> {
    try {
      return await apiClient<DatasetItem>(`/datasets/${id}`);
    } catch {
      return INITIAL_DATASETS.find(d => d.id === id) || INITIAL_DATASETS[0];
    }
  },

  async getIssues(datasetId?: string): Promise<QualityIssue[]> {
    try {
      return await apiClient<QualityIssue[]>(`/datasets/${datasetId || 'active'}/issues`);
    } catch {
      return SAMPLE_ISSUES;
    }
  },

  async getDiagnoses(datasetId?: string): Promise<DiagnosisEntry[]> {
    try {
      return await apiClient<DiagnosisEntry[]>(`/datasets/${datasetId || 'active'}/diagnoses`);
    } catch {
      return SAMPLE_DIAGNOSES;
    }
  },

  async getRepairs(datasetId?: string): Promise<RepairProposal[]> {
    try {
      return await apiClient<RepairProposal[]>(`/datasets/${datasetId || 'active'}/repairs`);
    } catch {
      return SAMPLE_REPAIRS;
    }
  },

  async getValidations(datasetId?: string): Promise<ValidationCheck[]> {
    try {
      return await apiClient<ValidationCheck[]>(`/datasets/${datasetId || 'active'}/validations`);
    } catch {
      return SAMPLE_VALIDATIONS;
    }
  },

  async getExplainability(datasetId?: string): Promise<ExplainabilityRecord[]> {
    try {
      return await apiClient<ExplainabilityRecord[]>(`/datasets/${datasetId || 'active'}/explainability`);
    } catch {
      return SAMPLE_EXPLAINABILITY;
    }
  },

  async getAuditLogs(datasetId?: string): Promise<AuditLog[]> {
    try {
      return await apiClient<AuditLog[]>(`/datasets/${datasetId || 'active'}/audit`);
    } catch {
      return SAMPLE_AUDIT_LOGS;
    }
  },

  async getQualityReport(datasetId?: string): Promise<QualityReport> {
    try {
      return await apiClient<QualityReport>(`/datasets/${datasetId || 'active'}/report`);
    } catch {
      return SAMPLE_REPORT;
    }
  },

  /**
   * Upload dataset file through the backend API integration.
   * Sends multipart/form-data with file and format hint.
   */
  async uploadDataset(file: File, formatHint?: string): Promise<DatasetItem> {
    const formData = new FormData();
    formData.append('file', file);
    if (formatHint) {
      formData.append('format', formatHint);
    }

    try {
      const result = await apiClient<DatasetItem>('/datasets/upload', {
        method: 'POST',
        body: formData,
      });
      return result;
    } catch (err: any) {
      // Re-throw with meaningful backend error details
      throw new Error(err.message || 'Failed to upload dataset to backend.');
    }
  },

  /**
   * Approve a repair proposal through the backend API integration.
   */
  async approveRepair(repairId: string, datasetId: string = 'active'): Promise<{ success: boolean; repair?: RepairProposal; message: string }> {
    try {
      const result = await apiClient<{ success: boolean; repair?: RepairProposal; message: string }>(
        `/datasets/${datasetId}/repairs/${repairId}/approve`,
        {
          method: 'POST',
          body: JSON.stringify({
            repairId,
            timestamp: new Date().toISOString(),
          }),
        }
      );
      return result;
    } catch (err: any) {
      throw new Error(err.message || `Backend failed to approve repair ${repairId}.`);
    }
  },

  /**
   * Reject a repair proposal through the backend API integration.
   */
  async rejectRepair(repairId: string, datasetId: string = 'active'): Promise<{ success: boolean; repair?: RepairProposal; message: string }> {
    try {
      const result = await apiClient<{ success: boolean; repair?: RepairProposal; message: string }>(
        `/datasets/${datasetId}/repairs/${repairId}/reject`,
        {
          method: 'POST',
          body: JSON.stringify({
            repairId,
            timestamp: new Date().toISOString(),
          }),
        }
      );
      return result;
    } catch (err: any) {
      throw new Error(err.message || `Backend failed to reject repair ${repairId}.`);
    }
  },

  /**
   * Apply an approved repair proposal through the backend API integration.
   */
  async applyRepair(repairId: string, datasetId: string = 'active'): Promise<{ success: boolean; repair?: RepairProposal; message: string }> {
    try {
      const result = await apiClient<{ success: boolean; repair?: RepairProposal; message: string }>(
        `/datasets/${datasetId}/repairs/${repairId}/apply`,
        {
          method: 'POST',
          body: JSON.stringify({
            repairId,
            timestamp: new Date().toISOString(),
          }),
        }
      );
      return result;
    } catch (err: any) {
      throw new Error(err.message || `Backend failed to apply repair ${repairId}.`);
    }
  },

  /**
   * Apply all approved repair proposals in bulk through the backend API integration.
   */
  async applyAllApproved(datasetId: string = 'active'): Promise<{ success: boolean; appliedCount?: number; message: string }> {
    try {
      const result = await apiClient<{ success: boolean; appliedCount?: number; message: string }>(
        `/datasets/${datasetId}/repairs/apply-batch`,
        {
          method: 'POST',
          body: JSON.stringify({
            timestamp: new Date().toISOString(),
          }),
        }
      );
      return result;
    } catch (err: any) {
      throw new Error(err.message || 'Backend failed to apply batch repairs.');
    }
  }
};
