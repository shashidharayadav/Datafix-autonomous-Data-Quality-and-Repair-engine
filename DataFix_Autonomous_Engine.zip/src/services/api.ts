/**
 * DataFix Centralized API Service Layer
 * Architecture ready for integration with backend & AI modules.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api/v1';

export class ApiError extends Error {
  status: number;
  data: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

export const getAuthToken = (): string | null => {
  return localStorage.getItem('datafix_auth_token') || sessionStorage.getItem('datafix_auth_token');
};

export const setAuthToken = (token: string, remember: boolean = false): void => {
  if (remember) {
    localStorage.setItem('datafix_auth_token', token);
  } else {
    sessionStorage.setItem('datafix_auth_token', token);
  }
};

export const clearAuthToken = (): void => {
  localStorage.removeItem('datafix_auth_token');
  sessionStorage.removeItem('datafix_auth_token');
  localStorage.removeItem('datafix_user');
  sessionStorage.removeItem('datafix_user');
};

export async function apiClient<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers || {});

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const config: RequestInit = {
    ...options,
    headers,
  };

  try {
    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint}`;
    const response = await fetch(url, config);

    if (response.status === 401) {
      clearAuthToken();
      window.dispatchEvent(new CustomEvent('datafix:unauthorized'));
      throw new ApiError('Session expired. Please log in again.', 401);
    }

    if (!response.ok) {
      let errorData: any;
      try {
        errorData = await response.json();
      } catch {
        let defaultMsg = response.statusText;
        if (response.status === 404) {
          defaultMsg = `Backend endpoint ${url} not found (HTTP 404). Ensure teammate backend server is active and endpoint is mounted.`;
        } else if (response.status === 415) {
          defaultMsg = 'Unsupported file format rejected by backend engine (HTTP 415).';
        } else if (response.status === 413) {
          defaultMsg = 'Payload too large: file exceeds backend size limit (HTTP 413).';
        } else if (response.status === 500) {
          defaultMsg = 'Backend internal server error (HTTP 500) encountered during processing.';
        }
        errorData = { message: defaultMsg };
      }
      throw new ApiError(
        errorData?.message || `Request failed with status ${response.status}`,
        response.status,
        errorData
      );
    }

    if (response.status === 204) {
      return {} as T;
    }

    return await response.json();
  } catch (err: any) {
    if (err instanceof ApiError) {
      throw err;
    }
    throw new ApiError(err.message || 'Network error occurred. Ensure backend is running.', 0);
  }
}
