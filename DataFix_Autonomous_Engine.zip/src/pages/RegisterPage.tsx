import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ParallaxCanvas } from '../components/auth/ParallaxCanvas';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  User as UserIcon, 
  Building2, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  Check, 
  AlertCircle 
} from 'lucide-react';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register, isLoading, error, clearError } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [localError, setLocalError] = useState<string | null>(null);

  // Password strength calculation
  const hasMinLength = password.length >= 8;
  const hasNumber = /\d/.test(password);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const strengthScore = [hasMinLength, hasNumber, hasSpecial, hasUpper].filter(Boolean).length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    if (!name.trim()) {
      setLocalError('Full name is required.');
      return;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setLocalError('Please enter a valid work email.');
      return;
    }
    if (password.length < 8) {
      setLocalError('Password must be at least 8 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setLocalError('Passwords do not match.');
      return;
    }
    if (!agreeTerms) {
      setLocalError('You must agree to the data privacy and security terms.');
      return;
    }

    try {
      await register({ name, email, organization, password, confirmPassword });
      navigate('/overview', { replace: true });
    } catch (err: any) {
      setLocalError(err?.message || 'Failed to create account.');
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col lg:flex-row bg-[#050B0B] text-[#F8FAFC] overflow-hidden">
      {/* Left side with brand & parallax */}
      <div className="relative flex-1 flex flex-col justify-between p-8 lg:p-14 z-10 border-b lg:border-b-0 lg:border-r border-[#26383A]/60">
        <ParallaxCanvas />

        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#00B8AD] to-[#008F89] p-0.5 shadow-teal-glow flex items-center justify-center">
              <div className="w-full h-full bg-[#080F12] rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-[#00B8AD]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-extrabold tracking-wider text-white">DATAFIX</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#00B8AD]/15 text-[#00B8AD] border border-[#00B8AD]/30">
                  REGISTRATION
                </span>
              </div>
              <p className="text-xs font-medium tracking-widest text-[#00B8AD] uppercase">
                Clean. Trust. Grow.
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 max-w-xl my-8 lg:my-auto">
          <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Deploy Autonomous <br />
            <span className="bg-gradient-to-r from-[#00B8AD] via-[#BFF8F0] to-[#00B8AD] bg-clip-text text-transparent">
              Data Reliability.
            </span>
          </h1>
          <p className="mt-5 text-base text-[#A7B4B8] leading-relaxed">
            Join leading enterprise data teams using DataFix to inspect, diagnose, repair, and certify datasets before they reach production warehouses and machine learning pipelines.
          </p>

          <div className="mt-8 space-y-3">
            <div className="flex items-center gap-3 text-sm text-[#F8FAFC]">
              <div className="w-5 h-5 rounded-full bg-[#00B8AD]/20 text-[#00B8AD] flex items-center justify-center">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Automated statistical anomaly & syntax defect detection</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-[#F8FAFC]">
              <div className="w-5 h-5 rounded-full bg-[#00B8AD]/20 text-[#00B8AD] flex items-center justify-center">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Deterministic & ML-driven transparent imputation algorithms</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-[#F8FAFC]">
              <div className="w-5 h-5 rounded-full bg-[#00B8AD]/20 text-[#00B8AD] flex items-center justify-center">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Immutable cryptographic audit trail for regulatory compliance</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 text-xs text-[#A7B4B8]">
          Enterprise-ready SOC2 & GDPR compliant data architecture.
        </div>
      </div>

      {/* Right side registration white card */}
      <div className="w-full lg:w-[480px] xl:w-[540px] flex items-center justify-center p-6 lg:p-12 z-20 bg-[#050B0B]">
        <div className="w-full max-w-md bg-white rounded-2xl p-8 lg:p-10 shadow-2xl border border-gray-100 text-[#111827]">
          <div className="mb-6">
            <h2 className="text-2xl font-bold tracking-tight text-[#111827]">
              Create Your Account
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              Start repairing datasets autonomously in minutes.
            </p>
          </div>

          {(localError || error) && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
              <span>{localError || error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Full Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Mercer"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Work Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex.mercer@organization.com"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Organization / Team
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Building2 className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  placeholder="Data Engineering Labs"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className="w-full pl-9 pr-9 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Password strength bar */}
              {password && (
                <div className="mt-2">
                  <div className="flex gap-1 h-1 w-full bg-gray-100 rounded-full overflow-hidden">
                    <div className={`h-full transition-all ${strengthScore >= 1 ? 'bg-red-500 w-1/4' : 'w-0'}`} />
                    <div className={`h-full transition-all ${strengthScore >= 2 ? 'bg-amber-500 w-1/4' : 'w-0'}`} />
                    <div className={`h-full transition-all ${strengthScore >= 3 ? 'bg-teal-400 w-1/4' : 'w-0'}`} />
                    <div className={`h-full transition-all ${strengthScore >= 4 ? 'bg-[#00B8AD] w-1/4' : 'w-0'}`} />
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                    <span>8+ characters</span>
                    <span>Numbers & symbols</span>
                    <span className="font-medium text-gray-600">
                      {strengthScore <= 1 && 'Weak'}
                      {strengthScore === 2 && 'Fair'}
                      {strengthScore === 3 && 'Good'}
                      {strengthScore === 4 && 'Strong'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat your password"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                  required
                />
              </div>
            </div>

            <div className="pt-1">
              <label className="flex items-start text-xs text-gray-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded border-gray-300 text-[#00B8AD] focus:ring-[#00B8AD]"
                />
                <span className="ml-2">
                  I agree to DataFix Terms of Service and Data Governance policies.
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-2.5 px-4 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-sm transition-all duration-200 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Creating Account...</span>
                </>
              ) : (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-500">
              Already have an account?{' '}
              <Link
                to="/login"
                className="font-semibold text-[#008F89] hover:text-[#00B8AD] hover:underline"
              >
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
