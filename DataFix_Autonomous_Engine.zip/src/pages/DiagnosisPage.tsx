import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  Cpu, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Sparkles, 
  FileText, 
  Search, 
  Filter,
  BarChart3,
  Layers
} from 'lucide-react';
import { DiagnosisEntry } from '../types/dataset';

export const DiagnosisPage: React.FC = () => {
  const navigate = useNavigate();
  const { diagnoses, activeDataset } = useData();

  const [selectedDiagnosis, setSelectedDiagnosis] = useState<DiagnosisEntry>(diagnoses[0]);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredDiagnoses = diagnoses.filter(d => 
    d.columnName.toLowerCase().includes(filterQuery.toLowerCase()) ||
    d.identifiedPattern.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Title & Capability Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <Cpu className="w-3.5 h-3.5" />
            <span>CAPABILITY: DIAGNOSE</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Root Cause Diagnosis Workspace
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Isolating upstream pipeline bugs, schema mismatches, and synthetic error sentinels through causal inference.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/repair')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
        >
          <span>Proceed to Data Repair Engine</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Main Diagnosis Split Workspace: Left Diagnosis Selector, Right Deep Dive (White Cards) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Diagnosed Issues List (4 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white rounded-2xl p-4 shadow-card-white border border-gray-100 text-[#111827]">
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Filter diagnosed issues..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
              />
            </div>

            <div className="space-y-2">
              {filteredDiagnoses.map((diag) => {
                const isSelected = selectedDiagnosis.id === diag.id;
                return (
                  <div
                    key={diag.id}
                    onClick={() => setSelectedDiagnosis(diag)}
                    className={`p-3.5 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-teal-50 border-[#00B8AD] shadow-sm'
                        : 'bg-white border-gray-100 hover:border-gray-200 hover:bg-gray-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <code className="text-xs font-mono font-bold text-gray-900">
                        {diag.columnName}
                      </code>
                      <span className="text-[10px] font-mono font-bold text-[#008F89]">
                        {diag.confidenceScore}% Confidence
                      </span>
                    </div>

                    <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed">
                      {diag.identifiedPattern}
                    </p>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-200/50 text-[10px]">
                      <span className="text-gray-500 font-medium">{diag.affectedRecords} records</span>
                      <span className={`font-semibold ${
                        diag.impactAssessment === 'High Risk' ? 'text-red-600' : 'text-amber-600'
                      }`}>
                        {diag.impactAssessment}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: In-depth Diagnosis Dossier (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827] space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-gray-900">
                  Diagnosis: <code>{selectedDiagnosis.columnName}</code>
                </h2>
                <span className="text-[10px] font-mono uppercase font-bold px-2 py-0.5 rounded bg-teal-50 text-[#008F89] border border-teal-200">
                  {selectedDiagnosis.category.replace('_', ' ')}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">
                Affecting {selectedDiagnosis.affectedRecords.toLocaleString()} rows in partition
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400 font-medium">Confidence:</span>
              <span className="text-sm font-extrabold font-mono text-[#008F89]">
                {selectedDiagnosis.confidenceScore}%
              </span>
            </div>
          </div>

          {/* 1. Identified Behavioral Pattern */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#00B8AD]" />
              <span>Identified Behavioral Pattern</span>
            </h3>
            <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs text-gray-800 leading-relaxed font-medium">
              {selectedDiagnosis.identifiedPattern}
            </div>
          </div>

          {/* 2. Observed Evidence vs Explanations (Clearly distinguished as required) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Observed Evidence */}
            <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-100 text-xs">
              <h4 className="font-bold text-[#008F89] mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4 text-[#00B8AD]" />
                <span>Empirical Evidence (Observed)</span>
              </h4>
              <ul className="space-y-2 mt-2">
                {selectedDiagnosis.observedEvidence.map((ev, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-gray-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00B8AD] mt-1.5 shrink-0" />
                    <span>{ev}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Possible Root Causes */}
            <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-100 text-xs">
              <h4 className="font-bold text-[#F59E0B] mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-[#F59E0B]" />
                <span>Probable Root Causes (Inferred)</span>
              </h4>
              <ul className="space-y-2 mt-2">
                {selectedDiagnosis.possibleRootCauses.map((cause, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-gray-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] mt-1.5 shrink-0" />
                    <span>{cause}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* 3. System Explanation & Recommended Correction Strategy */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#00B8AD]" />
              <span>Autonomous System Synthesis</span>
            </h3>
            <p className="text-xs text-gray-700 leading-relaxed p-4 rounded-xl bg-gray-50 border border-gray-200">
              {selectedDiagnosis.systemExplanation}
            </p>
          </div>

          {/* Action Trigger */}
          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={() => navigate('/repair')}
              className="px-4 py-2.5 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <span>View Recommended Repairs for this Issue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
