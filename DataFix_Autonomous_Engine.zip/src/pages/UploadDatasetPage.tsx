import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ArrowRight, 
  Database, 
  FileSpreadsheet, 
  ShieldCheck, 
  RefreshCw 
} from 'lucide-react';
import { DatasetItem } from '../types/dataset';

type FormatType = 'csv' | 'excel' | 'parquet_json' | 'auto';

export const UploadDatasetPage: React.FC = () => {
  const navigate = useNavigate();
  const { uploadDatasetFile, refreshDatasets } = useData();

  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<FormatType>('auto');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [uploadedDataset, setUploadedDataset] = useState<DatasetItem | null>(null);

  // Dedicated file inputs for general browse and specific format cards
  const genericInputRef = useRef<HTMLInputElement | null>(null);
  const csvInputRef = useRef<HTMLInputElement | null>(null);
  const excelInputRef = useRef<HTMLInputElement | null>(null);
  const parquetJsonInputRef = useRef<HTMLInputElement | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!isUploading) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (isUploading) return;

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0], 'auto');
    }
  };

  const validateAndSetFile = (file: File, formatHint: FormatType = 'auto') => {
    setErrorMessage(null);
    setUploadComplete(false);
    setUploadProgress(0);
    setUploadedDataset(null);

    // 1. Empty file validation
    if (!file || file.size === 0) {
      setErrorMessage('The selected file is empty (0 bytes). Please choose a valid dataset.');
      setSelectedFile(null);
      return;
    }

    // 2. File size limit validation (50MB)
    if (file.size > 50 * 1024 * 1024) {
      setErrorMessage(`File size (${(file.size / (1024 * 1024)).toFixed(2)} MB) exceeds the 50MB hackathon limit. Please upload a smaller partition.`);
      setSelectedFile(null);
      return;
    }

    const fileName = file.name.toLowerCase();

    // 3. Extension validation based on triggered format option
    if (formatHint === 'csv') {
      const isCsv = fileName.endsWith('.csv') || fileName.endsWith('.tsv') || fileName.endsWith('.txt');
      if (!isCsv) {
        setErrorMessage('Invalid file format. "CSV & Delimited" option accepts .csv, .tsv, and .txt files only.');
        setSelectedFile(null);
        return;
      }
    } else if (formatHint === 'excel') {
      const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');
      if (!isExcel) {
        setErrorMessage('Invalid file format. "Excel Workbooks" option accepts .xlsx and .xls files only.');
        setSelectedFile(null);
        return;
      }
    } else if (formatHint === 'parquet_json') {
      const isParquetOrJson = fileName.endsWith('.parquet') || fileName.endsWith('.json');
      if (!isParquetOrJson) {
        setErrorMessage('Invalid file format. "Parquet & JSON" option accepts .parquet and .json files only.');
        setSelectedFile(null);
        return;
      }
    } else {
      // General drag & drop / browse check
      const validExtensions = ['.csv', '.tsv', '.txt', '.xlsx', '.xls', '.json', '.parquet'];
      const isValid = validExtensions.some(ext => fileName.endsWith(ext));
      if (!isValid) {
        setErrorMessage('Unsupported file format. Please upload a valid CSV, Excel (.xlsx/.xls), Parquet, or JSON dataset.');
        setSelectedFile(null);
        return;
      }
    }

    setSelectedFormat(formatHint);
    setSelectedFile(file);
  };

  const handleFormatCardClick = (format: FormatType) => {
    if (isUploading) return;
    setErrorMessage(null);

    if (format === 'csv') {
      csvInputRef.current?.click();
    } else if (format === 'excel') {
      excelInputRef.current?.click();
    } else if (format === 'parquet_json') {
      parquetJsonInputRef.current?.click();
    }
  };

  const handleRemoveFile = () => {
    if (isUploading) return;
    setSelectedFile(null);
    setUploadProgress(0);
    setIsUploading(false);
    setUploadComplete(false);
    setErrorMessage(null);
    setUploadedDataset(null);
    if (genericInputRef.current) genericInputRef.current.value = '';
    if (csvInputRef.current) csvInputRef.current.value = '';
    if (excelInputRef.current) excelInputRef.current.value = '';
    if (parquetJsonInputRef.current) parquetJsonInputRef.current.value = '';
  };

  const handleStartUpload = async () => {
    if (!selectedFile || isUploading) return;

    setIsUploading(true);
    setErrorMessage(null);
    setUploadProgress(15);

    // Progress simulation while awaiting actual backend response
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev < 85) {
          return prev + Math.floor(Math.random() * 15) + 5;
        }
        return prev;
      });
    }, 200);

    try {
      // Submit upload through backend API integration
      const newDataset = await uploadDatasetFile(selectedFile, selectedFormat);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setUploadComplete(true);
      setUploadedDataset(newDataset);
      await refreshDatasets();
    } catch (err: any) {
      clearInterval(progressInterval);
      setUploadProgress(0);
      setUploadComplete(false);
      setErrorMessage(
        err.message || 'Upload failed. The backend service was unable to parse or validate this dataset.'
      );
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
          <Database className="w-3.5 h-3.5" />
          <span>INGESTION PIPELINE</span>
        </div>
        <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
          Upload Dataset for Autonomous Inspection
        </h1>
        <p className="text-sm text-[#A7B4B8] mt-1">
          Drop your raw tabular dataset to initiate automated schema inference, anomaly profiling, and repair generation.
        </p>
      </div>

      {/* Main Upload Card (Pure White Card) */}
      <div className="bg-white rounded-2xl p-6 lg:p-10 shadow-card-white border border-gray-100 text-[#111827]">
        {/* Hidden File Inputs */}
        <input
          ref={genericInputRef}
          type="file"
          accept=".csv,.tsv,.txt,.xlsx,.xls,.json,.parquet"
          onChange={(e) => e.target.files?.[0] && validateAndSetFile(e.target.files[0], 'auto')}
          className="hidden"
        />
        <input
          ref={csvInputRef}
          type="file"
          accept=".csv,.tsv,.txt"
          onChange={(e) => e.target.files?.[0] && validateAndSetFile(e.target.files[0], 'csv')}
          className="hidden"
        />
        <input
          ref={excelInputRef}
          type="file"
          accept=".xlsx,.xls"
          onChange={(e) => e.target.files?.[0] && validateAndSetFile(e.target.files[0], 'excel')}
          className="hidden"
        />
        <input
          ref={parquetJsonInputRef}
          type="file"
          accept=".parquet,.json"
          onChange={(e) => e.target.files?.[0] && validateAndSetFile(e.target.files[0], 'parquet_json')}
          className="hidden"
        />

        {/* Drag and Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => !isUploading && genericInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-8 lg:p-12 text-center transition-all duration-200 ${
            isUploading
              ? 'border-gray-200 bg-gray-50 cursor-not-allowed opacity-75'
              : isDragging
              ? 'border-[#00B8AD] bg-[#BFF8F0]/20 cursor-pointer'
              : selectedFile
              ? 'border-gray-300 bg-gray-50 cursor-pointer'
              : 'border-gray-300 hover:border-[#00B8AD] hover:bg-gray-50/60 cursor-pointer'
          }`}
        >
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-teal-50 text-[#008F89] flex items-center justify-center shadow-sm">
            <UploadCloud className="w-8 h-8 text-[#00B8AD]" />
          </div>

          <h3 className="text-base font-bold text-gray-900">
            {isDragging ? 'Drop your dataset here' : 'Drag & drop dataset or click to browse'}
          </h3>

          <p className="text-xs text-gray-500 mt-2 max-w-md mx-auto">
            Supports CSV & Delimited, Excel Workbooks (.xlsx/.xls), Parquet, and JSON formats. Up to 50MB files processed with zero data loss.
          </p>

          <button
            type="button"
            disabled={isUploading}
            className="mt-5 px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold transition-colors shadow-sm inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#008F89]" />
            <span>Select Local File</span>
          </button>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="mt-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-[#EF4444] shrink-0" />
              <span className="font-medium">{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="p-1 text-red-500 hover:text-red-800"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Selected File Details Bar */}
        {selectedFile && (
          <div className="mt-6 p-4 rounded-xl bg-gray-50 border border-gray-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#BFF8F0]/40 text-[#008F89] flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-gray-900 truncate">{selectedFile.name}</p>
                  <p className="text-[11px] text-gray-500">
                    {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • {selectedFormat.toUpperCase()} Format Mode
                  </p>
                </div>
              </div>

              {!isUploading && !uploadComplete && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                    title="Remove selected file"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    disabled={isUploading}
                    onClick={handleStartUpload}
                    className="px-4 py-2 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Run Autonomous Inspection</span>
                  </button>
                </div>
              )}
            </div>

            {/* Progress bar during upload */}
            {isUploading && (
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-gray-700 flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 text-[#00B8AD] animate-spin" />
                    Uploading to backend and parsing schema...
                  </span>
                  <span className="font-mono font-bold text-[#008F89]">{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#00B8AD] transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Upload Complete Success State */}
            {uploadComplete && uploadedDataset && (
              <div className="mt-4 pt-3 border-t border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs text-[#16A36A] font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Dataset "{uploadedDataset.name}" verified: {uploadedDataset.rowCount?.toLocaleString()} records and {uploadedDataset.columnCount} columns indexed.
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-100 text-xs font-medium cursor-pointer"
                  >
                    Upload Another
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('/inspector')}
                    className="px-4 py-1.5 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                  >
                    <span>Inspect In Workspace</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Target Format Options Cards (Fully Functional Clickable Handlers) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Format 1: CSV & Delimited */}
        <div 
          onClick={() => handleFormatCardClick('csv')}
          className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 hover:border-[#00B8AD] text-[#111827] cursor-pointer group transition-all flex flex-col justify-between"
          role="button"
          tabIndex={0}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#008F89] flex items-center justify-center group-hover:bg-[#00B8AD] group-hover:text-black transition-colors">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono font-bold text-gray-400 group-hover:text-[#00B8AD] transition-colors">
                CLICK TO UPLOAD
              </span>
            </div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider group-hover:text-[#008F89] transition-colors">
              CSV & Delimited
            </h4>
            <p className="text-xs text-gray-500 mt-1">
              Supports standard comma, tab, or pipe-separated UTF-8 files. Autonomous header, dialect, and delimiter inference.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
            <span className="text-[11px] font-semibold text-[#008F89] flex items-center gap-1">
              <span>Select CSV file</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-gray-400 font-mono">.csv, .tsv, .txt</span>
          </div>
        </div>

        {/* Format 2: Excel Workbooks */}
        <div 
          onClick={() => handleFormatCardClick('excel')}
          className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 hover:border-[#00B8AD] text-[#111827] cursor-pointer group transition-all flex flex-col justify-between"
          role="button"
          tabIndex={0}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#008F89] flex items-center justify-center group-hover:bg-[#00B8AD] group-hover:text-black transition-colors">
                <Database className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono font-bold text-gray-400 group-hover:text-[#00B8AD] transition-colors">
                CLICK TO UPLOAD
              </span>
            </div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider group-hover:text-[#008F89] transition-colors">
              Excel Workbooks
            </h4>
            <p className="text-xs text-gray-500 mt-1">
              Multi-sheet XLSX and XLS files. Cleans corrupted date serials, formula errors (#N/A, #REF!), and formatting traps.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
            <span className="text-[11px] font-semibold text-[#008F89] flex items-center gap-1">
              <span>Select Excel file</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-gray-400 font-mono">.xlsx, .xls</span>
          </div>
        </div>

        {/* Format 3: Parquet & JSON */}
        <div 
          onClick={() => handleFormatCardClick('parquet_json')}
          className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 hover:border-[#00B8AD] text-[#111827] cursor-pointer group transition-all flex flex-col justify-between"
          role="button"
          tabIndex={0}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#008F89] flex items-center justify-center group-hover:bg-[#00B8AD] group-hover:text-black transition-colors">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono font-bold text-gray-400 group-hover:text-[#00B8AD] transition-colors">
                CLICK TO UPLOAD
              </span>
            </div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider group-hover:text-[#008F89] transition-colors">
              Parquet & JSON
            </h4>
            <p className="text-xs text-gray-500 mt-1">
              Columnar high-throughput Parquet files with snappy compression, or newline-delimited JSON for Lakehouse ingestion.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
            <span className="text-[11px] font-semibold text-[#008F89] flex items-center gap-1">
              <span>Select Parquet/JSON file</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-gray-400 font-mono">.parquet, .json</span>
          </div>
        </div>
      </div>
    </div>
  );
};
