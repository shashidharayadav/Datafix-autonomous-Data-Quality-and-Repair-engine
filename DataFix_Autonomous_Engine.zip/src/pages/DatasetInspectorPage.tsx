import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { 
  Table, 
  Search, 
  SlidersHorizontal, 
  ChevronDown, 
  ChevronUp, 
  ArrowUpDown, 
  Filter, 
  Info, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight,
  Database,
  Layers
} from 'lucide-react';

export const DatasetInspectorPage: React.FC = () => {
  const { activeDataset } = useData();

  const [activeTab, setActiveTab] = useState<'preview' | 'columns'>('preview');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState<string>('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;

  const rawRows = activeDataset.rawRows || [];
  const columns = activeDataset.columns || [];

  // Filter rows
  const filteredRows = rawRows.filter(row => {
    if (!searchTerm.trim()) return true;
    return Object.values(row).some(val => 
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Sort rows
  const sortedRows = [...filteredRows].sort((a, b) => {
    const valA = a[sortColumn];
    const valB = b[sortColumn];
    if (valA === valB) return 0;
    if (valA === null || valA === undefined) return 1;
    if (valB === null || valB === undefined) return -1;
    if (sortDirection === 'asc') {
      return valA > valB ? 1 : -1;
    }
    return valA < valB ? 1 : -1;
  });

  // Pagination
  const totalPages = Math.ceil(sortedRows.length / rowsPerPage) || 1;
  const paginatedRows = sortedRows.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const handleSort = (colName: string) => {
    if (sortColumn === colName) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColumn(colName);
      setSortDirection('asc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Breadcrumb */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
          <Database className="w-3.5 h-3.5" />
          <span>INSPECTOR WORKSPACE</span>
        </div>
        <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
          Dataset Inspector & Profiler
        </h1>
        <p className="text-sm text-[#A7B4B8] mt-1">
          Explore data distributions, schema taxonomy, null cardinality, and underlying record matrices.
        </p>
      </div>

      {/* 1. DATASET SUMMARY METRICS (White Card) */}
      <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-gray-100">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#111827]">{activeDataset.name}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-50 text-[#008F89] font-bold border border-teal-200">
                {activeDataset.format}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              File Size: {activeDataset.fileSize} • Uploaded {activeDataset.uploadedAt}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 font-medium">Dataset Status:</span>
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-[#F59E0B] border border-amber-200 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{activeDataset.status}</span>
            </span>
          </div>
        </div>

        {/* 4 Summary Mini Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
          <div className="p-3.5 rounded-xl bg-gray-50 border border-gray-100">
            <span className="text-xs text-gray-500 font-medium">Total Records</span>
            <div className="text-xl font-bold text-gray-900 mt-0.5">
              {activeDataset.rowCount.toLocaleString()}
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-gray-50 border border-gray-100">
            <span className="text-xs text-gray-500 font-medium">Total Columns</span>
            <div className="text-xl font-bold text-gray-900 mt-0.5">
              {activeDataset.columnCount}
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-gray-50 border border-gray-100">
            <span className="text-xs text-gray-500 font-medium">Quality Score</span>
            <div className="text-xl font-bold text-[#008F89] mt-0.5">
              {activeDataset.qualityScoreBefore}%
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-gray-50 border border-gray-100">
            <span className="text-xs text-gray-500 font-medium">Detected Anomalies</span>
            <div className="text-xl font-bold text-[#EF4444] mt-0.5">
              {activeDataset.issuesCount}
            </div>
          </div>
        </div>
      </div>

      {/* Tab Switcher: Dataset Preview vs Column Health */}
      <div className="flex items-center gap-2 border-b border-[#26383A] pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('preview')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'preview'
              ? 'bg-[#00B8AD] text-black shadow-teal-sm'
              : 'text-[#A7B4B8] hover:text-white hover:bg-[#080F12]'
          }`}
        >
          <Table className="w-4 h-4" />
          <span>Interactive Preview Matrix ({rawRows.length} sample rows)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('columns')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'columns'
              ? 'bg-[#00B8AD] text-black shadow-teal-sm'
              : 'text-[#A7B4B8] hover:text-white hover:bg-[#080F12]'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Column-Level Profiler ({columns.length} columns)</span>
        </button>
      </div>

      {/* 2. TAB 1: DATASET PREVIEW TABLE (White Table) */}
      {activeTab === 'preview' && (
        <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
          {/* Controls: Search, Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
            <div className="relative w-full sm:w-72">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                <Search className="w-3.5 h-3.5" />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Filter table rows..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
              />
            </div>

            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span>Showing {paginatedRows.length} of {filteredRows.length} records</span>
            </div>
          </div>

          {/* Table Container */}
          <div className="mt-4 overflow-x-auto table-scrollbar">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                  {Object.keys(rawRows[0] || {}).map((col) => (
                    <th
                      key={col}
                      onClick={() => handleSort(col)}
                      className="pb-3 px-3 cursor-pointer hover:text-gray-700 whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1">
                        <span>{col}</span>
                        <ArrowUpDown className="w-3 h-3 text-gray-300" />
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 font-mono">
                {paginatedRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/80 transition-colors">
                    {Object.entries(row).map(([k, val], cIdx) => {
                      const isNull = val === null || val === undefined;
                      const isAnomaly = typeof val === 'number' && val < 0;
                      const isDateError = String(val).includes('invalid');

                      return (
                        <td key={cIdx} className="py-2.5 px-3 whitespace-nowrap text-gray-800">
                          {isNull ? (
                            <span className="px-1.5 py-0.5 rounded bg-red-100 text-red-700 text-[10px] font-bold">
                              null
                            </span>
                          ) : isAnomaly ? (
                            <span className="px-1.5 py-0.5 rounded bg-red-100 text-red-700 font-bold">
                              {String(val)}
                            </span>
                          ) : isDateError ? (
                            <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">
                              {String(val)}
                            </span>
                          ) : (
                            String(val)
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="flex items-center justify-between pt-4 mt-2 border-t border-gray-100 text-xs">
            <span className="text-gray-500">
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
                className="px-2.5 py-1 rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="px-2.5 py-1 rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. TAB 2: COLUMN-LEVEL INFORMATION (White Table with Health Diagnostics) */}
      {activeTab === 'columns' && (
        <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
          <div className="pb-4 border-b border-gray-100">
            <h3 className="text-base font-bold text-gray-900">Column Health & Profiling</h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Detailed breakdown of data types, missing value ratios, and cardinality distribution
            </p>
          </div>

          <div className="mt-4 overflow-x-auto table-scrollbar">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="pb-3 pr-4">Column Name</th>
                  <th className="pb-3 px-3">Data Type</th>
                  <th className="pb-3 px-3">Missing Count</th>
                  <th className="pb-3 px-3">Missing Ratio</th>
                  <th className="pb-3 px-3">Unique Values</th>
                  <th className="pb-3 px-3">Duplicate Key</th>
                  <th className="pb-3 pl-3 text-right">Health Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 font-mono">
                {columns.map((col, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/80 transition-colors">
                    <td className="py-3 pr-4 font-semibold text-gray-900">
                      {col.name}
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 text-[10px] uppercase font-bold">
                        {col.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-gray-700">
                      {col.missingCount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${col.missingPercentage > 0.5 ? 'bg-red-500' : 'bg-[#00B8AD]'}`}
                            style={{ width: `${Math.min(col.missingPercentage * 20, 100)}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-gray-500">{col.missingPercentage}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-gray-700">
                      {col.uniqueCount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      {col.hasDuplicates ? (
                        <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          Duplicates Found
                        </span>
                      ) : (
                        <span className="text-[10px] text-gray-400">Unique</span>
                      )}
                    </td>
                    <td className="py-3 pl-3 text-right">
                      {col.status === 'clean' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#16A36A] bg-green-50 px-2 py-0.5 rounded border border-green-200">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Optimal</span>
                        </span>
                      ) : col.status === 'warning' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#F59E0B] bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Review</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#EF4444] bg-red-50 px-2 py-0.5 rounded border border-red-200">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Critical</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
