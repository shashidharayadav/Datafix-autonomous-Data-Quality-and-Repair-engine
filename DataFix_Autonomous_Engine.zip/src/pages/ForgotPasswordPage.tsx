import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ParallaxCanvas } from '../components/auth/ParallaxCanvas';
import { ShieldCheck, Mail, ArrowLeft, CheckCircle2, AlertCircle, Send } from 'lucide-react';

export const ForgotPasswordPage: React.FC = () => {
  const { forgotPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setErrorMessage('Please enter a valid account email address.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await forgotPassword(email);
      setSuccessMessage(res.message);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Could not send reset link. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col lg:flex-row bg-[#050B0B] text-[#F8FAFC] overflow-hidden">
      {/* Left side brand */}
      <div className="relative flex-1 flex flex-col justify-between p-8 lg:p-14 z-10 border-b lg:border-b-0 lg:border-r border-[#26383A]/60">
        <ParallaxCanvas />

        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#00B8AD] to-[#008F89] p-0.5 shadow-teal-glow flex items-center justify-center">
              <div className="w-full h-full bg-[#080F12] rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-[#00B8AD]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-extrabold tracking-wider text-white">DATAFIX</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#00B8AD]/15 text-[#00B8AD] border border-[#00B8AD]/30">
                  RECOVERY
                </span>
              </div>
              <p className="text-xs font-medium tracking-widest text-[#00B8AD] uppercase">
                Clean. Trust. Grow.
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 max-w-xl my-8 lg:my-auto">
          <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Security & <br />
            <span className="bg-gradient-to-r from-[#00B8AD] via-[#BFF8F0] to-[#00B8AD] bg-clip-text text-transparent">
              Access Recovery.
            </span>
          </h1>
          <p className="mt-5 text-base text-[#A7B4B8] leading-relaxed">
            DataFix safeguards mission-critical datasets with granular RBAC access controls. Follow the automated recovery procedure to regain access to your verified workstation.
          </p>
        </div>

        <div className="relative z-10 text-xs text-[#A7B4B8]">
          Encrypted token dispatched via enterprise auth gateway.
        </div>
      </div>

      {/* Right side white card */}
      <div className="w-full lg:w-[480px] xl:w-[540px] flex items-center justify-center p-6 lg:p-12 z-20 bg-[#050B0B]">
        <div className="w-full max-w-md bg-white rounded-2xl p-8 lg:p-10 shadow-2xl border border-gray-100 text-[#111827]">
          <div className="mb-6">
            <Link
              to="/login"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#008F89] hover:text-[#00B8AD] mb-4 group"
            >
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              <span>Back to Login</span>
            </Link>
            <h2 className="text-2xl font-bold tracking-tight text-[#111827]">
              Reset Password
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              Enter your corporate email address to receive a secure password reset link.
            </p>
          </div>

          {errorMessage && (
            <div className="mb-4 p-3.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-[#008F89] text-xs flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#00B8AD] shrink-0" />
                <div className="leading-relaxed">
                  <p className="font-semibold text-gray-900 mb-1">Reset Instructions Sent</p>
                  <p>{successMessage}</p>
                </div>
              </div>

              <p className="text-xs text-gray-500 text-center">
                Didn't receive an email? Check your spam folder or try again in 60 seconds.
              </p>

              <button
                type="button"
                onClick={() => setSuccessMessage(null)}
                className="w-full py-2.5 px-4 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium text-xs transition-colors"
              >
                Resend to another email
              </button>

              <Link
                to="/login"
                className="block text-center text-xs font-semibold text-[#00B8AD] hover:underline pt-2"
              >
                Return to Login Page
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">
                  Account Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@company.com"
                    className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 py-3 px-4 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-sm transition-all duration-200 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>Transmitting Token...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Reset Link</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
