import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ParallaxCanvas } from '../components/auth/ParallaxCanvas';
import { 
  ShieldCheck, 
  Database, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Zap,
  Activity
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isLoading, error, clearError } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [localError, setLocalError] = useState<string | null>(null);

  // Redirect to requested protected path if available
  const from = (location.state as any)?.from?.pathname || '/overview';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    if (!email.trim()) {
      setLocalError('Please enter your work email address.');
      return;
    }
    if (!password) {
      setLocalError('Please enter your password.');
      return;
    }

    try {
      await login({ email, password, rememberMe });
      navigate(from, { replace: true });
    } catch (err: any) {
      setLocalError(err?.message || 'Invalid email or password.');
    }
  };

  const handleQuickFill = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setLocalError(null);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col lg:flex-row bg-[#050B0B] text-[#F8FAFC] overflow-hidden">
      {/* LEFT SECTION: Brand, Taglines & Interactive Parallax Canvas */}
      <div className="relative flex-1 flex flex-col justify-between p-8 lg:p-14 z-10 overflow-hidden border-b lg:border-b-0 lg:border-r border-[#26383A]/60">
        {/* Parallax background canvas reacting to mouse movements */}
        <ParallaxCanvas />

        {/* Content Layer over Parallax */}
        <div className="relative z-10">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#00B8AD] to-[#008F89] p-0.5 shadow-teal-glow flex items-center justify-center">
              <div className="w-full h-full bg-[#080F12] rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-[#00B8AD]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-extrabold tracking-wider text-white">DATAFIX</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#00B8AD]/15 text-[#00B8AD] border border-[#00B8AD]/30">
                  AUTONOMOUS v2.4
                </span>
              </div>
              <p className="text-xs font-medium tracking-widest text-[#00B8AD] uppercase">
                Clean. Trust. Grow.
              </p>
            </div>
          </div>
        </div>

        {/* Hero Narrative on Left */}
        <div className="relative z-10 max-w-xl my-8 lg:my-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#080F12]/80 border border-[#26383A] text-xs text-[#A7B4B8] mb-6 backdrop-blur-md">
            <Activity className="w-3.5 h-3.5 text-[#00B8AD] animate-pulse" />
            <span>Autonomous Data Quality & Repair Engine</span>
          </div>

          <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Make Your Data <br />
            <span className="bg-gradient-to-r from-[#00B8AD] via-[#BFF8F0] to-[#00B8AD] bg-clip-text text-transparent">
              Trustworthy.
            </span>
          </h1>

          <p className="mt-5 text-base lg:text-lg text-[#A7B4B8] leading-relaxed">
            Eliminate hours of manual data wrangling. DataFix autonomously detects statistical anomalies, 
            diagnoses root causes, recommends transparent repairs, validates schema constraints, and audits every change.
          </p>

          {/* Interactive Live Metrics Badges */}
          <div className="grid grid-cols-3 gap-3 mt-8">
            <div className="p-3.5 rounded-xl bg-[#080F12]/70 border border-[#26383A] backdrop-blur-sm">
              <div className="text-2xl font-bold text-white">99.8%</div>
              <div className="text-xs text-[#A7B4B8] mt-0.5">Post-Repair Health</div>
            </div>
            <div className="p-3.5 rounded-xl bg-[#080F12]/70 border border-[#26383A] backdrop-blur-sm">
              <div className="text-2xl font-bold text-[#00B8AD]">6 Core</div>
              <div className="text-xs text-[#A7B4B8] mt-0.5">Engine Modules</div>
            </div>
            <div className="p-3.5 rounded-xl bg-[#080F12]/70 border border-[#26383A] backdrop-blur-sm">
              <div className="text-2xl font-bold text-white">0-Loss</div>
              <div className="text-xs text-[#A7B4B8] mt-0.5">Audit Lineage</div>
            </div>
          </div>
        </div>

        {/* Footer info & interactive mouse prompt */}
        <div className="relative z-10 flex flex-wrap items-center justify-between text-xs text-[#A7B4B8] pt-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#16A36A] animate-ping" />
            <span>Core AI Verification Engine: Online</span>
          </div>
          <div className="text-xs text-[#A7B4B8]/70 hidden sm:block">
            Move mouse to interact with 3D neural data grid
          </div>
        </div>
      </div>

      {/* RIGHT SECTION: Pure White Login Card */}
      <div className="w-full lg:w-[480px] xl:w-[540px] flex items-center justify-center p-6 lg:p-12 z-20 bg-[#050B0B]">
        <div className="w-full max-w-md bg-white rounded-2xl p-8 lg:p-10 shadow-2xl border border-gray-100 text-[#111827]">
          {/* Header */}
          <div className="mb-6">
            <h2 className="text-2xl lg:text-3xl font-bold tracking-tight text-[#111827]">
              Welcome Back
            </h2>
            <p className="text-sm text-gray-500 mt-1.5">
              Sign in to manage and repair your mission-critical datasets.
            </p>
          </div>

          {/* Quick Demo Pre-fill for Hackathon Judges */}
          <div className="mb-6 p-3 rounded-xl bg-[#BFF8F0]/30 border border-[#00B8AD]/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#008F89] flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#00B8AD]" />
                Hackathon Judge 1-Click Access:
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleQuickFill('lead.engineer@datafix.ai', 'DataFix@2026')}
                className="text-xs font-medium px-2.5 py-1 rounded-md bg-white text-gray-700 hover:text-[#008F89] border border-gray-200 hover:border-[#00B8AD] transition-all shadow-sm flex items-center gap-1"
              >
                Lead Engineer Auto-fill
              </button>
              <button
                type="button"
                onClick={() => handleQuickFill('demo.analyst@datafix.ai', 'Passcode#2026')}
                className="text-xs font-medium px-2.5 py-1 rounded-md bg-white text-gray-700 hover:text-[#008F89] border border-gray-200 hover:border-[#00B8AD] transition-all shadow-sm"
              >
                Data Analyst
              </button>
            </div>
          </div>

          {/* Error Banner */}
          {(localError || error) && (
            <div className="mb-5 p-3.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
              <span>{localError || error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">
                Work Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white transition-all"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Password
                </label>
                <Link
                  to="/forgot-password"
                  className="text-xs font-medium text-[#008F89] hover:text-[#00B8AD] hover:underline"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-10 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00B8AD] focus:bg-white transition-all"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center text-xs text-gray-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-[#00B8AD] focus:ring-[#00B8AD] focus:ring-offset-0"
                />
                <span className="ml-2">Remember this workstation</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-3 px-4 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-sm transition-all duration-200 shadow-md hover:shadow-teal-sm flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Authenticating Session...</span>
                </>
              ) : (
                <>
                  <span>Sign In to DataFix</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </>
              )}
            </button>
          </form>

          {/* Registration link */}
          <div className="mt-6 pt-5 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-500">
              New to DataFix?{' '}
              <Link
                to="/register"
                className="font-semibold text-[#008F89] hover:text-[#00B8AD] hover:underline"
              >
                Create an engineer account
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
