import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  Sparkles, 
  HelpCircle, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Search, 
  Check, 
  Info,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export const ExplainabilityPage: React.FC = () => {
  const navigate = useNavigate();
  const { explainability, activeDataset } = useData();

  const [selectedRecord, setSelectedRecord] = useState(explainability[0]);
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = explainability.filter(e => 
    e.columnName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.algorithmName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.issueType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Title & Capability Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <Sparkles className="w-3.5 h-3.5" />
            <span>CAPABILITY: EXPLAIN</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Transparent Explainability Engine
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Zero black-box decisions. Mathematical proofs, covariate weights, and algorithmic rationale for every mutation.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/audit')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
        >
          <span>View Audit History Trail</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Main Split Layout: Left Record Selectors, Right Full Transparent Breakdown (White Cards) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white rounded-2xl p-4 shadow-card-white border border-gray-100 text-[#111827]">
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search explainability cases..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
              />
            </div>

            <div className="space-y-2">
              {filtered.map((item) => {
                const isSelected = selectedRecord.id === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => setSelectedRecord(item)}
                    className={`p-3.5 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-teal-50 border-[#00B8AD] shadow-sm'
                        : 'bg-white border-gray-100 hover:border-gray-200 hover:bg-gray-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-gray-900">
                        Record #{item.recordId} • <code>{item.columnName}</code>
                      </span>
                      <span className="text-[10px] font-mono font-bold text-[#008F89]">
                        {item.confidenceScore}% Trust
                      </span>
                    </div>

                    <div className="text-[11px] text-gray-600 line-clamp-1">
                      {item.algorithmName}
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-200/50 text-[10px]">
                      <span className="text-red-600 line-through truncate max-w-[80px]">
                        {String(item.originalValue)}
                      </span>
                      <span className="text-[#16A36A] font-bold truncate max-w-[120px]">
                        → {String(item.newValue)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Deep Rationale Dossier (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827] space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-gray-900">
                  Decision Breakdown: Record #{selectedRecord.recordId}
                </h2>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">
                Target Attribute: <code>{selectedRecord.columnName}</code> • Defect: {selectedRecord.issueType}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400 font-medium">Confidence Score:</span>
              <span className="text-sm font-extrabold font-mono text-[#008F89]">
                {selectedRecord.confidenceScore}%
              </span>
            </div>
          </div>

          {/* Before & After Diff Card */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-red-50/70 border border-red-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-red-600">
                Original Corrupted Value
              </span>
              <div className="text-base font-mono font-bold text-red-700 mt-1">
                {String(selectedRecord.originalValue)}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-green-50/70 border border-green-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#16A36A]">
                Autonomously Calibrated Value
              </span>
              <div className="text-base font-mono font-bold text-[#16A36A] mt-1">
                {String(selectedRecord.newValue)}
              </div>
            </div>
          </div>

          {/* Algorithmic Model Rationale */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#00B8AD]" />
              <span>Algorithmic Selection: {selectedRecord.algorithmName}</span>
            </h3>
            <p className="text-xs text-gray-700 p-4 rounded-xl bg-gray-50 border border-gray-200 leading-relaxed font-medium">
              {selectedRecord.whyChosen}
            </p>
          </div>

          {/* Supporting Evidence Breakdown */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00B8AD]" />
              <span>Covariate Evidence & Empirical Proof</span>
            </h3>
            <div className="space-y-2">
              {selectedRecord.supportingEvidence.map((ev, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 rounded-lg bg-teal-50/40 border border-teal-100 text-xs text-gray-800">
                  <Check className="w-4 h-4 text-[#00B8AD] shrink-0 mt-0.5" />
                  <span>{ev}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Rejected Counterfactual Options (Demonstrating true explainability) */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-gray-400" />
              <span>Alternative Hypotheses Evaluated & Discarded</span>
            </h3>
            <div className="space-y-2">
              {selectedRecord.alternativeOptions.map((alt, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-gray-50 border border-gray-200 text-xs">
                  <div className="flex items-center justify-between text-gray-700 font-semibold mb-1">
                    <span>{alt.method}</span>
                    <span className="text-[10px] text-gray-400 font-mono">Score: {alt.score}%</span>
                  </div>
                  <p className="text-[11px] text-gray-500">
                    Why Not Chosen: {alt.whyNotChosen}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
