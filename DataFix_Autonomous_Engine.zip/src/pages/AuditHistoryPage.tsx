import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  History, 
  Search, 
  Filter, 
  ArrowUpDown, 
  ShieldCheck, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  ArrowRight,
  Clock,
  Layers,
  CheckCircle2
} from 'lucide-react';

export const AuditHistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const { auditLogs, activeDataset } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;

  const filteredLogs = auditLogs.filter((log) => {
    if (actionFilter !== 'all' && log.action !== actionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        log.columnName.toLowerCase().includes(q) ||
        log.recordIdentifier.toString().toLowerCase().includes(q) ||
        log.repairMethod.toLowerCase().includes(q) ||
        log.operator.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalPages = Math.ceil(filteredLogs.length / rowsPerPage) || 1;
  const paginatedLogs = filteredLogs.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const handleExportAuditTrail = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      ["Timestamp,Dataset,Record,Column,Original,Updated,Method,Action,Operator,Status"]
      .concat(auditLogs.map(l => `"${l.timestamp}","${l.datasetName}","${l.recordIdentifier}","${l.columnName}","${l.originalValue}","${l.updatedValue}","${l.repairMethod}","${l.action}","${l.operator}","${l.status}"`))
      .join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `DataFix_Audit_Lineage_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Title & Capability Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <History className="w-3.5 h-3.5" />
            <span>CAPABILITY: TRACK</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Immutable Audit History & Lineage
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Complete cryptographic audit trail recording every state change, algorithm execution, and engineer approval.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportAuditTrail}
            className="px-4 py-2 rounded-xl bg-[#080F12] hover:bg-[#0B1519] text-white border border-[#26383A] font-semibold text-xs transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#00B8AD]" />
            <span>Export Audit Trail (CSV)</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('/reports')}
            className="px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <span>Generate Executive Report</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Audit Table Container (Pure White Card) */}
      <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search audit trail by column, operator, method..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400 font-medium">Filter Action:</span>
            <select
              value={actionFilter}
              onChange={(e) => {
                setActionFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            >
              <option value="all">All Actions ({auditLogs.length})</option>
              <option value="Auto-Repair">Auto-Repair</option>
              <option value="Manual Approval">Manual Approval</option>
              <option value="Bulk Patch">Bulk Patch</option>
              <option value="Rejection">Rejection</option>
            </select>
          </div>
        </div>

        {/* Audit Log Table */}
        <div className="mt-4 overflow-x-auto table-scrollbar">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="pb-3 pr-3">Timestamp (UTC)</th>
                <th className="pb-3 px-3">Record Identifier</th>
                <th className="pb-3 px-3">Column</th>
                <th className="pb-3 px-3">Original Value</th>
                <th className="pb-3 px-3">Updated Value</th>
                <th className="pb-3 px-3">Repair Method</th>
                <th className="pb-3 px-3">Action Type</th>
                <th className="pb-3 px-3">Authorized Operator</th>
                <th className="pb-3 pl-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-mono">
              {paginatedLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50/80 transition-colors">
                  <td className="py-3.5 pr-3 text-gray-500 text-[11px] whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-3.5 px-3 font-bold text-gray-900 whitespace-nowrap">
                    {log.recordIdentifier}
                  </td>
                  <td className="py-3.5 px-3">
                    <code className="text-xs font-bold text-[#008F89] bg-teal-50 px-1.5 py-0.5 rounded border border-teal-200">
                      {log.columnName}
                    </code>
                  </td>
                  <td className="py-3.5 px-3 text-red-600 line-through max-w-[120px] truncate">
                    {String(log.originalValue)}
                  </td>
                  <td className="py-3.5 px-3 text-[#16A36A] font-bold max-w-[140px] truncate">
                    {String(log.updatedValue)}
                  </td>
                  <td className="py-3.5 px-3 font-sans text-gray-700 max-w-xs truncate" title={log.repairMethod}>
                    {log.repairMethod}
                  </td>
                  <td className="py-3.5 px-3 font-sans">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-gray-800">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 font-sans text-gray-600 text-[11px] whitespace-nowrap">
                    {log.operator}
                  </td>
                  <td className="py-3.5 pl-3 text-right">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#16A36A] bg-green-50 px-2 py-0.5 rounded-full border border-green-200">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{log.status}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between pt-4 mt-2 border-t border-gray-100 text-xs font-sans">
          <span className="text-gray-500">
            Page {currentPage} of {totalPages} ({filteredLogs.length} verified events)
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1 rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1 rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
