import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  Database, 
  FileSpreadsheet, 
  SearchAlert, 
  Wrench, 
  ShieldCheck, 
  TrendingUp, 
  ArrowRight, 
  UploadCloud, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  ChevronRight,
  Activity
} from 'lucide-react';

export const OverviewPage: React.FC = () => {
  const navigate = useNavigate();
  const { datasets, activeDataset, qualityScore, issues, repairs, auditLogs } = useData();

  const totalRecords = datasets.reduce((acc, curr) => acc + curr.rowCount, 0);
  const totalIssues = datasets.reduce((acc, curr) => acc + curr.issuesCount, 0);
  const totalRepaired = datasets.reduce((acc, curr) => acc + curr.repairedCount, 0);

  // Issues by Category distribution
  const issueDistribution = [
    { label: 'Missing Values', count: 142, percentage: 37, color: '#00B8AD' },
    { label: 'Duplicate Records', count: 100, percentage: 26, color: '#008F89' },
    { label: 'Inconsistent Entries', count: 88, percentage: 23, color: '#16A36A' },
    { label: 'Statistical Anomalies', count: 40, percentage: 10, color: '#EF4444' },
    { label: 'Syntax & Formatting', count: 14, percentage: 4, color: '#F59E0B' },
  ];

  return (
    <div className="space-y-6">
      {/* 1. WELCOME SECTION (Dark container with Database & Shield illustration and teal highlights) */}
      <div className="relative rounded-2xl bg-[#080F12] border border-[#26383A] p-6 lg:p-8 overflow-hidden shadow-2xl">
        {/* Ambient Teal Glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#00B8AD]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B1519] border border-[#26383A] text-xs text-[#A7B4B8] mb-4">
              <span className="w-2 h-2 rounded-full bg-[#00B8AD] animate-pulse" />
              <span>Enterprise Autonomous Engine Active</span>
            </div>

            <h1 className="text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Welcome to DataFix
            </h1>
            <p className="text-base lg:text-lg font-medium text-[#00B8AD] mt-1">
              Don't Just Clean Data. Make It Trustworthy.
            </p>
            <p className="text-sm text-[#A7B4B8] mt-3 leading-relaxed">
              An intelligent data quality and repair engine that detects, diagnoses, repairs, validates, 
              explains, and tracks dataset issues with zero manual guesswork.
            </p>

            <div className="flex flex-wrap items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => navigate('/upload')}
                className="px-5 py-2.5 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs tracking-wide transition-all shadow-md hover:shadow-teal-sm flex items-center gap-2 cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Upload Dataset</span>
              </button>
              <button
                type="button"
                onClick={() => navigate('/explainability')}
                className="px-5 py-2.5 rounded-xl bg-[#0B1519] hover:bg-[#111F24] text-white border border-[#26383A] font-semibold text-xs transition-colors flex items-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-[#00B8AD]" />
                <span>Engine Rationale & Docs</span>
              </button>
            </div>
          </div>

          {/* Database and Shield Graphic */}
          <div className="relative shrink-0 w-64 h-48 hidden md:flex items-center justify-center">
            <div className="relative w-40 h-40 flex items-center justify-center">
              {/* Spinning orbital ring */}
              <div className="absolute inset-0 rounded-full border border-[#00B8AD]/30 border-dashed animate-[spin_20s_linear_infinite]" />
              <div className="absolute inset-4 rounded-full border border-[#26383A]" />
              
              {/* Central Shield Container */}
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#0B1519] to-[#080F12] border border-[#00B8AD]/50 shadow-teal-glow flex flex-col items-center justify-center">
                <ShieldCheck className="w-10 h-10 text-[#00B8AD]" />
                <span className="text-[10px] font-extrabold text-[#BFF8F0] tracking-wider mt-1">
                  AUTONOMOUS
                </span>
              </div>

              {/* Floating satellite tags */}
              <div className="absolute -top-1 -right-2 px-2 py-0.5 rounded-md bg-[#080F12] border border-[#00B8AD]/40 text-[9px] font-semibold text-[#00B8AD] shadow-sm">
                99.8% Trust
              </div>
              <div className="absolute -bottom-1 -left-2 px-2 py-0.5 rounded-md bg-[#080F12] border border-[#26383A] text-[9px] font-semibold text-white shadow-sm flex items-center gap-1">
                <Database className="w-3 h-3 text-[#00B8AD]" />
                <span>Zero-Loss</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. FIVE SUMMARY CARDS (Pure White Cards with Dark Typography & Teal Highlights) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Card 1: Total Datasets */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between transition-transform hover:-translate-y-0.5 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Total Datasets
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#BFF8F0]/40 text-[#008F89] flex items-center justify-center">
              <Database className="w-4 h-4 text-[#008F89]" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-[#111827]">{datasets.length}</div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-[#16A36A] font-semibold">
              <TrendingUp className="w-3 h-3" />
              <span>+2 verified today</span>
            </div>
          </div>
        </div>

        {/* Card 2: Total Records */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between transition-transform hover:-translate-y-0.5 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Total Records
            </span>
            <div className="w-8 h-8 rounded-lg bg-gray-100 text-gray-700 flex items-center justify-center">
              <FileSpreadsheet className="w-4 h-4 text-[#111827]" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-[#111827]">
              {totalRecords.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-gray-500 font-medium">
              <span>Across 3 active partitions</span>
            </div>
          </div>
        </div>

        {/* Card 3: Issues Detected */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between transition-transform hover:-translate-y-0.5 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Issues Detected
            </span>
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
              <SearchAlert className="w-4 h-4 text-[#EF4444]" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-[#111827]">
              {totalIssues.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-[#EF4444] font-semibold">
              <AlertTriangle className="w-3 h-3" />
              <span>5 core categories</span>
            </div>
          </div>
        </div>

        {/* Card 4: Issues Repaired */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between transition-transform hover:-translate-y-0.5 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Issues Repaired
            </span>
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#008F89] flex items-center justify-center">
              <Wrench className="w-4 h-4 text-[#008F89]" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-[#008F89]">
              {totalRepaired.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-[#16A36A] font-semibold">
              <CheckCircle2 className="w-3 h-3" />
              <span>92.6% resolution rate</span>
            </div>
          </div>
        </div>

        {/* Card 5: Data Quality Score */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between transition-transform hover:-translate-y-0.5 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Quality Score
            </span>
            <div className="w-8 h-8 rounded-lg bg-green-50 text-[#16A36A] flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-[#16A36A]" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-[#111827] flex items-baseline gap-1">
              <span>{qualityScore}%</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-[#16A36A] font-semibold">
              <TrendingUp className="w-3 h-3" />
              <span>+33.6% improvement</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. VISUALIZATIONS SECTION: White containers against Black Background */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Chart: 2 Columns */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-gray-100">
            <div>
              <h2 className="text-base font-bold text-[#111827]">Data Quality Trend</h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Reliability score progression across ingestion, detection, and autonomous repair
              </p>
            </div>
            <span className="self-start sm:self-auto text-xs font-semibold px-2.5 py-1 rounded-full bg-teal-50 text-[#008F89] border border-teal-200">
              Live Pipeline Stream
            </span>
          </div>

          {/* Responsive SVG Chart */}
          <div className="mt-6 h-56 w-full relative">
            <svg viewBox="0 0 600 200" className="w-full h-full overflow-visible">
              <defs>
                <linearGradient id="tealAreaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00B8AD" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#00B8AD" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="40" y1="30" x2="580" y2="30" stroke="#F1F5F9" strokeDasharray="4 4" />
              <line x1="40" y1="80" x2="580" y2="80" stroke="#F1F5F9" strokeDasharray="4 4" />
              <line x1="40" y1="130" x2="580" y2="130" stroke="#F1F5F9" strokeDasharray="4 4" />
              <line x1="40" y1="170" x2="580" y2="170" stroke="#E2E8F0" />

              {/* Y Axis Labels */}
              <text x="28" y="34" className="text-[10px] fill-gray-400 font-mono" textAnchor="end">100%</text>
              <text x="28" y="84" className="text-[10px] fill-gray-400 font-mono" textAnchor="end">80%</text>
              <text x="28" y="134" className="text-[10px] fill-gray-400 font-mono" textAnchor="end">60%</text>
              <text x="28" y="174" className="text-[10px] fill-gray-400 font-mono" textAnchor="end">40%</text>

              {/* Area fill */}
              <path
                d="M 60 145 L 140 138 L 220 152 L 310 115 L 400 78 L 490 42 L 560 35 L 560 170 L 60 170 Z"
                fill="url(#tealAreaGrad)"
              />

              {/* Line path */}
              <path
                d="M 60 145 L 140 138 L 220 152 L 310 115 L 400 78 L 490 42 L 560 35"
                fill="none"
                stroke="#00B8AD"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Nodes on path */}
              {[
                { x: 60, y: 145, label: 'Raw Ingestion', score: '62%' },
                { x: 140, y: 138, label: 'Schema Parse', score: '65%' },
                { x: 220, y: 152, label: 'Defect Flagging', score: '58%' },
                { x: 310, y: 115, label: 'Diagnosis Phase', score: '74%' },
                { x: 400, y: 78, label: 'MICE Imputation', score: '88%' },
                { x: 490, y: 42, label: 'Deduplication', score: '96%' },
                { x: 560, y: 35, label: 'Final Certified', score: '98.4%' },
              ].map((pt, idx) => (
                <g key={idx} className="cursor-pointer group">
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={idx === 6 ? 6 : 4}
                    fill={idx === 6 ? '#00B8AD' : '#FFFFFF'}
                    stroke="#008F89"
                    strokeWidth="2.5"
                  />
                  <text
                    x={pt.x}
                    y={pt.y - 10}
                    className="text-[9px] fill-gray-700 font-bold opacity-0 group-hover:opacity-100 transition-opacity"
                    textAnchor="middle"
                  >
                    {pt.score}
                  </text>
                  <text
                    x={pt.x}
                    y="188"
                    className="text-[9px] fill-gray-400 font-medium"
                    textAnchor="middle"
                  >
                    {pt.label}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* Doughnut Chart: Issues by Category */}
        <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h2 className="text-base font-bold text-[#111827]">Issues by Category</h2>
              <span className="text-xs font-semibold text-gray-500">384 Defects</span>
            </div>

            {/* Doughnut SVG */}
            <div className="relative w-44 h-44 mx-auto my-4 flex items-center justify-center">
              <svg className="w-44 h-44 transform -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="38" fill="transparent" stroke="#F1F5F9" strokeWidth="12" />
                {/* Missing values 37% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#00B8AD"
                  strokeWidth="12"
                  strokeDasharray={`${37 * 2.387} 238.7`}
                  strokeDashoffset="0"
                />
                {/* Duplicate records 26% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#008F89"
                  strokeWidth="12"
                  strokeDasharray={`${26 * 2.387} 238.7`}
                  strokeDashoffset={`-${37 * 2.387}`}
                />
                {/* Inconsistent entries 23% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#16A36A"
                  strokeWidth="12"
                  strokeDasharray={`${23 * 2.387} 238.7`}
                  strokeDashoffset={`-${(37 + 26) * 2.387}`}
                />
                {/* Anomalies 10% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#EF4444"
                  strokeWidth="12"
                  strokeDasharray={`${10 * 2.387} 238.7`}
                  strokeDashoffset={`-${(37 + 26 + 23) * 2.387}`}
                />
                {/* Invalid formats 4% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#F59E0B"
                  strokeWidth="12"
                  strokeDasharray={`${4 * 2.387} 238.7`}
                  strokeDashoffset={`-${(37 + 26 + 23 + 10) * 2.387}`}
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-xl font-extrabold text-[#111827]">384</span>
                <span className="text-[10px] uppercase font-semibold text-gray-400">Total</span>
              </div>
            </div>

            {/* Legend Breakdown */}
            <div className="space-y-2 mt-2">
              {issueDistribution.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-gray-700 font-medium">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="text-gray-900 font-bold">{item.count}</span>
                    <span className="text-gray-400 text-[11px]">({item.percentage}%)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/detection')}
            className="w-full mt-4 py-2 px-3 rounded-lg bg-gray-50 hover:bg-gray-100 text-xs font-semibold text-[#008F89] flex items-center justify-center gap-1.5 transition-colors border border-gray-200"
          >
            <span>Explore All Detections</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 4. TABLES & LOGS SECTION (Recent Datasets Table + Live Repair Activity Panel) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Datasets Table: 2 Columns */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
          <div className="flex items-center justify-between pb-4 border-b border-gray-100">
            <div>
              <h2 className="text-base font-bold text-[#111827]">Recent Datasets</h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Active dataset partitions under autonomous surveillance
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/upload')}
              className="text-xs font-semibold text-[#008F89] hover:text-[#00B8AD] flex items-center gap-1"
            >
              <span>Upload New</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 overflow-x-auto table-scrollbar">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="pb-3 pr-4">Dataset Name</th>
                  <th className="pb-3 px-3">Records</th>
                  <th className="pb-3 px-3">Status</th>
                  <th className="pb-3 px-3">Before Score</th>
                  <th className="pb-3 px-3">After Score</th>
                  <th className="pb-3 pl-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {datasets.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="py-3 pr-4">
                      <div className="font-semibold text-gray-900">{item.name}</div>
                      <div className="text-[10px] text-gray-400 mt-0.5">
                        {item.format} • {item.fileSize} • Uploaded {item.uploadedAt}
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono text-gray-700">
                      {item.rowCount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        item.status === 'Cleaned'
                          ? 'bg-green-50 text-[#16A36A] border border-green-200'
                          : 'bg-amber-50 text-[#F59E0B] border border-amber-200'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-gray-500">
                      {item.qualityScoreBefore}%
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-[#16A36A]">
                      {item.qualityScoreAfter || qualityScore}%
                    </td>
                    <td className="py-3 pl-3 text-right">
                      <button
                        type="button"
                        onClick={() => navigate('/inspector')}
                        className="px-2.5 py-1 rounded bg-teal-50 hover:bg-teal-100 text-[#008F89] font-semibold text-[11px] transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Repair Activity Feed: 1 Column */}
        <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h2 className="text-base font-bold text-[#111827]">Live Activity Feed</h2>
              <span className="w-2 h-2 rounded-full bg-[#16A36A] animate-ping" />
            </div>

            <div className="mt-4 space-y-3.5 max-h-80 overflow-y-auto pr-1">
              {auditLogs.slice(0, 4).map((log) => (
                <div key={log.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-900">{log.action}</span>
                    <span className="text-[10px] text-gray-400 font-mono">{log.timestamp.split(' ')[1]}</span>
                  </div>
                  <p className="text-[11px] text-gray-600 mt-1">
                    Applied <strong>{log.repairMethod}</strong> on <code>{log.columnName}</code> ({log.recordIdentifier}).
                  </p>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-200/60 text-[10px]">
                    <span className="text-gray-500">{log.operator}</span>
                    <span className="text-[#16A36A] font-semibold">Verified</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/audit')}
            className="w-full mt-4 py-2 px-3 rounded-lg bg-gray-50 hover:bg-gray-100 text-xs font-semibold text-[#008F89] flex items-center justify-center gap-1.5 transition-colors border border-gray-200"
          >
            <span>View Immutable Audit Trail</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
