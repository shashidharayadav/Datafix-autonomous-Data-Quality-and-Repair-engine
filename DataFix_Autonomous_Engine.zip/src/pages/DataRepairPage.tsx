import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  Wrench, 
  Check, 
  X, 
  Play, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  History, 
  Search, 
  Filter,
  Layers,
  ShieldCheck
} from 'lucide-react';
import { RepairProposal } from '../types/dataset';

export const DataRepairPage: React.FC = () => {
  const navigate = useNavigate();
  const { 
    repairs, 
    approveRepair, 
    rejectRepair, 
    applyRepair, 
    applyAllApproved,
    qualityScore 
  } = useData();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedRepair, setSelectedRepair] = useState<RepairProposal | null>(null);

  // Targeted functionality: Loading states per repair item to prevent repeated clicks
  const [processingIds, setProcessingIds] = useState<Record<string, boolean>>({});
  const [isApplyingBatch, setIsApplyingBatch] = useState<boolean>(false);

  // Clear user feedback banner for confirmation and error reporting
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const availableCount = repairs.length;
  const proposedCount = repairs.filter(r => r.status === 'proposed').length;
  const approvedCount = repairs.filter(r => r.status === 'approved').length;
  const appliedCount = repairs.filter(r => r.status === 'applied').length;

  const filteredRepairs = repairs.filter(r => {
    if (filterStatus !== 'all' && r.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        r.columnName.toLowerCase().includes(q) ||
        r.repairMethod.toLowerCase().includes(q) ||
        String(r.recordId).includes(q)
      );
    }
    return true;
  });

  // Targeted Fix: Real async approval workflow with verification, backend call, and feedback
  const handleApprove = async (item: RepairProposal) => {
    if (!item || !item.id) return;

    // Prevent repeated clicks while processing
    if (processingIds[item.id]) return;

    // Verify repair is awaiting approval
    if (item.status !== 'proposed') {
      setFeedback({
        type: 'error',
        message: `Repair for Row #${item.recordId} is not awaiting approval (current status: ${item.status}).`
      });
      return;
    }

    setProcessingIds(prev => ({ ...prev, [item.id]: true }));
    setFeedback(null);

    try {
      const result = await approveRepair(item.id);
      setFeedback({
        type: 'success',
        message: result.message || `Repair #${item.recordId} on "${item.columnName}" approved successfully.`
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Approval failed for Row #${item.recordId}: ${err.message}`
      });
    } finally {
      setProcessingIds(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
    }
  };

  const handleReject = async (item: RepairProposal) => {
    if (!item || !item.id || processingIds[item.id]) return;

    setProcessingIds(prev => ({ ...prev, [item.id]: true }));
    setFeedback(null);

    try {
      const result = await rejectRepair(item.id);
      setFeedback({
        type: 'success',
        message: result.message || `Repair #${item.recordId} rejected.`
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Rejection failed for Row #${item.recordId}: ${err.message}`
      });
    } finally {
      setProcessingIds(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
    }
  };

  const handleApply = async (item: RepairProposal) => {
    if (!item || !item.id || processingIds[item.id]) return;

    setProcessingIds(prev => ({ ...prev, [item.id]: true }));
    setFeedback(null);

    try {
      const result = await applyRepair(item.id);
      setFeedback({
        type: 'success',
        message: result.message || `Repair #${item.recordId} applied to dataset.`
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Apply failed for Row #${item.recordId}: ${err.message}`
      });
    } finally {
      setProcessingIds(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
    }
  };

  const handleApplyBatch = async () => {
    if (isApplyingBatch) return;
    setIsApplyingBatch(true);
    setFeedback(null);

    try {
      const result = await applyAllApproved();
      setFeedback({
        type: 'success',
        message: result.message || `Applied approved repairs across all partitions.`
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Batch application failed: ${err.message}`
      });
    } finally {
      setIsApplyingBatch(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Capability Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <Wrench className="w-3.5 h-3.5" />
            <span>CAPABILITY: REPAIR</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Autonomous Data Repair Engine
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Review algorithmic corrections, approve high-confidence imputations, and apply automated schema fixes.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            disabled={isApplyingBatch || (approvedCount + proposedCount) === 0}
            onClick={handleApplyBatch}
            className="px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isApplyingBatch ? (
              <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-black" />
            )}
            <span>{isApplyingBatch ? 'Applying Batch...' : `Apply All Approved (${approvedCount + proposedCount})`}</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('/validation')}
            className="px-4 py-2 rounded-xl bg-[#080F12] hover:bg-[#0B1519] text-white border border-[#26383A] font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>Proceed to Validation</span>
            <ArrowRight className="w-4 h-4 text-[#00B8AD]" />
          </button>
        </div>
      </div>

      {/* Real-time Status Confirmation & Error Feedback Banner */}
      {feedback && (
        <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between shadow-sm transition-all ${
          feedback.type === 'success'
            ? 'bg-teal-50 border-teal-200 text-[#008F89]'
            : 'bg-red-50 border-red-200 text-red-700'
        }`}>
          <div className="flex items-center gap-2.5">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#00B8AD] shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#EF4444] shrink-0" />
            )}
            <span className="font-medium">{feedback.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="p-1 text-gray-400 hover:text-gray-700 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 1. REPAIR SUMMARY CARDS (Pure White Cards with Dark Text) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Available For Repair
          </span>
          <div className="text-2xl font-extrabold text-[#111827] mt-1">{availableCount}</div>
          <div className="text-[11px] text-gray-400 mt-1">Flagged by anomaly profiler</div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Repairs Proposed
          </span>
          <div className="text-2xl font-extrabold text-[#008F89] mt-1">{proposedCount}</div>
          <div className="text-[11px] text-[#008F89] font-medium mt-1">Pending engineer review</div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Repairs Completed
          </span>
          <div className="text-2xl font-extrabold text-[#16A36A] mt-1">{appliedCount}</div>
          <div className="text-[11px] text-[#16A36A] font-medium mt-1">Written to clean partition</div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Current Health Score
          </span>
          <div className="text-2xl font-extrabold text-[#111827] mt-1">{qualityScore}%</div>
          <div className="text-[11px] text-[#16A36A] font-semibold mt-1">Dynamic recalculation</div>
        </div>
      </div>

      {/* 2. REPAIR PROPOSALS TABLE (Pure White Table Container) */}
      <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by column or repair method..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400 font-medium">Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            >
              <option value="all">All Statuses ({repairs.length})</option>
              <option value="proposed">Proposed</option>
              <option value="approved">Approved</option>
              <option value="applied">Applied</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="mt-4 overflow-x-auto table-scrollbar">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="pb-3 pr-3">Record ID</th>
                <th className="pb-3 px-3">Column Name</th>
                <th className="pb-3 px-3">Original Value</th>
                <th className="pb-3 px-3">Recommended Value</th>
                <th className="pb-3 px-3">Repair Method</th>
                <th className="pb-3 px-3">Confidence</th>
                <th className="pb-3 px-3">Status</th>
                <th className="pb-3 pl-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredRepairs.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50/80 transition-colors">
                  <td className="py-3.5 pr-3 font-mono font-bold text-gray-700">
                    Row #{item.recordId}
                  </td>
                  <td className="py-3.5 px-3">
                    <code className="text-xs font-mono font-bold text-gray-900 bg-gray-100 px-1.5 py-0.5 rounded">
                      {item.columnName}
                    </code>
                  </td>
                  {/* Original vs Recommended values clearly contrasted */}
                  <td className="py-3.5 px-3 font-mono text-red-600 bg-red-50/40 px-2 rounded">
                    <span className="line-through">{String(item.originalValue)}</span>
                  </td>
                  <td className="py-3.5 px-3 font-mono font-bold text-[#16A36A] bg-green-50/40 px-2 rounded">
                    {String(item.recommendedValue)}
                  </td>
                  <td className="py-3.5 px-3 text-gray-700 max-w-xs truncate" title={item.repairMethod}>
                    {item.repairMethod}
                  </td>
                  <td className="py-3.5 px-3 font-mono font-bold text-[#008F89]">
                    {item.confidence}%
                  </td>
                  <td className="py-3.5 px-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      item.status === 'applied'
                        ? 'bg-green-50 text-[#16A36A] border border-green-200'
                        : item.status === 'approved'
                        ? 'bg-teal-50 text-[#008F89] border border-teal-200'
                        : item.status === 'rejected'
                        ? 'bg-red-50 text-[#EF4444] border border-red-200'
                        : 'bg-amber-50 text-[#F59E0B] border border-amber-200'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="py-3.5 pl-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      {/* Approve button - only enabled when status is 'proposed' (awaiting approval) */}
                      {item.status !== 'applied' && item.status !== 'rejected' && (
                        <>
                          <button
                            type="button"
                            disabled={item.status !== 'proposed' || processingIds[item.id]}
                            onClick={() => handleApprove(item)}
                            className={`p-1.5 rounded transition-all flex items-center justify-center ${
                              processingIds[item.id]
                                ? 'bg-teal-100 text-[#008F89] cursor-wait'
                                : item.status !== 'proposed'
                                ? 'bg-gray-100 text-gray-400 cursor-not-allowed opacity-50'
                                : 'bg-teal-50 text-[#008F89] hover:bg-teal-100 cursor-pointer shadow-sm hover:scale-105'
                            }`}
                            title={
                              processingIds[item.id]
                                ? 'Processing approval with backend...'
                                : item.status === 'proposed'
                                ? 'Approve repair recommendation'
                                : `Already ${item.status}`
                            }
                          >
                            {processingIds[item.id] ? (
                              <div className="w-3.5 h-3.5 border-2 border-[#008F89] border-t-transparent rounded-full animate-spin" />
                            ) : (
                              <Check className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            type="button"
                            disabled={processingIds[item.id]}
                            onClick={() => handleReject(item)}
                            className={`p-1.5 rounded transition-all flex items-center justify-center ${
                              processingIds[item.id]
                                ? 'bg-red-100 text-[#EF4444] cursor-wait'
                                : 'bg-red-50 text-[#EF4444] hover:bg-red-100 cursor-pointer shadow-sm hover:scale-105'
                            }`}
                            title="Reject repair recommendation"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}

                      {/* Apply button - enabled once approved */}
                      {item.status === 'approved' && (
                        <button
                          type="button"
                          disabled={processingIds[item.id]}
                          onClick={() => handleApply(item)}
                          className="px-2.5 py-1 rounded bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-[11px] transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          {processingIds[item.id] ? (
                            <div className="w-3 h-3 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <span>Apply</span>
                          )}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => setSelectedRepair(item)}
                        className="px-2 py-1 rounded bg-gray-100 text-gray-700 font-semibold text-[11px] hover:bg-gray-200 cursor-pointer transition-colors"
                      >
                        Details
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Repair Detail Modal */}
      {selectedRepair && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-100 text-[#111827]">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="text-base font-bold text-gray-900">
                Repair Specification: Record #{selectedRepair.recordId}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedRepair(null)}
                className="p-1 text-gray-400 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-red-50 border border-red-200">
                  <span className="text-gray-500 font-medium">Original Corrupted Value:</span>
                  <div className="text-sm font-mono font-bold text-red-600 mt-1">
                    {String(selectedRepair.originalValue)}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-green-50 border border-green-200">
                  <span className="text-gray-500 font-medium">Calibrated Recommended Value:</span>
                  <div className="text-sm font-mono font-bold text-[#16A36A] mt-1">
                    {String(selectedRepair.recommendedValue)}
                  </div>
                </div>
              </div>

              <div>
                <span className="font-semibold text-gray-600">Repair Algorithmic Method:</span>
                <p className="p-2.5 rounded-lg bg-gray-50 border border-gray-200 mt-1 font-mono text-gray-800">
                  {selectedRepair.repairMethod}
                </p>
              </div>

              <div>
                <span className="font-semibold text-gray-600">Decision Rationale:</span>
                <p className="p-2.5 rounded-lg bg-gray-50 border border-gray-200 mt-1 text-gray-700 leading-relaxed">
                  {selectedRepair.repairReason}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-gray-500">Confidence Score:</span>
                <span className="font-mono font-bold text-sm text-[#008F89]">{selectedRepair.confidence}%</span>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedRepair(null)}
                className="px-4 py-2 rounded-lg bg-gray-100 text-gray-700 text-xs font-semibold hover:bg-gray-200 cursor-pointer"
              >
                Close
              </button>
              {selectedRepair.status === 'proposed' && (
                <button
                  type="button"
                  disabled={processingIds[selectedRepair.id]}
                  onClick={async () => {
                    await handleApprove(selectedRepair);
                    setSelectedRepair(prev => prev ? { ...prev, status: 'approved' } : null);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#00B8AD] text-black text-xs font-semibold hover:bg-[#008F89] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {processingIds[selectedRepair.id] ? (
                    <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Check className="w-3.5 h-3.5" />
                  )}
                  <span>Approve Recommendation</span>
                </button>
              )}
              {selectedRepair.status === 'approved' && (
                <button
                  type="button"
                  disabled={processingIds[selectedRepair.id]}
                  onClick={async () => {
                    await handleApply(selectedRepair);
                    setSelectedRepair(prev => prev ? { ...prev, status: 'applied' } : null);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#00B8AD] text-black text-xs font-semibold hover:bg-[#008F89] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {processingIds[selectedRepair.id] ? (
                    <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-black" />
                  )}
                  <span>Apply Repair Now</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
