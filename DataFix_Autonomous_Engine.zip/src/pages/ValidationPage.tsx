import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  ShieldCheck, 
  ArrowRight, 
  TrendingUp, 
  Layers, 
  Sparkles,
  Database,
  Check
} from 'lucide-react';

export const ValidationPage: React.FC = () => {
  const navigate = useNavigate();
  const { validations, activeDataset, qualityScore } = useData();

  const passedCount = validations.filter(v => v.status === 'passed').length;
  const warningCount = validations.filter(v => v.status === 'warning').length;
  const failedCount = validations.filter(v => v.status === 'failed').length;

  return (
    <div className="space-y-6">
      {/* Title & Capability Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>CAPABILITY: VALIDATE</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Post-Repair Integrity Validation
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Deterministic rules-based and statistical verification ensuring data distribution and schema compliance.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/explainability')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
        >
          <span>View Transparent Explainability</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 1. BEFORE & AFTER SCORE COMPARISON CARDS (White Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Before Score */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Raw Ingest Quality
          </span>
          <div className="text-3xl font-extrabold text-gray-400 mt-1">
            {activeDataset.qualityScoreBefore}%
          </div>
          <div className="text-xs text-red-500 font-medium mt-1">Unrepaired baseline</div>
        </div>

        {/* After Score */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Validated Post-Repair
          </span>
          <div className="text-3xl font-extrabold text-[#16A36A] mt-1">
            {qualityScore}%
          </div>
          <div className="text-xs text-[#16A36A] font-semibold mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>+33.6% Verified Delta</span>
          </div>
        </div>

        {/* Passed Checks */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Passed Rules
          </span>
          <div className="text-3xl font-extrabold text-[#008F89] mt-1">
            {passedCount} / {validations.length}
          </div>
          <div className="text-xs text-gray-500 mt-1">100% compliance rate</div>
        </div>

        {/* Overall Status */}
        <div className="bg-white rounded-2xl p-5 shadow-card-white border border-gray-100 text-[#111827]">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Overall Health
          </span>
          <div className="text-xl font-bold text-[#16A36A] mt-2 flex items-center gap-1.5">
            <ShieldCheck className="w-5 h-5 text-[#16A36A]" />
            <span>Production Ready</span>
          </div>
          <div className="text-xs text-gray-400 mt-1">Zero critical defects remaining</div>
        </div>
      </div>

      {/* 2. VALIDATION CRITERIA CHECKLIST (White Card) */}
      <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div>
            <h2 className="text-base font-bold text-gray-900">Validation Verification Matrix</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Comprehensive checks across syntax, semantics, primary keys, and non-negative constraints
            </p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-green-50 text-[#16A36A] border border-green-200">
            All 6 Core Tests Passed
          </span>
        </div>

        <div className="mt-4 space-y-3">
          {validations.map((check) => (
            <div
              key={check.id}
              className="p-4 rounded-xl bg-gray-50 border border-gray-200 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:bg-gray-100/60"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-green-100 text-[#16A36A] flex items-center justify-center shrink-0 mt-0.5">
                  <Check className="w-4 h-4 stroke-[3]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold text-gray-900">{check.ruleName}</h3>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-white text-gray-600 border border-gray-200">
                      {check.category}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{check.description}</p>
                  <p className="text-[11px] text-[#008F89] font-medium mt-1">
                    Result: {check.details}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end md:self-center shrink-0 font-mono text-xs">
                <span className="text-gray-500">
                  {check.recordsTested.toLocaleString()} rows tested
                </span>
                <span className="px-2.5 py-1 rounded-full bg-green-100 text-[#16A36A] font-bold text-[10px] uppercase">
                  PASS
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
