import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { 
  SearchAlert, 
  Filter, 
  Search, 
  AlertTriangle, 
  Layers, 
  CheckCircle2, 
  ArrowRight, 
  HelpCircle,
  Eye,
  ChevronDown,
  Sparkles
} from 'lucide-react';
import { QualityIssue, IssueSeverity } from '../types/dataset';

export const IssueDetectionPage: React.FC = () => {
  const navigate = useNavigate();
  const { issues, activeDataset } = useData();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedIssue, setSelectedIssue] = useState<QualityIssue | null>(null);

  // Filter issues
  const filteredIssues = issues.filter((issue) => {
    if (categoryFilter !== 'all' && issue.category !== categoryFilter) return false;
    if (severityFilter !== 'all' && issue.severity !== severityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchCol = issue.columnName.toLowerCase().includes(q);
      const matchDesc = issue.description.toLowerCase().includes(q);
      const matchCat = issue.categoryLabel.toLowerCase().includes(q);
      if (!matchCol && !matchDesc && !matchCat) return false;
    }
    return true;
  });

  const getSeverityBadge = (severity: IssueSeverity) => {
    switch (severity) {
      case 'critical':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-[#EF4444] border border-red-200 uppercase tracking-wide">
            Critical
          </span>
        );
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-[#F59E0B] border border-amber-200 uppercase tracking-wide">
            High
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-[#008F89] border border-teal-200 uppercase tracking-wide">
            Medium
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-700 uppercase tracking-wide">
            Low
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Capability Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#080F12] border border-[#26383A] text-xs text-[#00B8AD] mb-2 font-mono">
            <SearchAlert className="w-3.5 h-3.5" />
            <span>CAPABILITY: DETECT</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
            Autonomous Issue Detection
          </h1>
          <p className="text-sm text-[#A7B4B8] mt-1">
            Real-time multi-dimensional profiling flagging structural defects, semantic divergence, and statistical outliers.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/diagnosis')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#00B8AD] hover:bg-[#008F89] text-black font-semibold text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer"
        >
          <span>Proceed to Root Cause Diagnosis</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 5 Core Category Metric Cards (White Cards) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Missing Values', category: 'missing_values', count: 142, color: 'text-[#00B8AD]' },
          { label: 'Duplicate Records', category: 'duplicate_records', count: 100, color: 'text-[#008F89]' },
          { label: 'Invalid Formats', category: 'invalid_formats', count: 14, color: 'text-[#F59E0B]' },
          { label: 'Inconsistent Entries', category: 'inconsistent_entries', count: 88, color: 'text-[#16A36A]' },
          { label: 'Statistical Anomalies', category: 'anomalies', count: 40, color: 'text-[#EF4444]' },
        ].map((item, idx) => (
          <div
            key={idx}
            onClick={() => setCategoryFilter(categoryFilter === item.category ? 'all' : item.category)}
            className={`p-4 rounded-xl cursor-pointer transition-all border ${
              categoryFilter === item.category
                ? 'bg-teal-50 border-[#00B8AD] shadow-sm'
                : 'bg-white border-gray-100 hover:border-gray-300'
            }`}
          >
            <div className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider truncate">
              {item.label}
            </div>
            <div className={`text-2xl font-extrabold mt-1 ${item.color}`}>
              {item.count}
            </div>
            <div className="text-[10px] text-gray-400 mt-0.5">
              {categoryFilter === item.category ? 'Filtered' : 'Click to filter'}
            </div>
          </div>
        ))}
      </div>

      {/* Main Issue Table Container (White Card) */}
      <div className="bg-white rounded-2xl p-6 shadow-card-white border border-gray-100 text-[#111827]">
        {/* Filter controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-gray-100">
          <div className="relative w-full lg:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search detected anomalies..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Category Select */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            >
              <option value="all">All Categories ({issues.length})</option>
              <option value="missing_values">Missing Values</option>
              <option value="duplicate_records">Duplicate Records</option>
              <option value="invalid_formats">Invalid Formats</option>
              <option value="inconsistent_entries">Inconsistent Entries</option>
              <option value="anomalies">Anomalies</option>
            </select>

            {/* Severity Select */}
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#00B8AD]"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Detailed Issues Table */}
        <div className="mt-4 overflow-x-auto table-scrollbar">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="pb-3 pr-4">Issue Category</th>
                <th className="pb-3 px-3">Affected Column</th>
                <th className="pb-3 px-3">Impact (Rows)</th>
                <th className="pb-3 px-3">Severity</th>
                <th className="pb-3 px-3">Detected Anomaly Description</th>
                <th className="pb-3 pl-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredIssues.map((issue) => (
                <tr key={issue.id} className="hover:bg-gray-50/80 transition-colors">
                  <td className="py-3.5 pr-4">
                    <div className="font-bold text-gray-900">{issue.categoryLabel}</div>
                    <div className="text-[10px] text-gray-400 font-mono mt-0.5">
                      Flagged at {issue.detectedAt}
                    </div>
                  </td>
                  <td className="py-3.5 px-3">
                    <code className="text-xs font-mono font-semibold text-[#008F89] bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                      {issue.columnName}
                    </code>
                  </td>
                  <td className="py-3.5 px-3 font-mono font-bold text-gray-800">
                    {issue.affectedRowsCount.toLocaleString()} rows
                  </td>
                  <td className="py-3.5 px-3">
                    {getSeverityBadge(issue.severity)}
                  </td>
                  <td className="py-3.5 px-3 text-gray-600 max-w-sm truncate">
                    {issue.description}
                  </td>
                  <td className="py-3.5 pl-3 text-right">
                    <button
                      type="button"
                      onClick={() => setSelectedIssue(issue)}
                      className="px-2.5 py-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold text-[11px] transition-colors inline-flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3 text-[#008F89]" />
                      <span>Inspect Rows</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Row Sample Drawer / Modal */}
      {selectedIssue && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-100 text-[#111827] animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-gray-100">
              <div>
                <h3 className="text-base font-bold text-gray-900">
                  Defect Inspection: {selectedIssue.categoryLabel}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Affected column: <code>{selectedIssue.columnName}</code> • Severity: {selectedIssue.severity.toUpperCase()}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedIssue(null)}
                className="p-1 rounded text-gray-400 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="mt-4">
              <p className="text-xs text-gray-700 leading-relaxed mb-3">
                {selectedIssue.description}
              </p>

              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                Sample Corrupted Records Preview:
              </div>
              <div className="bg-gray-50 rounded-xl p-3 border border-gray-200 overflow-x-auto font-mono text-xs">
                <pre>{JSON.stringify(selectedIssue.sampleAffectedRows, null, 2)}</pre>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedIssue(null)}
                className="px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-xs font-semibold text-gray-700"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedIssue(null);
                  navigate('/diagnosis');
                }}
                className="px-4 py-2 rounded-lg bg-[#00B8AD] hover:bg-[#008F89] text-black text-xs font-semibold flex items-center gap-1.5"
              >
                <span>View Root Cause Diagnosis</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
