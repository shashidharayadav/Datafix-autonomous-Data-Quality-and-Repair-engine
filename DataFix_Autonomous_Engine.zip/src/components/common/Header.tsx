import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  Search, 
  Bell, 
  User as UserIcon, 
  LogOut, 
  ShieldCheck, 
  Database, 
  Settings, 
  ExternalLink, 
  Check, 
  AlertTriangle,
  Menu,
  ChevronDown
} from 'lucide-react';

interface HeaderProps {
  onToggleMobileSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileSidebar }) => {
  const { user, logout } = useAuth();
  const { datasets, activeDataset, setActiveDatasetId, searchFilter, setSearchFilter } = useData();

  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showDatasetMenu, setShowDatasetMenu] = useState(false);

  const profileRef = useRef<HTMLDivElement | null>(null);
  const notifRef = useRef<HTMLDivElement | null>(null);
  const datasetRef = useRef<HTMLDivElement | null>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setShowProfileMenu(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (datasetRef.current && !datasetRef.current.contains(e.target as Node)) {
        setShowDatasetMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-30 h-16 w-full bg-[#080F12] border-b border-[#26383A] px-4 lg:px-8 flex items-center justify-between">
      {/* Left: Mobile hamburger & Active dataset pill */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleMobileSidebar}
          className="p-2 rounded-lg text-[#A7B4B8] hover:text-white hover:bg-[#26383A]/50 lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Dataset Switcher Dropdown */}
        <div className="relative" ref={datasetRef}>
          <button
            type="button"
            onClick={() => setShowDatasetMenu(!showDatasetMenu)}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-[#0B1519] border border-[#26383A] hover:border-[#00B8AD]/60 text-xs text-[#F8FAFC] transition-all"
          >
            <Database className="w-3.5 h-3.5 text-[#00B8AD]" />
            <span className="font-semibold max-w-[140px] sm:max-w-[200px] truncate">
              {activeDataset.name}
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00B8AD]/15 text-[#00B8AD] hidden sm:inline-block">
              {activeDataset.format}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#A7B4B8]" />
          </button>

          {showDatasetMenu && (
            <div className="absolute left-0 mt-2 w-72 rounded-xl bg-[#080F12] border border-[#26383A] shadow-2xl p-2 z-50 animate-in fade-in-50">
              <div className="text-[11px] font-bold text-[#A7B4B8] px-2 py-1 uppercase tracking-wider">
                Select Active Workspace Dataset
              </div>
              <div className="space-y-1 mt-1">
                {datasets.map(d => (
                  <button
                    key={d.id}
                    onClick={() => {
                      setActiveDatasetId(d.id);
                      setShowDatasetMenu(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-all ${
                      d.id === activeDataset.id
                        ? 'bg-[#00B8AD]/15 text-white border border-[#00B8AD]/40'
                        : 'text-[#A7B4B8] hover:bg-[#0B1519] hover:text-white'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-white truncate">{d.name}</div>
                      <div className="text-[10px] text-[#A7B4B8] mt-0.5">
                        {d.rowCount.toLocaleString()} rows • {d.columnCount} cols • {d.fileSize}
                      </div>
                    </div>
                    {d.id === activeDataset.id && (
                      <Check className="w-4 h-4 text-[#00B8AD] shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Center: Search Bar */}
      <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A7B4B8]">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search records, detected anomalies, columns, rules..."
            className="w-full pl-9 pr-12 py-1.5 text-xs bg-[#050B0B] border border-[#26383A] rounded-lg text-[#F8FAFC] placeholder-[#A7B4B8]/60 focus:outline-none focus:border-[#00B8AD] focus:ring-1 focus:ring-[#00B8AD] transition-all"
          />
          <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none">
            <kbd className="text-[10px] font-mono bg-[#080F12] text-[#A7B4B8] px-1.5 py-0.5 rounded border border-[#26383A]">
              /
            </kbd>
          </div>
        </div>
      </div>

      {/* Right: Notifications & User Profile */}
      <div className="flex items-center gap-3">
        {/* Notification Bell */}
        <div className="relative" ref={notifRef}>
          <button
            type="button"
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg text-[#A7B4B8] hover:text-white hover:bg-[#0B1519] border border-transparent hover:border-[#26383A] transition-all"
            title="System Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#00B8AD] shadow-teal-sm" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl bg-[#080F12] border border-[#26383A] shadow-2xl p-3 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-[#26383A]">
                <span className="text-xs font-bold text-white">System Events</span>
                <span className="text-[10px] text-[#00B8AD] font-medium">3 New Alerts</span>
              </div>
              <div className="space-y-2 mt-2 max-h-64 overflow-y-auto">
                <div className="p-2 rounded-lg bg-[#0B1519] border border-[#26383A]/80 text-xs">
                  <div className="flex items-center gap-1.5 text-[#16A36A] font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Autonomous Repair Succeeded</span>
                  </div>
                  <p className="text-[11px] text-[#A7B4B8] mt-1">
                    142 null entries imputed in <code>annual_income</code> via MICE model.
                  </p>
                  <span className="text-[9px] text-[#A7B4B8]/70 mt-1 block">2 mins ago</span>
                </div>

                <div className="p-2 rounded-lg bg-[#0B1519] border border-[#26383A]/80 text-xs">
                  <div className="flex items-center gap-1.5 text-[#F59E0B] font-semibold">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Duplicate Hashes Flagged</span>
                  </div>
                  <p className="text-[11px] text-[#A7B4B8] mt-1">
                    100 duplicate transaction rows queued for deduplication review.
                  </p>
                  <span className="text-[9px] text-[#A7B4B8]/70 mt-1 block">14 mins ago</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Pill & Dropdown */}
        <div className="relative" ref={profileRef}>
          <button
            type="button"
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-full bg-[#0B1519] border border-[#26383A] hover:border-[#00B8AD]/60 transition-all text-left"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#00B8AD] to-[#008F89] p-0.5 flex items-center justify-center">
              <div className="w-full h-full rounded-full bg-[#080F12] flex items-center justify-center text-xs font-bold text-[#00B8AD]">
                {user?.name ? user.name.charAt(0).toUpperCase() : 'A'}
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-semibold text-white leading-tight">
                {user?.name || 'Alex Mercer'}
              </div>
              <div className="text-[10px] text-[#00B8AD] leading-tight">
                {user?.role ? user.role.split(' ')[0] : 'Engineer'}
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-[#A7B4B8]" />
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-64 rounded-xl bg-[#080F12] border border-[#26383A] shadow-2xl p-2 z-50">
              <div className="p-2.5 border-b border-[#26383A]">
                <p className="text-xs font-bold text-white truncate">{user?.name || 'Alex Mercer'}</p>
                <p className="text-[11px] text-[#A7B4B8] truncate">{user?.email || 'lead.engineer@datafix.ai'}</p>
                <span className="inline-block text-[9px] font-semibold px-2 py-0.5 rounded bg-[#00B8AD]/15 text-[#00B8AD] border border-[#00B8AD]/30 mt-1.5">
                  Senior Reliability Engineer
                </span>
              </div>

              <div className="py-1">
                <button
                  type="button"
                  onClick={() => setShowProfileMenu(false)}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-[#A7B4B8] hover:text-white hover:bg-[#0B1519] transition-colors"
                >
                  <Settings className="w-3.5 h-3.5 text-[#00B8AD]" />
                  <span>Pipeline Preferences</span>
                </button>
                <a
                  href="#docs"
                  onClick={(e) => { e.preventDefault(); setShowProfileMenu(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-[#A7B4B8] hover:text-white hover:bg-[#0B1519] transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#00B8AD]" />
                  <span>Engine Architecture Docs</span>
                </a>
              </div>

              <div className="pt-1 border-t border-[#26383A]">
                <button
                  type="button"
                  onClick={() => {
                    setShowProfileMenu(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-[#EF4444] hover:bg-red-500/10 transition-colors font-semibold"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out Session</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
