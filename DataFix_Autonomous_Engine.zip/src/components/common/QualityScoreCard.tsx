import React from 'react';
import { TrendingUp, ShieldCheck } from 'lucide-react';
import { useData } from '../../context/DataContext';

interface QualityScoreCardProps {
  collapsed?: boolean;
}

export const QualityScoreCard: React.FC<QualityScoreCardProps> = ({ collapsed = false }) => {
  const { qualityScore } = useData();

  // SVG Circular progress params
  const size = 52;
  const strokeWidth = 5;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (qualityScore / 100) * circumference;

  if (collapsed) {
    return (
      <div className="w-full flex justify-center py-2" title={`Quality Score: ${qualityScore}%`}>
        <div className="relative w-10 h-10 flex items-center justify-center">
          <svg className="w-10 h-10 transform -rotate-90">
            <circle
              cx="20"
              cy="20"
              r="16"
              className="stroke-[#26383A]"
              strokeWidth="3.5"
              fill="transparent"
            />
            <circle
              cx="20"
              cy="20"
              r="16"
              className="stroke-[#00B8AD] transition-all duration-700 ease-out"
              strokeWidth="3.5"
              fill="transparent"
              strokeDasharray={2 * Math.PI * 16}
              strokeDashoffset={2 * Math.PI * 16 - (qualityScore / 100) * 2 * Math.PI * 16}
              strokeLinecap="round"
            />
          </svg>
          <span className="absolute text-[10px] font-bold text-white">
            {Math.round(qualityScore)}%
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3.5 rounded-xl bg-[#0B1519] border border-[#26383A] shadow-lg relative overflow-hidden group">
      {/* Subtle corner teal glow */}
      <div className="absolute -right-4 -bottom-4 w-16 h-16 bg-[#00B8AD]/10 rounded-full blur-xl pointer-events-none group-hover:bg-[#00B8AD]/20 transition-all" />

      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
          <ShieldCheck className="w-3.5 h-3.5 text-[#00B8AD]" />
          <span>Data Quality Score</span>
        </div>
        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#16A36A]/15 text-[#16A36A] border border-[#16A36A]/30">
          Healthy
        </span>
      </div>

      <div className="flex items-center gap-3">
        {/* Circular Progress SVG */}
        <div className="relative shrink-0 flex items-center justify-center">
          <svg className="w-13 h-13 transform -rotate-90" width={size} height={size}>
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              className="stroke-[#26383A]"
              strokeWidth={strokeWidth}
              fill="transparent"
            />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              className="stroke-[#00B8AD] transition-all duration-1000 ease-out"
              strokeWidth={strokeWidth}
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-xs font-extrabold text-white">
              {qualityScore}%
            </span>
          </div>
        </div>

        {/* Metric info */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-[#16A36A]">
            <TrendingUp className="w-3 h-3" />
            <span>+33.6% boost</span>
          </div>
          <p className="text-[11px] text-[#A7B4B8] mt-0.5 truncate">
            Post-repair validation
          </p>
        </div>
      </div>
    </div>
  );
};
