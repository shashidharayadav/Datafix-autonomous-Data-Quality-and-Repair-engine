import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  ShieldCheck, 
  LayoutDashboard, 
  UploadCloud, 
  Table, 
  SearchAlert, 
  Cpu, 
  Wrench, 
  CheckCircle2, 
  Sparkles, 
  History, 
  FileText, 
  ChevronLeft, 
  ChevronRight,
  Database
} from 'lucide-react';
import { QualityScoreCard } from './QualityScoreCard';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    { label: 'Overview', to: '/overview', icon: LayoutDashboard, badge: null },
    { label: 'Upload Dataset', to: '/upload', icon: UploadCloud, badge: null },
    { label: 'Dataset Inspector', to: '/inspector', icon: Table, badge: null },
    { label: 'Issue Detection', to: '/detection', icon: SearchAlert, badge: 'DETECT' },
    { label: 'Diagnosis', to: '/diagnosis', icon: Cpu, badge: 'DIAGNOSE' },
    { label: 'Data Repair', to: '/repair', icon: Wrench, badge: 'REPAIR' },
    { label: 'Validation', to: '/validation', icon: CheckCircle2, badge: 'VALIDATE' },
    { label: 'Explainability', to: '/explainability', icon: Sparkles, badge: 'EXPLAIN' },
    { label: 'Audit History', to: '/audit', icon: History, badge: 'TRACK' },
    { label: 'Reports', to: '/reports', icon: FileText, badge: null },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Main Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col justify-between bg-[#080F12] border-r border-[#26383A] transition-all duration-300 ease-in-out ${
          collapsed ? 'w-20' : 'w-64'
        } ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top Header: Brand Logo & Title */}
        <div className="p-4 flex items-center justify-between border-b border-[#26383A]">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00B8AD] to-[#008F89] p-0.5 shadow-teal-sm shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-[#080F12] rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-[#00B8AD]" />
              </div>
            </div>

            {!collapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-lg font-extrabold tracking-wider text-white">DATAFIX</span>
                </div>
                <p className="text-[10px] font-medium tracking-widest text-[#00B8AD] uppercase truncate">
                  Clean. Trust. Grow.
                </p>
              </div>
            )}
          </div>

          {/* Desktop Collapse Toggle */}
          <button
            type="button"
            onClick={onToggleCollapse}
            className="hidden lg:flex p-1.5 rounded-lg text-[#A7B4B8] hover:text-white hover:bg-[#26383A]/60 transition-colors"
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Middle Navigation Items */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-bold text-[#A7B4B8] uppercase tracking-wider">
              Platform Modules
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onCloseMobile}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 group relative ${
                    isActive
                      ? 'bg-[#00B8AD] text-black shadow-teal-sm'
                      : 'text-[#F8FAFC] hover:bg-[#0B1519] hover:text-white'
                  } ${collapsed ? 'justify-center px-0' : ''}`
                }
                title={collapsed ? item.label : undefined}
              >
                {({ isActive }) => (
                  <>
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-black' : 'text-[#F8FAFC] group-hover:text-[#00B8AD]'
                      }`}
                    />

                    {!collapsed && (
                      <div className="flex-1 flex items-center justify-between">
                        <span className="truncate">{item.label}</span>
                        {item.badge && (
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold tracking-tight uppercase ${
                              isActive
                                ? 'bg-black/20 text-black'
                                : 'bg-[#00B8AD]/15 text-[#00B8AD] border border-[#00B8AD]/30'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </div>

        {/* Bottom Section: Data Quality Score Card */}
        <div className="p-3 border-t border-[#26383A] bg-[#080F12]">
          <QualityScoreCard collapsed={collapsed} />
        </div>
      </aside>
    </>
  );
};
