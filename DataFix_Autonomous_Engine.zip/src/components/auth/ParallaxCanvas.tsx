import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  baseRadius: number;
  color: string;
  alpha: number;
  layer: number; // For parallax depth calculation
}

interface DataPacket {
  fromNode: number;
  toNode: number;
  progress: number;
  speed: number;
}

export const ParallaxCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    // Mouse coordinates with smoothing
    const mouse = {
      x: width / 2,
      y: height / 2,
      targetX: width / 2,
      targetY: height / 2,
      isHovered: false,
    };

    // Responsive resize handler
    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.targetX = e.clientX - rect.left;
      mouse.targetY = e.clientY - rect.top;
      mouse.isHovered = true;
    };

    const handleMouseLeave = () => {
      mouse.targetX = width / 2;
      mouse.targetY = height / 2;
      mouse.isHovered = false;
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);

    // Initialize particles (Data Nodes)
    const particleCount = 55;
    const particles: Particle[] = [];
    const colors = ['#00B8AD', '#008F89', '#BFF8F0', '#ffffff'];

    for (let i = 0; i < particleCount; i++) {
      const layer = Math.random() * 3 + 1; // 1 to 4 depth
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4 * layer,
        vy: (Math.random() - 0.5) * 0.4 * layer,
        baseRadius: Math.random() * 2 + 1.2,
        radius: Math.random() * 2 + 1.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.5 + 0.3,
        layer,
      });
    }

    // Dynamic data packets running along connections
    const packets: DataPacket[] = [];
    for (let i = 0; i < 8; i++) {
      packets.push({
        fromNode: Math.floor(Math.random() * particleCount),
        toNode: Math.floor(Math.random() * particleCount),
        progress: Math.random(),
        speed: Math.random() * 0.01 + 0.006,
      });
    }

    let angle = 0;

    // Render loop
    const render = () => {
      // Smooth mouse easing
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      const parallaxOffsetX = (mouse.x - width / 2) * 0.035;
      const parallaxOffsetY = (mouse.y - height / 2) * 0.035;

      // Dark background with subtle gradient clearing
      ctx.fillStyle = '#050B0B';
      ctx.fillRect(0, 0, width, height);

      // Subtle cybernetic radial glow centered near mouse / database shield
      const grad = ctx.createRadialGradient(
        width * 0.45 + parallaxOffsetX * 2,
        height * 0.5 + parallaxOffsetY * 2,
        20,
        width * 0.45,
        height * 0.5,
        width * 0.65
      );
      grad.addColorStop(0, 'rgba(0, 184, 173, 0.12)');
      grad.addColorStop(0.5, 'rgba(0, 143, 137, 0.04)');
      grad.addColorStop(1, 'rgba(5, 11, 11, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Draw faint holographic grid lines
      ctx.lineWidth = 0.5;
      ctx.strokeStyle = 'rgba(38, 56, 58, 0.35)';
      const gridSize = 48;
      const gridShiftX = (parallaxOffsetX * 0.4) % gridSize;
      const gridShiftY = (parallaxOffsetY * 0.4) % gridSize;

      for (let x = gridShiftX; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = gridShiftY; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw 3D wireframe cylinder database in center-left with parallax rotation
      angle += 0.008;
      const dbCenterX = width * 0.48 + parallaxOffsetX * 2.5;
      const dbCenterY = height * 0.46 + parallaxOffsetY * 2.5;
      const dbRadius = 85;
      const dbHeight = 110;

      ctx.save();
      ctx.strokeStyle = 'rgba(0, 184, 173, 0.45)';
      ctx.lineWidth = 1.2;

      // Draw 3 tiered database disks
      [-dbHeight / 2, 0, dbHeight / 2].forEach((offsetY, idx) => {
        ctx.beginPath();
        ctx.ellipse(dbCenterX, dbCenterY + offsetY, dbRadius, dbRadius * 0.32, 0, 0, Math.PI * 2);
        ctx.stroke();

        if (idx === 0) {
          ctx.fillStyle = 'rgba(0, 184, 173, 0.08)';
          ctx.fill();
        }
      });

      // Database bounding columns
      [-dbRadius, dbRadius].forEach(edgeX => {
        ctx.beginPath();
        ctx.moveTo(dbCenterX + edgeX, dbCenterY - dbHeight / 2);
        ctx.lineTo(dbCenterX + edgeX, dbCenterY + dbHeight / 2);
        ctx.stroke();
      });

      // Shield overlay contour
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(191, 248, 240, 0.8)';
      ctx.lineWidth = 2;
      const shieldTopY = dbCenterY - 45;
      ctx.moveTo(dbCenterX - 40, shieldTopY);
      ctx.lineTo(dbCenterX + 40, shieldTopY);
      ctx.lineTo(dbCenterX + 40, shieldTopY + 35);
      ctx.quadraticCurveTo(dbCenterX, shieldTopY + 75, dbCenterX, shieldTopY + 85);
      ctx.quadraticCurveTo(dbCenterX, shieldTopY + 75, dbCenterX - 40, shieldTopY + 35);
      ctx.closePath();
      ctx.fillStyle = 'rgba(0, 184, 173, 0.15)';
      ctx.fill();
      ctx.stroke();

      // Shield verification checkmark
      ctx.beginPath();
      ctx.strokeStyle = '#00B8AD';
      ctx.lineWidth = 2.5;
      ctx.moveTo(dbCenterX - 14, shieldTopY + 36);
      ctx.lineTo(dbCenterX - 4, shieldTopY + 46);
      ctx.lineTo(dbCenterX + 15, shieldTopY + 24);
      ctx.stroke();

      ctx.restore();

      // Update and draw interconnected particle mesh
      particles.forEach((p) => {
        // Position update
        p.x += p.vx;
        p.y += p.vy;

        // Wrap screen edges
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Parallax position
        const drawX = p.x + parallaxOffsetX * p.layer;
        const drawY = p.y + parallaxOffsetY * p.layer;

        // Distance to mouse for subtle proximity glow
        const dx = mouse.x - drawX;
        const dy = mouse.y - drawY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          p.radius = p.baseRadius * (1 + (1 - dist / 120) * 1.5);
        } else {
          p.radius = p.baseRadius;
        }

        // Draw particle node
        ctx.beginPath();
        ctx.arc(drawX, drawY, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
        ctx.globalAlpha = 1.0;
      });

      // Draw connection lines between proximate nodes
      ctx.lineWidth = 0.6;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const p1 = particles[i];
          const p2 = particles[j];
          const x1 = p1.x + parallaxOffsetX * p1.layer;
          const y1 = p1.y + parallaxOffsetY * p1.layer;
          const x2 = p2.x + parallaxOffsetX * p2.layer;
          const y2 = p2.y + parallaxOffsetY * p2.layer;

          const dx = x1 - x2;
          const dy = y1 - y2;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 130) {
            const alpha = (1 - dist / 130) * 0.28;
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.strokeStyle = `rgba(0, 184, 173, ${alpha})`;
            ctx.stroke();
          }
        }
      }

      // Draw moving data packets
      packets.forEach(packet => {
        packet.progress += packet.speed;
        if (packet.progress >= 1) {
          packet.progress = 0;
          packet.fromNode = Math.floor(Math.random() * particleCount);
          packet.toNode = Math.floor(Math.random() * particleCount);
        }

        const p1 = particles[packet.fromNode];
        const p2 = particles[packet.toNode];
        if (!p1 || !p2) return;

        const x1 = p1.x + parallaxOffsetX * p1.layer;
        const y1 = p1.y + parallaxOffsetY * p1.layer;
        const x2 = p2.x + parallaxOffsetX * p2.layer;
        const y2 = p2.y + parallaxOffsetY * p2.layer;

        const currentX = x1 + (x2 - x1) * packet.progress;
        const currentY = y1 + (y2 - y1) * packet.progress;

        ctx.beginPath();
        ctx.arc(currentX, currentY, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = '#BFF8F0';
        ctx.shadowColor = '#00B8AD';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-auto cursor-crosshair z-0"
    />
  );
};
