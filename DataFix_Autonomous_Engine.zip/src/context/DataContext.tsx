import React, { createContext, useContext, useState, ReactNode } from 'react';
import { 
  DatasetItem, 
  QualityIssue, 
  DiagnosisEntry, 
  RepairProposal, 
  ValidationCheck, 
  ExplainabilityRecord, 
  AuditLog, 
  QualityReport 
} from '../types/dataset';
import { 
  INITIAL_DATASETS, 
  SAMPLE_ISSUES, 
  SAMPLE_DIAGNOSES, 
  SAMPLE_REPAIRS, 
  SAMPLE_VALIDATIONS, 
  SAMPLE_EXPLAINABILITY, 
  SAMPLE_AUDIT_LOGS, 
  SAMPLE_REPORT,
  datasetService
} from '../services/datasetService';

interface DataContextType {
  datasets: DatasetItem[];
  activeDataset: DatasetItem;
  setActiveDatasetId: (id: string) => void;
  issues: QualityIssue[];
  diagnoses: DiagnosisEntry[];
  repairs: RepairProposal[];
  validations: ValidationCheck[];
  explainability: ExplainabilityRecord[];
  auditLogs: AuditLog[];
  report: QualityReport;
  qualityScore: number;
  approveRepair: (repairId: string) => Promise<{ success: boolean; message: string }>;
  rejectRepair: (repairId: string) => Promise<{ success: boolean; message: string }>;
  applyRepair: (repairId: string) => Promise<{ success: boolean; message: string }>;
  applyAllApproved: () => Promise<{ success: boolean; message: string; appliedCount: number }>;
  uploadDatasetFile: (file: File, formatHint?: string) => Promise<DatasetItem>;
  addDataset: (newDataset: DatasetItem) => void;
  deleteDataset: (id: string) => void;
  refreshDatasets: () => Promise<void>;
  filterIssuesByCategory: (category?: string) => QualityIssue[];
  searchFilter: string;
  setSearchFilter: (query: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [datasets, setDatasets] = useState<DatasetItem[]>(INITIAL_DATASETS);
  const [activeDatasetId, setActiveDatasetId] = useState<string>(INITIAL_DATASETS[0].id);
  const [issues, setIssues] = useState<QualityIssue[]>(SAMPLE_ISSUES);
  const [diagnoses, setDiagnoses] = useState<DiagnosisEntry[]>(SAMPLE_DIAGNOSES);
  const [repairs, setRepairs] = useState<RepairProposal[]>(SAMPLE_REPAIRS);
  const [validations, setValidations] = useState<ValidationCheck[]>(SAMPLE_VALIDATIONS);
  const [explainability, setExplainability] = useState<ExplainabilityRecord[]>(SAMPLE_EXPLAINABILITY);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(SAMPLE_AUDIT_LOGS);
  const [report, setReport] = useState<QualityReport>(SAMPLE_REPORT);
  const [searchFilter, setSearchFilter] = useState<string>('');

  const activeDataset = datasets.find(d => d.id === activeDatasetId) || datasets[0];

  // Dynamic quality score calculation
  const totalRepairs = repairs.length;
  const appliedRepairs = repairs.filter(r => r.status === 'applied' || r.status === 'approved').length;
  const calculatedScore = totalRepairs > 0 
    ? Math.round(64.8 + ((appliedRepairs / totalRepairs) * 33.6) * 10) / 10 
    : activeDataset.qualityScoreAfter || 98.4;

  const refreshDatasets = async () => {
    try {
      const latest = await datasetService.getDatasets();
      if (latest && latest.length > 0) {
        setDatasets(latest);
      }
    } catch (err) {
      console.warn('Could not refresh datasets from backend:', err);
    }
  };

  const uploadDatasetFile = async (file: File, formatHint?: string): Promise<DatasetItem> => {
    const uploaded = await datasetService.uploadDataset(file, formatHint);
    setDatasets(prev => [uploaded, ...prev]);
    setActiveDatasetId(uploaded.id);
    return uploaded;
  };

  const approveRepair = async (repairId: string): Promise<{ success: boolean; message: string }> => {
    // 1. Identify the correct repair recommendation
    const target = repairs.find(r => r.id === repairId);
    if (!target) {
      throw new Error(`Repair recommendation with ID "${repairId}" was not found.`);
    }

    // 2. Verify that the repair is awaiting approval
    if (target.status !== 'proposed') {
      throw new Error(`Repair #${target.recordId} is not awaiting approval (current status: ${target.status}).`);
    }

    // 3. Send the approval request through existing API integration & wait for actual response
    const response = await datasetService.approveRepair(repairId, activeDataset.id);

    // 4. Update the repair status only after successful confirmation
    const timestampStr = new Date().toLocaleTimeString();
    setRepairs(prev => prev.map(r => {
      if (r.id === repairId) {
        return { 
          ...r, 
          status: 'approved', 
          reviewedAt: timestampStr, 
          reviewedBy: 'Alex Mercer (Lead Engineer)' 
        };
      }
      return r;
    }));

    // Add confirmed action to audit trail
    const newAudit: AuditLog = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      datasetName: activeDataset.name,
      recordIdentifier: `Record #${target.recordId}`,
      columnName: target.columnName,
      originalValue: String(target.originalValue),
      updatedValue: String(target.recommendedValue),
      repairMethod: target.repairMethod,
      action: 'Manual Approval',
      operator: 'Alex Mercer (Lead Engineer)',
      status: 'Completed'
    };
    setAuditLogs(prev => [newAudit, ...prev]);

    return {
      success: true,
      message: response.message || `Repair #${target.recordId} on "${target.columnName}" approved successfully.`
    };
  };

  const rejectRepair = async (repairId: string): Promise<{ success: boolean; message: string }> => {
    const target = repairs.find(r => r.id === repairId);
    if (!target) {
      throw new Error(`Repair recommendation with ID "${repairId}" was not found.`);
    }

    if (target.status === 'applied') {
      throw new Error(`Cannot reject repair #${target.recordId} because it has already been applied.`);
    }

    const response = await datasetService.rejectRepair(repairId, activeDataset.id);

    setRepairs(prev => prev.map(r => {
      if (r.id === repairId) {
        return { 
          ...r, 
          status: 'rejected', 
          reviewedAt: new Date().toLocaleTimeString(), 
          reviewedBy: 'Alex Mercer (Lead Engineer)' 
        };
      }
      return r;
    }));

    const newAudit: AuditLog = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      datasetName: activeDataset.name,
      recordIdentifier: `Record #${target.recordId}`,
      columnName: target.columnName,
      originalValue: String(target.originalValue),
      updatedValue: '[RETAINED ORIGINAL]',
      repairMethod: target.repairMethod,
      action: 'Rejection',
      operator: 'Alex Mercer (Lead Engineer)',
      status: 'Completed'
    };
    setAuditLogs(prev => [newAudit, ...prev]);

    return {
      success: true,
      message: response.message || `Repair #${target.recordId} on "${target.columnName}" was rejected.`
    };
  };

  const applyRepair = async (repairId: string): Promise<{ success: boolean; message: string }> => {
    const target = repairs.find(r => r.id === repairId);
    if (!target) {
      throw new Error(`Repair recommendation with ID "${repairId}" was not found.`);
    }

    const response = await datasetService.applyRepair(repairId, activeDataset.id);

    setRepairs(prev => prev.map(r => {
      if (r.id === repairId) {
        return { 
          ...r, 
          status: 'applied', 
          reviewedAt: new Date().toLocaleTimeString(), 
          reviewedBy: 'Alex Mercer (Lead Engineer)' 
        };
      }
      return r;
    }));

    const newAudit: AuditLog = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      datasetName: activeDataset.name,
      recordIdentifier: `Record #${target.recordId}`,
      columnName: target.columnName,
      originalValue: String(target.originalValue),
      updatedValue: String(target.recommendedValue),
      repairMethod: target.repairMethod,
      action: 'Auto-Repair',
      operator: 'DataFix Engine (Autonomous)',
      status: 'Completed'
    };
    setAuditLogs(prev => [newAudit, ...prev]);

    return {
      success: true,
      message: response.message || `Repair #${target.recordId} applied successfully.`
    };
  };

  const applyAllApproved = async (): Promise<{ success: boolean; message: string; appliedCount: number }> => {
    const response = await datasetService.applyAllApproved(activeDataset.id);

    let count = 0;
    setRepairs(prev => prev.map(r => {
      if (r.status === 'approved' || r.status === 'proposed') {
        count++;
        return { ...r, status: 'applied', reviewedAt: new Date().toLocaleTimeString(), reviewedBy: 'Alex Mercer (Lead Engineer)' };
      }
      return r;
    }));

    const bulkAudit: AuditLog = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      datasetName: activeDataset.name,
      recordIdentifier: 'Batch Multi-Record',
      columnName: 'All Critical Columns',
      originalValue: 'Multiple Anomalies',
      updatedValue: 'Calibrated Canonical Values',
      repairMethod: 'Autonomous Batch Rectification Pipeline',
      action: 'Bulk Patch',
      operator: 'Alex Mercer (Lead Engineer)',
      status: 'Completed'
    };
    setAuditLogs(prev => [bulkAudit, ...prev]);

    return {
      success: true,
      message: response.message || `Batch applied ${count} repairs successfully.`,
      appliedCount: count
    };
  };

  const addDataset = (newDataset: DatasetItem) => {
    setDatasets(prev => [newDataset, ...prev]);
    setActiveDatasetId(newDataset.id);
  };

  const deleteDataset = (id: string) => {
    setDatasets(prev => prev.filter(d => d.id !== id));
    if (activeDatasetId === id && datasets.length > 1) {
      const remaining = datasets.filter(d => d.id !== id);
      setActiveDatasetId(remaining[0].id);
    }
  };

  const filterIssuesByCategory = (category?: string) => {
    if (!category || category === 'all') return issues;
    return issues.filter(i => i.category === category);
  };

  return (
    <DataContext.Provider
      value={{
        datasets,
        activeDataset,
        setActiveDatasetId,
        issues,
        diagnoses,
        repairs,
        validations,
        explainability,
        auditLogs,
        report,
        qualityScore: calculatedScore,
        approveRepair,
        rejectRepair,
        applyRepair,
        applyAllApproved,
        uploadDatasetFile,
        addDataset,
        deleteDataset,
        refreshDatasets,
        filterIssuesByCategory,
        searchFilter,
        setSearchFilter
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
