import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck } from 'lucide-react';

export const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen w-full bg-[#050B0B] flex flex-col items-center justify-center text-[#F8FAFC]">
        <div className="w-12 h-12 rounded-xl bg-[#080F12] border border-[#26383A] flex items-center justify-center mb-4 relative shadow-teal-glow">
          <ShieldCheck className="w-6 h-6 text-[#00B8AD] animate-pulse" />
          <div className="absolute inset-0 rounded-xl border border-[#00B8AD]/40 animate-ping" />
        </div>
        <p className="text-sm font-semibold tracking-wider text-white">DATAFIX SECURE GATEWAY</p>
        <p className="text-xs text-[#A7B4B8] mt-1">Verifying encrypted workstation session...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};
