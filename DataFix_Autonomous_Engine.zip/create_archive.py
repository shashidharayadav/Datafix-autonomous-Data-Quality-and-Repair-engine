"""
Creates a clean, complete distribution zip file for the DataFix project
excluding virtual environments, node_modules, and cache files to keep size under 20 MB.
"""

import os
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_ZIP = PROJECT_ROOT / "DataFix_Autonomous_Engine.zip"

# Patterns to strictly exclude
EXCLUDE_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".gemini",
    "dist-ssr"
}

EXCLUDE_FILES = {
    "DataFix_Autonomous_Engine.zip",
    "datafix_backup.db"
}

EXCLUDE_EXTS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".log"
}

def should_exclude(path: Path) -> bool:
    for part in path.parts:
        if part in EXCLUDE_DIRS:
            return True
    if path.name in EXCLUDE_FILES:
        return True
    if path.suffix in EXCLUDE_EXTS:
        return True
    # Exclude active secrets
    if path.name == ".env":
        return True
    return False

def make_zip():
    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()

    total_files = 0
    total_uncompressed_bytes = 0

    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

            for file in files:
                file_path = Path(root) / file
                if should_exclude(file_path):
                    continue

                rel_path = file_path.relative_to(PROJECT_ROOT)
                zipf.write(file_path, arcname=str(rel_path))
                total_files += 1
                total_uncompressed_bytes += file_path.stat().st_size

    zip_size_bytes = OUTPUT_ZIP.stat().st_size
    zip_size_mb = zip_size_bytes / (1024 * 1024)

    print("=" * 60)
    print(" DATAFIX ARCHIVE GENERATION SUMMARY")
    print("=" * 60)
    print(f"Archive file:        {OUTPUT_ZIP.name}")
    print(f"Full path:           {OUTPUT_ZIP}")
    print(f"Total files:         {total_files}")
    print(f"Uncompressed size:   {total_uncompressed_bytes / (1024 * 1024):.2f} MB")
    print(f"Compressed size:     {zip_size_mb:.2f} MB ({zip_size_bytes:,} bytes)")
    print(f"Under 20 MB target:  {'PASS (< 20 MB)' if zip_size_mb < 20 else 'FAIL (> 20 MB)'}")
    print("=" * 60)

if __name__ == "__main__":
    make_zip()
