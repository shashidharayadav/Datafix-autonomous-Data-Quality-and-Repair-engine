from datetime import datetime
from sqlalchemy.orm import Session
from backend.app.models.audit import AuditLog

def log_audit_event(
    db: Session,
    dataset_name: str,
    record_identifier: str,
    column_name: str,
    original_value: str,
    updated_value: str,
    repair_method: str,
    action: str,
    operator: str = "DataFix Autonomous Engine",
    status: str = "Completed",
    dataset_id: str = None
) -> AuditLog:
    """Creates and commits an immutable cryptographic audit log entry."""
    entry = AuditLog(
        id=f"aud_{int(datetime.utcnow().timestamp() * 1000)}",
        dataset_id=dataset_id,
        timestamp=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        dataset_name=dataset_name,
        record_identifier=str(record_identifier),
        column_name=str(column_name),
        original_value=str(original_value),
        updated_value=str(updated_value),
        repair_method=repair_method,
        action=action,
        operator=operator,
        status=status
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
