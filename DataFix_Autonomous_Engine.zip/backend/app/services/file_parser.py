import csv
import io
import json
from pathlib import Path
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np

def detect_delimiter(sample_bytes: bytes) -> str:
    """Detects delimiter (comma, tab, pipe, semicolon) from text samples."""
    sample_text = sample_bytes[:4096].decode('utf-8', errors='ignore')
    try:
        sniffer = csv.Sniffer()
        dialect = sniffer.sniff(sample_text, delimiters=[',', '\t', '|', ';'])
        return dialect.delimiter
    except Exception:
        # Fallback counting
        counts = {
            ',': sample_text.count(','),
            '\t': sample_text.count('\t'),
            '|': sample_text.count('|'),
            ';': sample_text.count(';')
        }
        best = max(counts, key=counts.get)
        return best if counts[best] > 0 else ','

def parse_dataset_file(file_path: Path, filename: str) -> Tuple[pd.DataFrame, str]:
    """
    Parses an uploaded file into a pandas DataFrame.
    Supports CSV, TSV, XLSX, XLS, PARQUET, and JSON.
    Returns (DataFrame, format_name).
    """
    ext = filename.lower().split('.')[-1]

    if ext in ['csv', 'tsv', 'txt']:
        with open(file_path, 'rb') as f:
            sample = f.read(4096)
        delimiter = detect_delimiter(sample)
        df = pd.read_csv(file_path, delimiter=delimiter, low_memory=False)
        return df, "CSV"

    elif ext in ['xlsx', 'xls']:
        df = pd.read_excel(file_path, engine='openpyxl')
        return df, "XLSX"

    elif ext == 'parquet':
        df = pd.read_parquet(file_path)
        return df, "PARQUET"

    elif ext == 'json':
        try:
            df = pd.read_json(file_path)
        except Exception:
            df = pd.read_json(file_path, lines=True)
        return df, "JSON"

    else:
        raise ValueError(f"Unsupported file format: .{ext}")

def extract_column_metadata(df: pd.DataFrame) -> list[Dict[str, Any]]:
    """Analyzes each column to produce type, missing ratio, unique values, and samples."""
    columns_info = []

    for col in df.columns:
        series = df[col]
        total_rows = len(df)
        null_count = int(series.isna().sum())
        null_percentage = round((null_count / total_rows * 100), 2) if total_rows > 0 else 0.0
        unique_count = int(series.nunique(dropna=True))

        # Infer simplified data type
        dtype_str = str(series.dtype).lower()
        if 'int' in dtype_str:
            inferred_type = 'integer'
        elif 'float' in dtype_str:
            inferred_type = 'float'
        elif 'bool' in dtype_str:
            inferred_type = 'boolean'
        elif 'datetime' in dtype_str:
            inferred_type = 'date'
        elif unique_count < 25 and total_rows > 50:
            inferred_type = 'category'
        else:
            inferred_type = 'string'

        # Check duplicate keys
        has_duplicates = (unique_count < (total_rows - null_count)) and (total_rows > 1)

        # Health status
        if null_percentage > 1.0 or (inferred_type in ['integer', 'float'] and (series < 0).any()):
            status = 'critical'
        elif null_percentage > 0.0 or has_duplicates:
            status = 'warning'
        else:
            status = 'clean'

        # Sample values
        non_null = series.dropna().tolist()
        sample_vals = [v if not pd.isna(v) else None for v in non_null[:3]]

        columns_info.append({
            "name": str(col),
            "type": inferred_type,
            "missingCount": null_count,
            "missingPercentage": null_percentage,
            "uniqueCount": unique_count,
            "sampleValues": sample_vals,
            "hasDuplicates": has_duplicates,
            "status": status
        })

    return columns_info
