import hashlib
import hmac
import os
import time
import secrets
from backend.app.config import settings

def hash_password(password: str) -> str:
    """Secure password hashing using PBKDF2 with HMAC-SHA256 and salt."""
    salt = secrets.token_hex(16)
    key = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    )
    return f"{salt}:{key.hex()}"

get_password_hash = hash_password

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against the stored salt:hash string."""
    try:
        salt, key_hex = hashed_password.split(":")
        new_key = hashlib.pbkdf2_hmac(
            'sha256',
            plain_password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        )
        return hmac.compare_digest(new_key.hex(), key_hex)
    except Exception:
        return False

def create_session_token(email: str, user_id: str) -> tuple[str, int]:
    """Generates a cryptographically strong session token and expiration epoch."""
    random_bytes = secrets.token_urlsafe(32)
    timestamp = int(time.time())
    expires_at = timestamp + (settings.ACCESS_TOKEN_EXPIRE_HOURS * 3600)
    
    # Format: df_jwt_<user_id>_<timestamp>_<random_bytes>
    token = f"df_jwt_{user_id}_{timestamp}_{random_bytes}"
    return token, expires_at * 1000 # milliseconds for frontend compatibility
