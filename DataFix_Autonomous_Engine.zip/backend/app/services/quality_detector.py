import json
import re
from typing import List, Dict, Any, Tuple
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

def run_quality_profiling(df: pd.DataFrame, dataset_id: str) -> List[Dict[str, Any]]:
    """
    Executes analytical data profiling and AI anomaly detection across 5 official capabilities.
    Returns a list of structured QualityIssue dictionaries.
    """
    issues = []
    issue_idx = 1
    total_rows = len(df)

    if total_rows == 0:
        return issues

    # 1. Missing Values Detection
    for col in df.columns:
        null_mask = df[col].isna() | (df[col].astype(str).str.strip().isin(['', 'null', 'NULL', 'None', 'NaN', 'N/A', 'n/a']))
        null_count = int(null_mask.sum())
        if null_count > 0:
            indices = df.index[null_mask].tolist()[:100]
            sample_rows = df[null_mask].head(2).to_dict(orient='records')
            severity = "critical" if (null_count / total_rows) > 0.01 else "high"

            issues.append({
                "id": f"iss_{issue_idx:02d}",
                "category": "missing_values",
                "categoryLabel": "Missing Values",
                "severity": severity,
                "columnName": str(col),
                "affectedRowsCount": null_count,
                "affectedRowIndices": indices,
                "description": f"{null_count} records contain null or empty values in '{col}'. Required for downstream model inference and integrity.",
                "detectedAt": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
                "status": "repair_ready",
                "sampleAffectedRows": sample_rows
            })
            issue_idx += 1

    # 2. Duplicate Records Detection
    dup_mask = df.duplicated(keep=False)
    dup_count = int(dup_mask.sum())
    if dup_count > 0:
        first_col = str(df.columns[0])
        indices = df.index[dup_mask].tolist()[:100]
        sample_rows = df[dup_mask].head(2).to_dict(orient='records')

        issues.append({
            "id": f"iss_{issue_idx:02d}",
            "category": "duplicate_records",
            "categoryLabel": "Duplicate Records",
            "severity": "high",
            "columnName": first_col,
            "affectedRowsCount": dup_count,
            "affectedRowIndices": indices,
            "description": f"{dup_count} duplicate rows detected with identical payload signatures across columns.",
            "detectedAt": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
            "status": "repair_ready",
            "sampleAffectedRows": sample_rows
        })
        issue_idx += 1

    # 3. Invalid Formats (Temporal / Date / Syntax)
    for col in df.columns:
        if 'time' in col.lower() or 'date' in col.lower():
            # Check for strings that fail datetime conversion
            str_series = df[col].astype(str)
            invalid_dates = []
            for idx, val in str_series.items():
                if val in ['nan', 'None', '', 'null']:
                    continue
                if 'invalid' in val.lower() or '/' in val and '-' in val:
                    invalid_dates.append(idx)
                else:
                    try:
                        pd.to_datetime(val)
                    except Exception:
                        invalid_dates.append(idx)

            if len(invalid_dates) > 0:
                sample_rows = df.loc[invalid_dates[:2]].to_dict(orient='records')
                issues.append({
                    "id": f"iss_{issue_idx:02d}",
                    "category": "invalid_formats",
                    "categoryLabel": "Invalid Formats",
                    "severity": "high",
                    "columnName": str(col),
                    "affectedRowsCount": len(invalid_dates),
                    "affectedRowIndices": invalid_dates[:100],
                    "description": f"{len(invalid_dates)} non-conforming timestamps found violating standard ISO 8601 formatting.",
                    "detectedAt": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
                    "status": "repair_ready",
                    "sampleAffectedRows": sample_rows
                })
                issue_idx += 1

    # 4. Inconsistent Categorical Entries (e.g. State names, mixed capitalization)
    for col in df.columns:
        series = df[col].dropna()
        if series.dtype == 'object' and series.nunique() < 40 and total_rows > 30:
            str_vals = series.astype(str).str.strip()
            # Check if uppercase and lowercase or multi-length variants exist
            unique_raw = set(str_vals.unique())
            unique_lower = {v.lower() for v in unique_raw}
            has_mixed_tokens = len(unique_raw) > len(unique_lower) or any(len(v) > 2 for v in unique_raw if 'state' in col.lower())

            if has_mixed_tokens:
                inconsistent_mask = str_vals.str.len() > 2 if 'state' in col.lower() else str_vals != str_vals.str.upper()
                inconsistent_indices = df.index[df[col].isin(str_vals[inconsistent_mask])].tolist()
                sample_rows = df.loc[inconsistent_indices[:2]].to_dict(orient='records')

                issues.append({
                    "id": f"iss_{issue_idx:02d}",
                    "category": "inconsistent_entries",
                    "categoryLabel": "Inconsistent Entries",
                    "severity": "medium",
                    "columnName": str(col),
                    "affectedRowsCount": len(inconsistent_indices),
                    "affectedRowIndices": inconsistent_indices[:100],
                    "description": f"Inconsistent categorical taxonomy detected in '{col}': mixed casing and multi-variant tokens.",
                    "detectedAt": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
                    "status": "repair_ready",
                    "sampleAffectedRows": sample_rows
                })
                issue_idx += 1

    # 5. Statistical Anomalies / Machine Sentinels (Isolation Forest + Boundary Check)
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    for col in num_cols:
        series = df[col].dropna()
        if len(series) < 10:
            continue

        # Check for sentinel errors (e.g. -999999) or physically impossible negatives
        extreme_negatives = series < -999
        anomalies_found = []

        if extreme_negatives.any():
            anomalies_found = df.index[extreme_negatives].tolist()
        else:
            # Run Isolation Forest for multivariate/univariate outlier detection
            try:
                iso = IsolationForest(contamination=0.015, random_state=42)
                preds = iso.fit_predict(series.values.reshape(-1, 1))
                outliers_mask = preds == -1
                if outliers_mask.any():
                    anomalies_found = series[outliers_mask].index.tolist()
            except Exception:
                # Z-score fallback
                mean, std = series.mean(), series.std()
                if std > 0:
                    z_scores = np.abs((series - mean) / std)
                    anomalies_found = series[z_scores > 3.5].index.tolist()

        if len(anomalies_found) > 0:
            sample_rows = df.loc[anomalies_found[:2]].to_dict(orient='records')
            issues.append({
                "id": f"iss_{issue_idx:02d}",
                "category": "anomalies",
                "categoryLabel": "Statistical Anomalies",
                "severity": "critical",
                "columnName": str(col),
                "affectedRowsCount": len(anomalies_found),
                "affectedRowIndices": anomalies_found[:100],
                "description": f"{len(anomalies_found)} statistical anomalies and boundary condition violations flagged in '{col}'.",
                "detectedAt": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
                "status": "repair_ready",
                "sampleAffectedRows": sample_rows
            })
            issue_idx += 1

    return issues
