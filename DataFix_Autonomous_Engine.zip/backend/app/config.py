import os
from pathlib import Path
from dotenv import load_dotenv

APP_DIR = Path(__file__).resolve().parent
BASE_DIR = APP_DIR.parent
ROOT_DIR = BASE_DIR.parent

# Load environment variables: check backend/.env first, then root .env
backend_env = BASE_DIR / ".env"
root_env = ROOT_DIR / ".env"

if backend_env.exists() and backend_env.stat().st_size > 0:
    load_dotenv(backend_env, override=True)
elif root_env.exists() and root_env.stat().st_size > 0:
    load_dotenv(root_env, override=True)
else:
    load_dotenv(backend_env)
    load_dotenv(root_env)


def _get_normalized_database_url() -> str:
    raw_url = os.getenv("DATABASE_URL", "").strip()
    if (raw_url.startswith('"') and raw_url.endswith('"')) or (raw_url.startswith("'") and raw_url.endswith("'")):
        raw_url = raw_url[1:-1].strip()
    
    if not raw_url or "PASTE_YOUR" in raw_url or "YOUR_SUPABASE" in raw_url:
        return f"sqlite:///{BASE_DIR / 'datafix.db'}"
    
    # SQLAlchemy 1.4/2.0 requires postgresql:// instead of legacy postgres://
    if raw_url.startswith("postgres://"):
        raw_url = raw_url.replace("postgres://", "postgresql://", 1)
        
    return raw_url


def _get_normalized_secret_key() -> str:
    raw_key = os.getenv("SECRET_KEY", "").strip()
    if (raw_key.startswith('"') and raw_key.endswith('"')) or (raw_key.startswith("'") and raw_key.endswith("'")):
        raw_key = raw_key[1:-1].strip()
    return raw_key if raw_key else "datafix-hackathon-secure-production-jwt-token-2026"


class Settings:
    PROJECT_NAME: str = "DataFix Autonomous Engine API"
    APP_NAME: str = "DataFix Autonomous Engine API"
    VERSION: str = "2.4.0"
    APP_VERSION: str = "2.4.0"
    API_PREFIX: str = "/api/v1"
    API_V1_STR: str = "/api/v1"
    
    # Database URL: supports Supabase PostgreSQL via env with SQLite fallback
    DATABASE_URL: str = _get_normalized_database_url()
    
    # Secret key for tokens & sessions
    SECRET_KEY: str = _get_normalized_secret_key()
    ACCESS_TOKEN_EXPIRE_HOURS: int = 24
    
    # File Storage Paths
    STORAGE_DIR: Path = BASE_DIR / "storage"
    UPLOAD_DIR: Path = STORAGE_DIR / "uploads"
    REPAIRED_DIR: Path = STORAGE_DIR / "repaired"
    
    # Allowed CORS Origins
    CORS_ORIGINS: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "*"
    ]


settings = Settings()

# Ensure storage directories exist
settings.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
settings.REPAIRED_DIR.mkdir(parents=True, exist_ok=True)
