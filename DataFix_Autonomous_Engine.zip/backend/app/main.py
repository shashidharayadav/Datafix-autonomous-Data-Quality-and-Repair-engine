"""
DataFix - Autonomous Data Quality and Repair Engine
FastAPI Application Entry Point
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.app.config import settings
from backend.app.database import init_db, SessionLocal
from backend.app.routers import (
    auth,
    datasets,
    issues,
    diagnosis,
    repairs,
    validation,
    explainability,
    audit,
    reports
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application startup and shutdown events.
    Initializes database tables, creates storage paths, and runs seed if DB is empty.
    """
    # 1. Initialize SQLite / DB tables
    init_db()

    # 2. Check and run auto-seeding if first run
    try:
        from backend.seed import seed_database
        db = SessionLocal()
        seed_database(db)
        db.close()
    except Exception as e:
        print(f"[DataFix Startup] Seed check note: {e}")

    yield


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Autonomous Data Quality Profiling, Diagnosis, Repair, and Compliance Engine API.",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# Configure CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "*"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", tags=["Health"])
def root():
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "online",
        "docs": "/docs",
        "apiPrefix": settings.API_V1_STR
    }


@app.get("/health", tags=["Health"])
@app.get(f"{settings.API_V1_STR}/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "storage": {
            "uploads": str(settings.UPLOAD_DIR),
            "repaired": str(settings.REPAIRED_DIR)
        }
    }


# Include v1 Routers
api_v1_router = FastAPI()

app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(datasets.router, prefix=settings.API_V1_STR)
app.include_router(issues.router, prefix=settings.API_V1_STR)
app.include_router(diagnosis.router, prefix=settings.API_V1_STR)
app.include_router(repairs.router, prefix=settings.API_V1_STR)
app.include_router(validation.router, prefix=settings.API_V1_STR)
app.include_router(explainability.router, prefix=settings.API_V1_STR)
app.include_router(audit.router, prefix=settings.API_V1_STR)
app.include_router(reports.router, prefix=settings.API_V1_STR)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Fallback error handler ensuring client receives informative error."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": f"Internal Server Error: {str(exc)}"}
    )
