"""
DataFix - Database Connection & Session Management
Supports both Supabase PostgreSQL and local SQLite with connection pooling and health checks.
"""

import sys
from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from backend.app.config import settings

# Engine configuration: configure connection pooling & SSL parameters
is_postgres = settings.DATABASE_URL.startswith("postgresql")

engine_kwargs = {
    "pool_pre_ping": True, # Automatically reconnect dropped idle connections
}

if is_postgres:
    # Supabase PostgreSQL connection pool settings
    engine_kwargs.update({
        "pool_size": 10,
        "max_overflow": 20,
        "pool_recycle": 300, # Recycle connections every 5 minutes
    })
else:
    # SQLite configuration
    engine_kwargs["connect_args"] = {"check_same_thread": False}

try:
    engine = create_engine(settings.DATABASE_URL, **engine_kwargs)
except Exception as e:
    # Fallback to SQLite if connection string initialization fails
    print(f"[Database Config Warning] Could not initialize engine: {e}")
    engine = create_engine(
        f"sqlite:///{settings.STORAGE_DIR.parent / 'datafix.db'}",
        connect_args={"check_same_thread": False},
        pool_pre_ping=True
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency for yielding database session with automatic cleanup."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def test_connection() -> tuple[bool, str]:
    """Tests the database connection without exposing sensitive credentials."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        db_type = "Supabase PostgreSQL" if is_postgres else "SQLite"
        return True, f"Successfully connected to {db_type}"
    except Exception as e:
        err_msg = str(e)
        # Sanitize error to avoid printing passwords if embedded in connection string
        if "@" in err_msg:
            # Mask user:pass before host
            import re
            err_msg = re.sub(r'://[^@]+@', r'://***:***@', err_msg)
        return False, err_msg


def init_db():
    """Initializes all SQLAlchemy models in the target database."""
    from backend.app import models
    Base.metadata.create_all(bind=engine)
