from pydantic import BaseModel
from typing import Dict, Any

class QualityReportSchema(BaseModel):
    id: str
    datasetId: str
    datasetName: str
    generatedAt: str
    initialScore: float
    finalScore: float
    totalRecords: int
    totalIssuesFound: int
    issuesRepaired: int
    issuesRemaining: int
    breakdown: Dict[str, Any]
    executiveSummary: str
    validationStatus: str
