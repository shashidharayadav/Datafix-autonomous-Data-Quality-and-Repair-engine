from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: str
    organization: Optional[str] = "DataFix Enterprise Cloud"
    avatarUrl: Optional[str] = None
    createdAt: str

    class Config:
        from_attributes = True

class AuthSessionResponse(BaseModel):
    token: str
    user: UserResponse
    expiresAt: int

class LoginRequest(BaseModel):
    email: str
    password: str
    rememberMe: Optional[bool] = False

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    confirmPassword: Optional[str] = None
    organization: Optional[str] = "DataFix Organization"

class ForgotPasswordRequest(BaseModel):
    email: str

class ForgotPasswordResponse(BaseModel):
    success: bool
    message: str
