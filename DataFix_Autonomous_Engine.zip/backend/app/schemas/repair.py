from pydantic import BaseModel
from typing import Optional, Any

class RepairProposalSchema(BaseModel):
    id: str
    issueId: Optional[str] = None
    recordId: Any
    columnName: str
    originalValue: Any
    recommendedValue: Any
    repairMethod: str
    repairReason: str
    confidence: int
    status: str # proposed, approved, rejected, applied
    reviewedAt: Optional[str] = None
    reviewedBy: Optional[str] = None

class RepairActionResponse(BaseModel):
    success: bool
    repair: Optional[RepairProposalSchema] = None
    message: str

class BatchRepairActionResponse(BaseModel):
    success: bool
    appliedCount: int
    message: str
