from pydantic import BaseModel
from typing import List, Optional, Any, Dict

class DatasetColumnSchema(BaseModel):
    name: str
    type: str # string, integer, float, date, boolean, category
    missingCount: int
    missingPercentage: float
    uniqueCount: int
    sampleValues: List[Any] = []
    hasDuplicates: Optional[bool] = False
    status: str = "clean" # clean, warning, critical

class DatasetItemSchema(BaseModel):
    id: str
    name: str
    fileName: str
    fileSize: str
    rowCount: int
    columnCount: int
    uploadedAt: str
    format: str # CSV, XLSX, JSON, PARQUET
    status: str # Ready, Processing, Cleaned, Issues Found
    qualityScoreBefore: float
    qualityScoreAfter: Optional[float] = None
    issuesCount: int = 0
    repairedCount: int = 0
    columns: List[DatasetColumnSchema] = []
    rawRows: List[Dict[str, Any]] = []

class QualityIssueSchema(BaseModel):
    id: str
    category: str # missing_values, duplicate_records, invalid_formats, inconsistent_entries, anomalies
    categoryLabel: str
    severity: str # critical, high, medium, low
    columnName: str
    affectedRowsCount: int
    affectedRowIndices: List[int] = []
    description: str
    detectedAt: str
    status: str = "repair_ready"
    sampleAffectedRows: List[Dict[str, Any]] = []

class DiagnosisEntrySchema(BaseModel):
    id: str
    issueId: str
    category: str
    columnName: str
    affectedRecords: int
    identifiedPattern: str
    possibleRootCauses: List[str] = []
    observedEvidence: List[str] = []
    systemExplanation: str
    confidenceScore: float
    impactAssessment: str

class ValidationCheckSchema(BaseModel):
    id: str
    ruleName: str
    category: str
    description: str
    status: str # passed, failed, warning
    recordsTested: int
    failuresFound: int
    details: str

class ExplainabilityRecordSchema(BaseModel):
    id: str
    repairId: str
    recordId: Any
    columnName: str
    originalValue: Any
    newValue: Any
    issueType: str
    repairMethod: str
    whyChosen: str
    algorithmName: str
    supportingEvidence: List[str] = []
    confidenceScore: float
    alternativeOptions: List[Dict[str, Any]] = []

class AuditLogSchema(BaseModel):
    id: str
    timestamp: str
    datasetName: str
    recordIdentifier: Any
    columnName: str
    originalValue: Any
    updatedValue: Any
    repairMethod: str
    action: str
    operator: str
    status: str
