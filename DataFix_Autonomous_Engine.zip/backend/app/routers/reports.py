"""
DataFix - Quality Reports Router
Provides executive and technical data quality summary reports.
"""

import json
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.validation import QualityReport
from backend.app.schemas.report import QualityReportSchema

router = APIRouter(prefix="/datasets", tags=["Reports"])


@router.get("/{dataset_id}/report", response_model=QualityReportSchema)
def get_dataset_quality_report(
    dataset_id: str,
    db: Session = Depends(get_db)
):
    """
    Get executive quality certification report for a dataset.
    """
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    if not target_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No dataset available."
        )

    dataset = db.query(Dataset).filter(Dataset.id == target_id).first()
    if not dataset:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Dataset with ID '{target_id}' not found."
        )

    report = db.query(QualityReport).filter(
        QualityReport.dataset_id == target_id
    ).first()

    if not report:
        breakdown_data = {
            "missing_values": {"detected": dataset.issues_count, "repaired": dataset.repaired_count},
            "duplicate_records": {"detected": 0, "repaired": 0},
            "invalid_formats": {"detected": 0, "repaired": 0},
            "inconsistent_entries": {"detected": 0, "repaired": 0},
            "anomalies": {"detected": 0, "repaired": 0}
        }
        val_status = "Passed with Distinction" if dataset.issues_count == 0 else "Requires Attention"
        return QualityReportSchema(
            id=f"rep_{dataset.id}",
            datasetId=dataset.id,
            datasetName=dataset.name,
            generatedAt=dataset.updated_at.strftime("%Y-%m-%d %H:%M:%S") if dataset.updated_at else dataset.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            initialScore=dataset.quality_score_before,
            finalScore=dataset.quality_score_after,
            totalRecords=dataset.row_count,
            totalIssuesFound=dataset.issues_count,
            issuesRepaired=dataset.repaired_count,
            issuesRemaining=max(0, dataset.issues_count - dataset.repaired_count),
            breakdown=breakdown_data,
            executiveSummary=f"Autonomous data quality audit complete for {dataset.name}. {dataset.repaired_count} of {dataset.issues_count} anomalies resolved.",
            validationStatus=val_status
        )

    breakdown_dict = {}
    try:
        breakdown_dict = json.loads(report.breakdown) if report.breakdown else {}
    except Exception:
        breakdown_dict = {}

    return QualityReportSchema(
        id=report.id,
        datasetId=report.dataset_id,
        datasetName=report.dataset_name,
        generatedAt=report.generated_at,
        initialScore=report.initial_score,
        finalScore=report.final_score,
        totalRecords=report.total_records,
        totalIssuesFound=report.total_issues_found,
        issuesRepaired=report.issues_repaired,
        issuesRemaining=report.issues_remaining,
        breakdown=breakdown_dict,
        executiveSummary=report.executive_summary,
        validationStatus=report.validation_status
    )
