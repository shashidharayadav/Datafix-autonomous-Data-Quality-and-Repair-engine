"""
DataFix - Explainability Router
Provides transparency, algorithmic rationale, and counterfactual considerations
for identified issues and recommended repairs.
"""

import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.validation import ExplainabilityRecord
from backend.app.schemas.dataset import ExplainabilityRecordSchema

router = APIRouter(prefix="/datasets", tags=["Explainability"])


@router.get("/{dataset_id}/explainability", response_model=List[ExplainabilityRecordSchema])
def get_dataset_explainability(
    dataset_id: str,
    db: Session = Depends(get_db)
):
    """
    Get audit and AI explainability records for a dataset.
    """
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    if not target_id:
        return []

    records = db.query(ExplainabilityRecord).filter(
        ExplainabilityRecord.dataset_id == target_id
    ).all()

    results = []
    for exp in records:
        evidence_list = []
        alt_options = []
        try:
            evidence_list = json.loads(exp.supporting_evidence) if exp.supporting_evidence else []
            alt_options = json.loads(exp.alternative_options) if exp.alternative_options else []
        except Exception:
            pass

        results.append(
            ExplainabilityRecordSchema(
                id=exp.id,
                repairId=exp.repair_id,
                recordId=exp.record_id,
                columnName=exp.column_name,
                originalValue=exp.original_value,
                newValue=exp.new_value,
                issueType=exp.issue_type,
                repairMethod=exp.repair_method,
                whyChosen=exp.why_chosen,
                algorithmName=exp.algorithm_name,
                supportingEvidence=evidence_list,
                confidenceScore=exp.confidence_score,
                alternativeOptions=alt_options
            )
        )

    return results
