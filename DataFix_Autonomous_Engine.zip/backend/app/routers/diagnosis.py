import json
from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.diagnosis import DiagnosisEntry
from backend.app.schemas.dataset import DiagnosisEntrySchema

router = APIRouter(prefix="/datasets", tags=["Diagnosis"])

@router.get("/{dataset_id}/diagnoses", response_model=List[DiagnosisEntrySchema])
def get_dataset_diagnoses(dataset_id: str, db: Session = Depends(get_db)):
    """Returns evidence-backed diagnoses distinguishing observed evidence from inferred root causes."""
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    if not target_id:
        return []

    entries = db.query(DiagnosisEntry).filter(DiagnosisEntry.dataset_id == target_id).all()
    results = []

    for diag in entries:
        root_causes = []
        observed_ev = []
        try:
            root_causes = json.loads(diag.possible_root_causes) if diag.possible_root_causes else []
            observed_ev = json.loads(diag.observed_evidence) if diag.observed_evidence else []
        except Exception:
            pass

        results.append(DiagnosisEntrySchema(
            id=diag.id,
            issueId=diag.issue_id,
            category=diag.category,
            columnName=diag.column_name,
            affectedRecords=diag.affected_records,
            identifiedPattern=diag.identified_pattern,
            possibleRootCauses=root_causes,
            observedEvidence=observed_ev,
            systemExplanation=diag.system_explanation,
            confidenceScore=diag.confidence_score,
            impactAssessment=diag.impact_assessment
        ))

    return results
