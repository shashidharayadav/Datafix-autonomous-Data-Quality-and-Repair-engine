import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.issue import QualityIssue
from backend.app.schemas.dataset import QualityIssueSchema

router = APIRouter(prefix="/datasets", tags=["Issues"])

@router.get("/{dataset_id}/issues", response_model=List[QualityIssueSchema])
def get_dataset_issues(dataset_id: str, db: Session = Depends(get_db)):
    """Returns detected quality issues for the specified or active dataset."""
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    if not target_id:
        return []

    issues = db.query(QualityIssue).filter(QualityIssue.dataset_id == target_id).all()
    results = []

    for iss in issues:
        row_indices = []
        sample_rows = []
        try:
            row_indices = json.loads(iss.affected_row_indices) if iss.affected_row_indices else []
            sample_rows = json.loads(iss.sample_affected_rows) if iss.sample_affected_rows else []
        except Exception:
            pass

        results.append(QualityIssueSchema(
            id=iss.id,
            category=iss.category,
            categoryLabel=iss.category_label,
            severity=iss.severity,
            columnName=iss.column_name,
            affectedRowsCount=iss.affected_rows_count,
            affectedRowIndices=row_indices,
            description=iss.description,
            detectedAt=iss.detected_at,
            status=iss.status,
            sampleAffectedRows=sample_rows
        ))

    return results
