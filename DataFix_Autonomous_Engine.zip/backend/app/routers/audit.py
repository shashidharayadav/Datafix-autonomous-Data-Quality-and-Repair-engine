"""
DataFix - Audit Trail Router
Provides immutable compliance and forensic audit logs for dataset mutations and decisions.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.audit import AuditLog
from backend.app.schemas.dataset import AuditLogSchema

router = APIRouter(prefix="/datasets", tags=["Audit Trail"])


@router.get("/{dataset_id}/audit", response_model=List[AuditLogSchema])
def get_dataset_audit_logs(
    dataset_id: str,
    action: Optional[str] = Query(None, description="Filter by action name"),
    db: Session = Depends(get_db)
):
    """
    Get chronological immutable audit trail for a dataset.
    """
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    query = db.query(AuditLog)
    if target_id:
        query = query.filter((AuditLog.dataset_id == target_id) | (AuditLog.dataset_id.is_(None)))

    if action:
        query = query.filter(AuditLog.action == action)

    logs = query.order_by(AuditLog.created_at.desc()).all()
    
    return [
        AuditLogSchema(
            id=l.id,
            timestamp=l.timestamp,
            datasetName=l.dataset_name,
            recordIdentifier=l.record_identifier,
            columnName=l.column_name,
            originalValue=l.original_value,
            updatedValue=l.updated_value,
            repairMethod=l.repair_method,
            action=l.action,
            operator=l.operator,
            status=l.status
        )
        for l in logs
    ]
