"""
DataFix - Validation Checks Router
Provides validation matrix endpoints for evaluated and repaired datasets.
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.dataset import Dataset
from backend.app.models.validation import ValidationCheck
from backend.app.schemas.dataset import ValidationCheckSchema

router = APIRouter(prefix="/datasets", tags=["Validations"])


@router.get("/{dataset_id}/validations", response_model=List[ValidationCheckSchema])
def get_dataset_validations(
    dataset_id: str,
    db: Session = Depends(get_db)
):
    """
    Get all pre/post repair validation matrix checks for a dataset.
    """
    if dataset_id == "active":
        active_ds = db.query(Dataset).order_by(Dataset.created_at.desc()).first()
        target_id = active_ds.id if active_ds else None
    else:
        target_id = dataset_id

    if not target_id:
        return []

    validations = db.query(ValidationCheck).filter(
        ValidationCheck.dataset_id == target_id
    ).all()

    return [
        ValidationCheckSchema(
            id=v.id,
            ruleName=v.rule_name,
            category=v.category,
            description=v.description,
            status=v.status,
            recordsTested=v.records_tested,
            failuresFound=v.failures_found,
            details=v.details
        )
        for v in validations
    ]
