from sqlalchemy import Column, String, Integer, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database import Base

class RepairProposal(Base):
    __tablename__ = "repair_proposals"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    issue_id = Column(String, nullable=True)
    record_id = Column(String, nullable=False) # e.g. row index or ID
    column_name = Column(String, nullable=False)
    original_value = Column(Text, nullable=True)
    recommended_value = Column(Text, nullable=True)
    repair_method = Column(Text, nullable=False)
    repair_reason = Column(Text, nullable=False)
    confidence = Column(Integer, default=95)
    status = Column(String, default="proposed", index=True) # proposed, approved, rejected, applied
    reviewed_at = Column(String, nullable=True)
    reviewed_by = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    dataset = relationship("Dataset", back_populates="repairs")
    executions = relationship("RepairExecutionHistory", back_populates="repair", cascade="all, delete-orphan")

class RepairExecutionHistory(Base):
    __tablename__ = "repair_execution_history"

    id = Column(String, primary_key=True, index=True)
    repair_id = Column(String, ForeignKey("repair_proposals.id", ondelete="CASCADE"), nullable=False, index=True)
    execution_status = Column(String, default="Completed")
    original_value = Column(Text, nullable=True)
    final_value = Column(Text, nullable=True)
    execution_timestamp = Column(String, default=lambda: datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    operator = Column(String, default="DataFix Autonomous Engine")
    execution_details = Column(Text, nullable=True)

    repair = relationship("RepairProposal", back_populates="executions")
