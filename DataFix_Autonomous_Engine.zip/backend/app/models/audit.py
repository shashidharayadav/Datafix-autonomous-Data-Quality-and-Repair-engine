from sqlalchemy import Column, String, Text, DateTime
from datetime import datetime
from backend.app.database import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, nullable=True, index=True)
    timestamp = Column(String, default=lambda: datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    dataset_name = Column(String, nullable=False)
    record_identifier = Column(String, nullable=False)
    column_name = Column(String, nullable=False)
    original_value = Column(Text, nullable=True)
    updated_value = Column(Text, nullable=True)
    repair_method = Column(Text, nullable=False)
    action = Column(String, nullable=False) # Auto-Repair, Manual Approval, Bulk Patch, Rejection, Rollback
    operator = Column(String, default="DataFix Autonomous Engine")
    status = Column(String, default="Completed")
    created_at = Column(DateTime, default=datetime.utcnow)
