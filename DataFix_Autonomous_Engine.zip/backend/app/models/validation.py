from sqlalchemy import Column, String, Integer, Float, Text, ForeignKey
from sqlalchemy.orm import relationship
from backend.app.database import Base

class ValidationCheck(Base):
    __tablename__ = "validation_checks"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    rule_name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    status = Column(String, default="passed") # passed, failed, warning
    records_tested = Column(Integer, default=0)
    failures_found = Column(Integer, default=0)
    details = Column(Text, nullable=False)

    dataset = relationship("Dataset", back_populates="validations")

class ExplainabilityRecord(Base):
    __tablename__ = "explainability_records"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    repair_id = Column(String, nullable=False)
    record_id = Column(String, nullable=False)
    column_name = Column(String, nullable=False)
    original_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    issue_type = Column(String, nullable=False)
    repair_method = Column(Text, nullable=False)
    why_chosen = Column(Text, nullable=False)
    algorithm_name = Column(String, nullable=False)
    supporting_evidence = Column(Text, default="[]") # JSON list of string evidence
    confidence_score = Column(Float, default=95.0)
    alternative_options = Column(Text, default="[]") # JSON list of dicts

class QualityReport(Base):
    __tablename__ = "quality_reports"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    dataset_name = Column(String, nullable=False)
    generated_at = Column(String, nullable=False)
    initial_score = Column(Float, nullable=False)
    final_score = Column(Float, nullable=False)
    total_records = Column(Integer, default=0)
    total_issues_found = Column(Integer, default=0)
    issues_repaired = Column(Integer, default=0)
    issues_remaining = Column(Integer, default=0)
    breakdown = Column(Text, default="{}") # JSON breakdown
    executive_summary = Column(Text, nullable=False)
    validation_status = Column(String, default="Passed with Distinction")
