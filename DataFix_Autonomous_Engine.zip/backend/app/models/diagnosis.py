from sqlalchemy import Column, String, Integer, Float, Text, ForeignKey
from sqlalchemy.orm import relationship
from backend.app.database import Base

class DiagnosisEntry(Base):
    __tablename__ = "diagnosis_entries"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    issue_id = Column(String, ForeignKey("quality_issues.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String, nullable=False)
    column_name = Column(String, nullable=False)
    affected_records = Column(Integer, default=0)
    identified_pattern = Column(Text, nullable=False)
    possible_root_causes = Column(Text, default="[]") # JSON array of inferred causes
    observed_evidence = Column(Text, default="[]") # JSON array of direct observations
    system_explanation = Column(Text, nullable=False)
    confidence_score = Column(Float, default=95.0)
    impact_assessment = Column(String, default="High Risk") # High Risk, Moderate Risk, Low Risk

    issue = relationship("QualityIssue", back_populates="diagnoses")
