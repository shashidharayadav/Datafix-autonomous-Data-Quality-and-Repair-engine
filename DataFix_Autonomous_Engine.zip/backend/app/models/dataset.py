from sqlalchemy import Column, String, Integer, Float, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database import Base

class Dataset(Base):
    __tablename__ = "datasets"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)
    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_size = Column(String, nullable=False)
    row_count = Column(Integer, default=0)
    column_count = Column(Integer, default=0)
    uploaded_at = Column(String, default=lambda: datetime.utcnow().strftime("%Y-%m-%d %H:%M"))
    format = Column(String, nullable=False) # CSV, XLSX, JSON, PARQUET
    status = Column(String, default="Ready") # Ready, Processing, Cleaned, Issues Found
    quality_score_before = Column(Float, default=65.0)
    quality_score_after = Column(Float, nullable=True)
    issues_count = Column(Integer, default=0)
    repaired_count = Column(Integer, default=0)
    uploaded_by = Column(String, nullable=True)
    repaired_file_path = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    columns = relationship("DatasetColumn", back_populates="dataset", cascade="all, delete-orphan")
    issues = relationship("QualityIssue", back_populates="dataset", cascade="all, delete-orphan")
    repairs = relationship("RepairProposal", back_populates="dataset", cascade="all, delete-orphan")
    validations = relationship("ValidationCheck", back_populates="dataset", cascade="all, delete-orphan")

class DatasetColumn(Base):
    __tablename__ = "dataset_columns"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False) # string, integer, float, date, boolean, category
    missing_count = Column(Integer, default=0)
    missing_percentage = Column(Float, default=0.0)
    unique_count = Column(Integer, default=0)
    sample_values = Column(Text, default="[]") # JSON list of sample values
    has_duplicates = Column(Boolean, default=False)
    status = Column(String, default="clean") # clean, warning, critical

    dataset = relationship("Dataset", back_populates="columns")
