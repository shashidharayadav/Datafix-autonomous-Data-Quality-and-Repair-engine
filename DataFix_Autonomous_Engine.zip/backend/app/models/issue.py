from sqlalchemy import Column, String, Integer, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database import Base

class QualityIssue(Base):
    __tablename__ = "quality_issues"

    id = Column(String, primary_key=True, index=True)
    dataset_id = Column(String, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String, nullable=False, index=True) # missing_values, duplicate_records, invalid_formats, inconsistent_entries, anomalies
    category_label = Column(String, nullable=False)
    severity = Column(String, default="medium") # critical, high, medium, low
    column_name = Column(String, nullable=False, index=True)
    affected_rows_count = Column(Integer, default=0)
    affected_row_indices = Column(Text, default="[]") # JSON list of row indices
    description = Column(Text, nullable=False)
    detected_at = Column(String, default=lambda: datetime.utcnow().strftime("%Y-%m-%d %H:%M"))
    status = Column(String, default="open") # open, investigating, repair_ready, resolved
    sample_affected_rows = Column(Text, default="[]") # JSON list of dicts

    dataset = relationship("Dataset", back_populates="issues")
    diagnoses = relationship("DiagnosisEntry", back_populates="issue", cascade="all, delete-orphan")
