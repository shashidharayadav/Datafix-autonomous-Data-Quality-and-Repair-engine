"""
DataFix - Safe & Idempotent SQLite to Supabase PostgreSQL Migration Script
Preserves primary keys, relationships, and provides dry-run verification.
"""

import sys
import argparse
import sqlite3
from pathlib import Path
from sqlalchemy import text
from backend.app.config import settings, BASE_DIR
from backend.app.database import engine, Base, init_db
from backend.app import models

SQLITE_PATH = BASE_DIR / "datafix.db"

# Migration sequence respecting Foreign Key dependency constraints
TABLE_SEQUENCE = [
    "users",
    "datasets",
    "dataset_columns",
    "quality_issues",
    "diagnosis_entries",
    "repair_proposals",
    "repair_execution_history",
    "validation_checks",
    "explainability_records",
    "quality_reports",
    "audit_logs"
]


def run_migration(dry_run: bool = True):
    print("=" * 65)
    print(" DATAFIX — SQLITE TO SUPABASE POSTGRESQL MIGRATION TOOL")
    print("=" * 65)
    print(f"Mode: {'[DRY RUN - PREVIEW ONLY]' if dry_run else '[LIVE EXECUTION]'}")
    print(f"Source (SQLite): {SQLITE_PATH}")

    if not SQLITE_PATH.exists():
        print(f"Error: SQLite source file '{SQLITE_PATH}' not found.")
        return False

    is_postgres = settings.DATABASE_URL.startswith("postgresql")
    if not is_postgres:
        print("\nNotice: Current DATABASE_URL is NOT pointing to PostgreSQL/Supabase.")
        print(f"Current target: {settings.DATABASE_URL.split('///')[0]}...")
        print("Please configure your DATABASE_URL in backend/.env before migrating.")
        return False

    # 1. Connect to SQLite
    sqlite_conn = sqlite3.connect(SQLITE_PATH)
    sqlite_conn.row_factory = sqlite3.Row
    sqlite_cur = sqlite_conn.cursor()

    # 2. Test PostgreSQL Connection & Create Tables
    print("\n[Step 1/3] Connecting to Supabase PostgreSQL & verifying schema...")
    try:
        with engine.connect() as pg_conn:
            pg_conn.execute(text("SELECT 1"))
        print("  -> Connected successfully to Supabase PostgreSQL.")
    except Exception as e:
        err_msg = str(e)
        if "@" in err_msg:
            import re
            err_msg = re.sub(r'://[^@]+@', r'://***:***@', err_msg)
        print(f"  -> Connection Failed: {err_msg}")
        return False

    if not dry_run:
        print("  -> Initializing PostgreSQL tables if not present...")
        init_db()
        print("  -> PostgreSQL schema verified.")

    # 3. Analyze and transfer tables
    print("\n[Step 2/3] Inspecting tables and planning data transfer...")
    migration_summary = {}

    with engine.connect() as pg_conn:
        for table in TABLE_SEQUENCE:
            # Check source SQLite rows
            try:
                sqlite_cur.execute(f"SELECT * FROM {table}")
                sqlite_rows = sqlite_cur.fetchall()
                source_count = len(sqlite_rows)
            except Exception:
                sqlite_rows = []
                source_count = 0

            # Check target PG rows if table exists
            target_count = 0
            existing_ids = set()
            try:
                res = pg_conn.execute(text(f"SELECT id FROM {table}"))
                existing_ids = {str(r[0]) for r in res.fetchall()}
                target_count = len(existing_ids)
            except Exception:
                # Table might not exist yet in dry run
                pass

            to_insert = [row for row in sqlite_rows if str(row["id"]) not in existing_ids]
            to_skip = source_count - len(to_insert)

            migration_summary[table] = {
                "source": source_count,
                "target_before": target_count,
                "to_insert": len(to_insert),
                "to_skip": to_skip,
                "rows": to_insert
            }

            print(f"  * {table:25}: SQLite={source_count:3} | PG Existing={target_count:3} | To Migrate={len(to_insert):3} | Skipped={to_skip:3}")

    # 4. Execute transfer if not dry run
    print("\n[Step 3/3] Migration Execution Status...")
    if dry_run:
        total_to_migrate = sum(v["to_insert"] for v in migration_summary.values())
        print(f"\n[DRY RUN COMPLETE] Total new records pending migration: {total_to_migrate}")
        print("To apply this migration to your live Supabase database, run:")
        print("    python -m backend.migrate_to_postgres --apply")
        sqlite_conn.close()
        return True

    # Live migration
    total_migrated = 0
    with engine.begin() as pg_conn:
        for table in TABLE_SEQUENCE:
            records = migration_summary[table]["rows"]
            if not records:
                continue

            columns = list(records[0].keys())
            cols_clause = ", ".join(f'"{c}"' for c in columns)
            vals_clause = ", ".join(f":{c}" for c in columns)
            insert_sql = text(f'INSERT INTO "{table}" ({cols_clause}) VALUES ({vals_clause}) ON CONFLICT DO NOTHING')

            for r in records:
                row_dict = dict(r)
                pg_conn.execute(insert_sql, row_dict)
                total_migrated += 1

    print(f"\n[MIGRATION SUCCESS] Migrated {total_migrated} records into Supabase PostgreSQL.")
    sqlite_conn.close()
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DataFix SQLite to PostgreSQL Migration")
    parser.add_argument("--apply", action="store_true", help="Execute live migration (default is dry-run)")
    args = parser.parse_args()

    run_migration(dry_run=not args.apply)
