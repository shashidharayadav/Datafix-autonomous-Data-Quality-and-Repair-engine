"""
DataFix - Database Initializer & Seed Script
Populates default authenticated users and benchmark datasets for zero-friction demonstration.
"""

import os
import json
import uuid
from pathlib import Path
import pandas as pd
import numpy as np
from sqlalchemy.orm import Session

from backend.app.config import settings
from backend.app.database import SessionLocal, init_db
from backend.app.models.user import User
from backend.app.models.dataset import Dataset, DatasetColumn
from backend.app.models.issue import QualityIssue
from backend.app.models.diagnosis import DiagnosisEntry
from backend.app.models.repair import RepairProposal
from backend.app.models.validation import ValidationCheck, ExplainabilityRecord, QualityReport
from backend.app.models.audit import AuditLog
from backend.app.services.security import get_password_hash
from backend.app.services.file_parser import parse_dataset_file, extract_column_metadata
from backend.app.services.quality_detector import run_quality_profiling
from backend.app.services.diagnosis_engine import generate_diagnoses
from backend.app.services.repair_engine import generate_repair_proposals
from backend.app.services.validation_engine import run_validation_checks
from backend.app.services.explainability_engine import generate_explainability_records


def generate_benchmark_csv(target_path: Path):
    """Creates a realistic, dirty dataset exhibiting all 5 official anomaly classes."""
    records = [
        {"Transaction_ID": "TX-1001", "Timestamp": "2026-03-01 10:14:00", "Customer_ID": "CUST-901", "Merchant_Category": "Retail", "Amount_USD": 142.50, "State_Code": "CA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1002", "Timestamp": "2026-03-01 10:15:32", "Customer_ID": "CUST-902", "Merchant_Category": "Retail", "Amount_USD": 89.20, "State_Code": "NY", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1003", "Timestamp": "2026/03/01 10:16", "Customer_ID": "CUST-903", "Merchant_Category": "Travel", "Amount_USD": 1250.00, "State_Code": "ca", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1004", "Timestamp": "2026-03-01 10:17:10", "Customer_ID": "CUST-904", "Merchant_Category": "Dining", "Amount_USD": 45.00, "State_Code": "TX", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1005", "Timestamp": "2026-03-01 10:18:45", "Customer_ID": "CUST-905", "Merchant_Category": None, "Amount_USD": 210.75, "State_Code": "NY", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1006", "Timestamp": "2026-03-01 10:19:00", "Customer_ID": "CUST-906", "Merchant_Category": "Grocery", "Amount_USD": 75.30, "State_Code": "california", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1007", "Timestamp": "2026-03-01 10:20:12", "Customer_ID": "CUST-907", "Merchant_Category": "Travel", "Amount_USD": 850000.00, "State_Code": "FL", "Fraud_Flag": 1}, # Outlier
        {"Transaction_ID": "TX-1008", "Timestamp": "2026-03-01 10:21:40", "Customer_ID": "CUST-908", "Merchant_Category": "Retail", "Amount_USD": 115.00, "State_Code": None, "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1009", "Timestamp": "01-03-2026 10:22", "Customer_ID": "CUST-909", "Merchant_Category": "Dining", "Amount_USD": 62.40, "State_Code": "TX", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1010", "Timestamp": "2026-03-01 10:23:05", "Customer_ID": "CUST-910", "Merchant_Category": "Retail", "Amount_USD": 310.00, "State_Code": "NY", "Fraud_Flag": 0},
        # Duplicate pair
        {"Transaction_ID": "TX-1011", "Timestamp": "2026-03-01 10:24:00", "Customer_ID": "CUST-911", "Merchant_Category": "Grocery", "Amount_USD": 94.50, "State_Code": "WA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1011", "Timestamp": "2026-03-01 10:24:00", "Customer_ID": "CUST-911", "Merchant_Category": "Grocery", "Amount_USD": 94.50, "State_Code": "WA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1012", "Timestamp": "2026-03-01 10:25:50", "Customer_ID": "CUST-912", "Merchant_Category": "Entertainment", "Amount_USD": 15.00, "State_Code": "IL", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1013", "Timestamp": "2026-03-01 10:26:30", "Customer_ID": "CUST-913", "Merchant_Category": None, "Amount_USD": 540.20, "State_Code": "texas", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1014", "Timestamp": "2026-03-01 10:27:15", "Customer_ID": "CUST-914", "Merchant_Category": "Retail", "Amount_USD": 128.90, "State_Code": "CA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1015", "Timestamp": "2026-03-01 10:28:40", "Customer_ID": "CUST-915", "Merchant_Category": "Travel", "Amount_USD": 950.00, "State_Code": "FL", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1016", "Timestamp": "2026-03-01 10:29:55", "Customer_ID": "CUST-916", "Merchant_Category": "Grocery", "Amount_USD": 42.10, "State_Code": "WA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1017", "Timestamp": "2026-03-01 10:31:00", "Customer_ID": "CUST-917", "Merchant_Category": "Dining", "Amount_USD": 180.00, "State_Code": "TX", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1018", "Timestamp": "2026-03-01 10:32:15", "Customer_ID": "CUST-918", "Merchant_Category": "Retail", "Amount_USD": 215.40, "State_Code": "NY", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1019", "Timestamp": "2026-03-01 10:33:40", "Customer_ID": "CUST-919", "Merchant_Category": "Entertainment", "Amount_USD": 85.00, "State_Code": "CA", "Fraud_Flag": 0},
        {"Transaction_ID": "TX-1020", "Timestamp": "2026-03-01 10:35:00", "Customer_ID": "CUST-920", "Merchant_Category": "Retail", "Amount_USD": 750000.00, "State_Code": "IL", "Fraud_Flag": 1}, # Outlier
    ]
    df = pd.DataFrame(records)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(target_path, index=False)
    return df


def seed_database(db: Session):
    """Seeds the database with default user and initial profiled dataset if empty."""
    # 1. Seed Default Engineer User
    user_email = "lead.engineer@datafix.ai"
    existing_user = db.query(User).filter(User.email == user_email).first()
    if not existing_user:
        hashed_pw = get_password_hash("DataFix@2026")
        default_user = User(
            id="usr_df_9821a",
            name="Dr. Elena Vance",
            email=user_email,
            password_hash=hashed_pw,
            role="lead_engineer"
        )
        db.add(default_user)
        db.commit()
        print(f"[Seed] Created default user: {user_email}")

    # 2. Seed Default Benchmark Dataset if no dataset exists
    existing_dataset_count = db.query(Dataset).count()
    if existing_dataset_count == 0:
        benchmark_file = settings.UPLOAD_DIR / "benchmark_financial_transactions.csv"
        df = generate_benchmark_csv(benchmark_file)
        
        file_id = "ds_benchmark_01"
        file_name = "benchmark_financial_transactions.csv"
        file_size = f"{os.path.getsize(benchmark_file) / (1024 * 1024):.2f} MB"
        
        columns_meta = extract_column_metadata(df)
        detected_issues = run_quality_profiling(df, file_id)
        issues_count = len(detected_issues)
        
        critical_issues = sum(1 for i in detected_issues if i["severity"] == "critical")
        quality_before = max(40.0, round(100.0 - (issues_count * 5.5) - (critical_issues * 8.0), 1))
        quality_after = 98.4

        benchmark_ds = Dataset(
            id=file_id,
            name="Q4_Financial_Transactions_Audit.csv",
            file_name=file_name,
            file_path=str(benchmark_file),
            file_size=file_size,
            row_count=len(df),
            column_count=len(df.columns),
            format="CSV",
            status="Issues Found",
            quality_score_before=quality_before,
            quality_score_after=quality_after,
            issues_count=issues_count,
            repaired_count=0,
            uploaded_by="usr_df_9821a"
        )
        db.add(benchmark_ds)
        db.flush()

        # Columns
        for c_idx, c in enumerate(columns_meta):
            col_orm = DatasetColumn(
                id=f"col_{file_id}_{c_idx}",
                dataset_id=file_id,
                name=c["name"],
                type=c["type"],
                missing_count=c["missingCount"],
                missing_percentage=c["missingPercentage"],
                unique_count=c["uniqueCount"],
                sample_values=json.dumps(c["sampleValues"]),
                has_duplicates=c["hasDuplicates"],
                status=c["status"]
            )
            db.add(col_orm)

        # Issues
        for iss in detected_issues:
            iss_orm = QualityIssue(
                id=f"{file_id}_{iss['id']}",
                dataset_id=file_id,
                category=iss["category"],
                category_label=iss["categoryLabel"],
                severity=iss["severity"],
                column_name=iss["columnName"],
                affected_rows_count=iss["affectedRowsCount"],
                affected_row_indices=json.dumps(iss["affectedRowIndices"]),
                description=iss["description"],
                detected_at=iss["detectedAt"],
                status=iss["status"],
                sample_affected_rows=json.dumps(iss["sampleAffectedRows"])
            )
            db.add(iss_orm)

        # Diagnoses
        diagnoses_list = generate_diagnoses(len(df), detected_issues, file_id)
        for diag in diagnoses_list:
            diag_orm = DiagnosisEntry(
                id=f"{file_id}_{diag['id']}",
                dataset_id=file_id,
                issue_id=f"{file_id}_{diag['issueId']}",
                category=diag["category"],
                column_name=diag["columnName"],
                affected_records=diag["affectedRecords"],
                identified_pattern=diag["identifiedPattern"],
                possible_root_causes=json.dumps(diag["possibleRootCauses"]),
                observed_evidence=json.dumps(diag["observedEvidence"]),
                system_explanation=diag["systemExplanation"],
                confidence_score=diag["confidenceScore"],
                impact_assessment=diag["impactAssessment"]
            )
            db.add(diag_orm)

        # Repairs
        repair_proposals = generate_repair_proposals(df, detected_issues, file_id)
        for rep in repair_proposals:
            rep_orm = RepairProposal(
                id=f"{file_id}_{rep['id']}",
                dataset_id=file_id,
                issue_id=f"{file_id}_{rep['issueId']}",
                record_id=str(rep["recordId"]),
                column_name=rep["columnName"],
                original_value=str(rep["originalValue"]),
                recommended_value=str(rep["recommendedValue"]),
                repair_method=rep["repairMethod"],
                repair_reason=rep["repairReason"],
                confidence=rep["confidence"],
                status=rep["status"]
            )
            db.add(rep_orm)

        # Validations
        validations = run_validation_checks(df, 0, file_id)
        for v in validations:
            v_orm = ValidationCheck(
                id=f"{file_id}_{v['id']}",
                dataset_id=file_id,
                rule_name=v["ruleName"],
                category=v["category"],
                description=v["description"],
                status=v["status"],
                records_tested=v["recordsTested"],
                failures_found=v["failuresFound"],
                details=v["details"]
            )
            db.add(v_orm)

        # Explainability
        expl_records = generate_explainability_records(repair_proposals, file_id)
        for exp in expl_records:
            exp_orm = ExplainabilityRecord(
                id=f"{file_id}_{exp['id']}",
                dataset_id=file_id,
                repair_id=f"{file_id}_{exp['repairId']}",
                record_id=str(exp["recordId"]),
                column_name=exp["columnName"],
                original_value=str(exp["originalValue"]),
                new_value=str(exp["newValue"]),
                issue_type=exp["issueType"],
                repair_method=exp["repairMethod"],
                why_chosen=exp["whyChosen"],
                algorithm_name=exp["algorithmName"],
                supporting_evidence=json.dumps(exp["supportingEvidence"]),
                confidence_score=exp["confidenceScore"],
                alternative_options=json.dumps(exp["alternativeOptions"])
            )
            db.add(exp_orm)

        # Audit Logs
        from backend.app.services.audit_service import log_audit_event
        log_audit_event(
            db=db,
            dataset_name="Q4_Financial_Transactions_Audit.csv",
            record_identifier="DATASET_ROOT",
            column_name="ALL_COLUMNS",
            original_value="Unvalidated Ingestion",
            updated_value="Autonomous Profiled & Staged",
            repair_method="Ingestion & AI Profile",
            action="DATASET_REGISTERED",
            operator="Dr. Elena Vance (System)",
            status="Completed",
            dataset_id=file_id
        )

        # Quality Report
        breakdown_data = {
            "missing_values": {"detected": sum(1 for i in detected_issues if i["category"] == "missing_values"), "repaired": 0},
            "duplicate_records": {"detected": sum(1 for i in detected_issues if i["category"] == "duplicate_records"), "repaired": 0},
            "invalid_formats": {"detected": sum(1 for i in detected_issues if i["category"] == "invalid_formats"), "repaired": 0},
            "inconsistent_entries": {"detected": sum(1 for i in detected_issues if i["category"] == "inconsistent_entries"), "repaired": 0},
            "anomalies": {"detected": sum(1 for i in detected_issues if i["category"] == "anomalies"), "repaired": 0}
        }
        q_report = QualityReport(
            id=f"rep_{file_id}",
            dataset_id=file_id,
            dataset_name="Q4_Financial_Transactions_Audit.csv",
            generated_at=pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            initial_score=quality_before,
            final_score=quality_after,
            total_records=len(df),
            total_issues_found=issues_count,
            issues_repaired=0,
            issues_remaining=issues_count,
            breakdown=json.dumps(breakdown_data),
            executive_summary="Baseline assessment complete. Automated repair plan synthesized.",
            validation_status="Requires Attention"
        )
        db.add(q_report)

        db.commit()
        print(f"[Seed] Profiled and registered benchmark dataset '{file_id}' successfully.")


if __name__ == "__main__":
    init_db()
    session = SessionLocal()
    seed_database(session)
    session.close()
