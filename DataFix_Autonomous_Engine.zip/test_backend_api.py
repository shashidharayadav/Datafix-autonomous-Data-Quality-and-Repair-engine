import urllib.request
import json
import sys

def test(url, method='GET', data=None):
    req = urllib.request.Request(url, method=method)
    if data:
        req.add_header('Content-Type', 'application/json')
        body = json.dumps(data).encode('utf-8')
    else:
        body = None
    try:
        with urllib.request.urlopen(req, data=body) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            print(f"[SUCCESS {resp.status}] {method} {url}")
            return res
    except urllib.error.HTTPError as e:
        print(f"[FAILED {e.code}] {method} {url}: {e.read().decode('utf-8')}")
        raise e

print("--- 1. Testing Health ---")
test('http://127.0.0.1:8000/health')

print("\n--- 2. Testing Auth Login ---")
login_res = test('http://127.0.0.1:8000/api/v1/auth/login', 'POST', {'email': 'lead.engineer@datafix.ai', 'password': 'DataFix@2026'})
print(f"Logged in user: {login_res['user']['name']} ({login_res['user']['role']})")

print("\n--- 3. Testing Datasets Listing & Active Item ---")
datasets = test('http://127.0.0.1:8000/api/v1/datasets')
ds_id = datasets[0]['id']
print(f"Dataset: {datasets[0]['name']}, Rows: {datasets[0]['rowCount']}, Columns: {datasets[0]['columnCount']}, Issues: {datasets[0]['issuesCount']}")

active_ds = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}')
print(f"Columns profiled: {len(active_ds['columns'])}, Preview rows: {len(active_ds['rawRows'])}")

print("\n--- 4. Testing Quality Issues ---")
issues = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/issues')
print(f"Issues detected: {len(issues)}")

print("\n--- 5. Testing Diagnoses ---")
diagnoses = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/diagnoses')
print(f"Diagnoses generated: {len(diagnoses)}")

print("\n--- 6. Testing Repairs Proposals & Approval Flow ---")
repairs = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/repairs')
print(f"Repairs proposed: {len(repairs)}")
if len(repairs) > 0:
    first_rep_id = repairs[0]['id']
    test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/repairs/{first_rep_id}/approve', 'POST')
    print(f"Approved repair proposal: {first_rep_id}")

print("\n--- 7. Testing Validations Matrix ---")
validations = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/validations')
print(f"Validation checks: {len(validations)}")

print("\n--- 8. Testing Explainability Records ---")
explainability = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/explainability')
print(f"Explainability records: {len(explainability)}")

print("\n--- 9. Testing Audit Trail ---")
audit_trail = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/audit')
print(f"Audit log entries: {len(audit_trail)}")

print("\n--- 10. Testing Executive Quality Report ---")
report = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/report')
print(f"Report: Status {report['validationStatus']}, Score: {report['initialScore']} -> {report['finalScore']}")

print("\n--- 11. Testing Apply Batch Repairs ---")
batch_res = test(f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/repairs/apply-batch', 'POST')
print(f"Batch repair applied: {batch_res['appliedCount']} fixes applied. Download path: {batch_res.get('downloadUrl')}")

print("\n--- 12. Testing Download Repaired Dataset ---")
download_url = f'http://127.0.0.1:8000/api/v1/datasets/{ds_id}/download'
req = urllib.request.Request(download_url)
with urllib.request.urlopen(req) as resp:
    data_bytes = resp.read()
    print(f"[SUCCESS {resp.status}] Downloaded cleaned dataset: {len(data_bytes)} bytes")

print("\nALL BACKEND API TESTS COMPLETED SUCCESSFULLY!")
