# DataFix — Autonomous Data Quality and Repair Engine

**DataFix** is an autonomous data quality engineering system designed to ingest, profile, diagnose, repair, and validate high-scale enterprise datasets with audit-grade explainability.

---

## Architecture Overview

```
                      ┌───────────────────────────┐
                      │  React + Vite Frontend    │
                      │  (Black + White + Teal)   │
                      └─────────────┬─────────────┘
                                    │ Reverse Proxy (/api)
                                    ▼
                      ┌───────────────────────────┐
                      │    FastAPI Backend API    │
                      │      (/api/v1/...)        │
                      └─────────────┬─────────────┘
                                    │
          ┌─────────────────────────┼─────────────────────────┐
          ▼                         ▼                         ▼
┌───────────────────┐     ┌───────────────────┐     ┌───────────────────┐
│ AI / ML Profiler  │     │   Repair Engine   │     │ Validation Matrix │
│ (IsolationForest, │     │ (MICE Imputation, │     │ (6 Core Rules,    │
│  Z-Score, Regex)  │     │  Deduplication)   │     │  Explainability)  │
└───────────────────┘     └───────────────────┘     └───────────────────┘
                                    │
                                    ▼
                      ┌───────────────────────────┐
                      │  PostgreSQL / Supabase    │
                      │  (or zero-config SQLite)  │
                      └───────────────────────────┘
```

---

## Key Features

1. **Autonomous Defect Profiling:**
   - Detects missing values with severity indicators.
   - Exact duplicate record detection via full payload hashing.
   - Non-compliant temporal formats (ISO 8601 validation).
   - Inconsistent categorical taxonomy & case normalization.
   - Machine learning statistical anomaly detection via Scikit-Learn `IsolationForest` and Z-score boundaries.
2. **Deterministic Root-Cause Diagnosis:**
   - Separates empirical observed evidence from inferred root causes with confidence scoring.
3. **Audit-Grade Repair Engine:**
   - MICE (Multivariate Imputation by Chained Equations) for numerical attributes.
   - Mode frequency imputation for categorical variables.
   - Non-destructive processing: original raw files remain untouched; cleaned files are saved separately in `backend/storage/repaired/`.
4. **Interactive Validation & Counterfactual Explainability:**
   - 6-rule validation matrix with before/after cleanliness scoring.
   - Mathematical justification and evaluated counterfactual alternatives.
5. **Immutable Forensic Audit Trail:**
   - Full timeline logging for regulatory compliance and audit tracking.

---

## Quickstart Guide

### 1. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
pip install -r requirements.txt

# Start FastAPI server (runs on http://127.0.0.1:8000)
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```

- **Swagger Documentation:** `http://127.0.0.1:8000/docs`
- **Pre-seeded Account:** `lead.engineer@datafix.ai` / `DataFix@2026`

### 2. Frontend Setup

```bash
# Install frontend dependencies
npm install

# Start Vite dev server (runs on http://localhost:5173)
npm run dev
```

The frontend automatically proxies `/api` calls directly to the FastAPI server on port 8000.

---

## Supabase PostgreSQL Configuration & Migration

1. Add your Supabase connection URI in `backend/.env`:
   ```env
   DATABASE_URL=postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres
   SECRET_KEY=datafix-hackathon-secure-production-jwt-token-2026
   ```

2. Run dry-run migration check:
   ```bash
   python -m backend.migrate_to_postgres
   ```

3. Apply migration to live Supabase:
   ```bash
   python -m backend.migrate_to_postgres --apply
   ```

---

## REST API Reference (`/api/v1`)

| Endpoint | Method | Description |
| :--- | :---: | :--- |
| `/auth/login` | POST | Authenticate user & issue session token |
| `/auth/register` | POST | Register new analyst/engineer |
| `/auth/me` | GET | Active session verification |
| `/datasets` | GET | List all active datasets |
| `/datasets/upload` | POST | Upload dataset (CSV, XLSX, Parquet, JSON) |
| `/datasets/{id}` | GET | Get dataset schema, profile & preview rows |
| `/datasets/{id}/issues` | GET | Retrieve flagged data defects |
| `/datasets/{id}/diagnoses` | GET | Evidence-backed root cause diagnoses |
| `/datasets/{id}/repairs` | GET | Get algorithmic repair proposals |
| `/datasets/{id}/repairs/{id}/approve` | POST | Approve repair proposal |
| `/datasets/{id}/repairs/{id}/reject` | POST | Reject repair proposal |
| `/datasets/{id}/repairs/apply-batch` | POST | Apply all approved repairs & generate clean file |
| `/datasets/{id}/validations` | GET | 6-criteria validation matrix |
| `/datasets/{id}/explainability` | GET | Algorithmic rationale & counterfactual trade-offs |
| `/datasets/{id}/audit` | GET | Immutable forensic audit log |
| `/datasets/{id}/report` | GET | Executive cleanliness certification report |
| `/datasets/{id}/download` | GET | Download repaired dataset |
